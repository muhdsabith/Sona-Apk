import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/spotify_track.dart';
import '../services/apis.dart';
import '../services/spotify_auth.dart';

class SpotifyScreen extends StatefulWidget {
  const SpotifyScreen({super.key, required this.auth});
  final SpotifyAuth auth;
  @override
  State<SpotifyScreen> createState() => _SpotifyScreenState();
}

class _SpotifyScreenState extends State<SpotifyScreen> {
  final _clientId = TextEditingController();
  final _prefs = SharedPreferencesAsync();
  late final SpotifyApi _api;
  List<SpotifyTrack> _tracks = [];
  String _range = 'long_term';
  String? _error;
  bool _busy = true;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _api = SpotifyApi(auth: widget.auth);
    unawaited(_restoreSettings());
  }

  Future<void> _restoreSettings() async {
    try {
      final saved = await _prefs.getString('sona.spotify.client_id');
      if (!mounted) return;
      _clientId.text = saved ?? '';
    } catch (_) {
      if (!mounted) return;
      _error = 'Enter your Spotify Client ID to connect.';
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (widget.auth.connected) await _refresh();
  }

  String _message(Object error) => error is SpotifyException
      ? error.message
      : 'Could not reach Spotify. Check your internet connection and try again.';

  Future<void> _connect({bool freshBrowserSession = false}) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
      _loaded = false;
      _tracks = [];
    });
    try {
      await widget.auth.signIn(
        _clientId.text,
        freshBrowserSession: freshBrowserSession,
      );
      if (!mounted) return;
      try {
        await _prefs.setString('sona.spotify.client_id', _clientId.text.trim());
      } catch (_) {}
      final tracks = await _api.getTopTracks(timeRange: _range);
      if (mounted)
        setState(() {
          _tracks = tracks;
          _loaded = true;
        });
    } catch (error) {
      if (mounted) setState(() => _error = _message(error));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _refresh() async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
      _loaded = false;
      _tracks = [];
    });
    try {
      final tracks = await _api.getTopTracks(timeRange: _range);
      if (mounted)
        setState(() {
          _tracks = tracks;
          _loaded = true;
        });
    } catch (error) {
      if (mounted) setState(() => _error = _message(error));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _open(Uri uri) async {
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw const SpotifyException('Could not open Spotify on this phone.');
      }
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not open the link. Please try again.'),
          ),
        );
    }
  }

  void _disconnect() {
    widget.auth.signOut();
    setState(() {
      _tracks = [];
      _loaded = false;
      _error = null;
    });
  }

  @override
  void dispose() {
    _api.dispose();
    _clientId.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final connected = widget.auth.connected;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Spotify'),
        actions: [
          if (connected)
            TextButton(
              onPressed: _busy ? null : _disconnect,
              child: const Text('Disconnect'),
            ),
        ],
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 640),
            child: ListView(
              padding: const EdgeInsets.all(24),
              children: [
                Text(
                  'Your most-played favourites.',
                  style: Theme.of(context).textTheme.headlineLarge,
                ),
                const SizedBox(height: 12),
                const Text(
                  'Connect Spotify to see your top five tracks. Choose a track to listen in Spotify.',
                ),
                const SizedBox(height: 24),
                if (!connected) ...[
                  TextField(
                    controller: _clientId,
                    enabled: !_busy,
                    autocorrect: false,
                    enableSuggestions: false,
                    decoration: const InputDecoration(
                      labelText: 'Spotify Client ID',
                      helperText:
                          'From your Spotify developer app. No client secret needed.',
                    ),
                  ),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    onPressed: _busy ? null : _connect,
                    icon: const Icon(Icons.link),
                    label: const Text('Connect Spotify'),
                  ),
                  TextButton.icon(
                    onPressed: _busy
                        ? null
                        : () => _connect(freshBrowserSession: true),
                    icon: const Icon(Icons.refresh),
                    label: const Text('Try Chrome login'),
                  ),
                  const Text(
                    'Uses Chrome when available and requests a fresh login session. Another supported browser may be used if Chrome is unavailable.',
                    style: TextStyle(fontSize: 12),
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'First-time setup',
                    style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Create a Spotify developer app with Web API enabled. Add this exact redirect URI in its settings:',
                  ),
                  const SizedBox(height: 8),
                  SelectableText(
                    SpotifyAuth.redirectUri,
                    style: const TextStyle(fontWeight: FontWeight.w600),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton.icon(
                      onPressed: () async {
                        await Clipboard.setData(
                          const ClipboardData(text: SpotifyAuth.redirectUri),
                        );
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Redirect URI copied')),
                        );
                      },
                      icon: const Icon(Icons.copy, size: 18),
                      label: const Text('Copy redirect URI'),
                    ),
                  ),
                  const Text(
                    'Development access requires the app owner to have Spotify Premium. Add each test account under Users and Access in the developer dashboard.',
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton(
                      onPressed: () => _open(
                        Uri.parse('https://developer.spotify.com/dashboard'),
                      ),
                      child: const Text('Open Spotify developer dashboard'),
                    ),
                  ),
                ] else ...[
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final entry in const {
                        'short_term': '4 weeks',
                        'medium_term': '6 months',
                        'long_term': '1 year',
                      }.entries)
                        ChoiceChip(
                          label: Text(entry.value),
                          selected: _range == entry.key,
                          onSelected: _busy
                              ? null
                              : (selected) {
                                  if (!selected || _range == entry.key) return;
                                  setState(() => _range = entry.key);
                                  unawaited(_refresh());
                                },
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'Top tracks on Spotify',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                      ),
                      IconButton(
                        tooltip: 'Refresh tracks',
                        onPressed: _busy ? null : _refresh,
                        icon: const Icon(Icons.refresh),
                      ),
                    ],
                  ),
                ],
                if (_busy)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Center(child: CircularProgressIndicator()),
                  ),
                if (_error != null)
                  Container(
                    margin: const EdgeInsets.symmetric(vertical: 16),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.errorContainer,
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(
                      _error!,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.onErrorContainer,
                      ),
                    ),
                  ),
                const Text(
                  'Sona 2.0.1 · Optional Spotify connection',
                  style: TextStyle(fontSize: 12),
                ),
                if (connected && _loaded && _tracks.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 24),
                    child: Text(
                      'Spotify has no top tracks for this period yet. Try another time range.',
                    ),
                  ),
                for (final entry in _tracks.asMap().entries)
                  Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${entry.key + 1}. ${entry.value.title}',
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                          const SizedBox(height: 4),
                          Text(entry.value.artists),
                          const SizedBox(height: 8),
                          OutlinedButton.icon(
                            onPressed: () => _open(entry.value.url),
                            icon: const Icon(Icons.open_in_new, size: 18),
                            label: const Text('Open in Spotify'),
                          ),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: 20),
                const Text(
                  'Track information provided by Spotify. This connection does not stream Spotify audio in Sona. Login tokens stay in memory and are cleared when you disconnect or close the app.',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
