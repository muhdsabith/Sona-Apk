import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../controllers/app_controller.dart';
import '../models/media_item.dart';
import '../services/spotify_auth.dart';
import 'cover_art.dart';
import 'spotify_screen.dart';
import 'spotify_playlist_screen.dart';
import 'podcast_discovery.dart';

const accent = Color(0xFFC9F27A);
const muted = Color(0xFFA4ACA3);

String clock(Duration value) {
  final minutes = value.inMinutes.toString();
  final seconds = (value.inSeconds % 60).toString().padLeft(2, '0');
  return '$minutes:$seconds';
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.controller});
  final AppController controller;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int tab = 0;
  int filter = 0;
  String query = '';
  final search = TextEditingController();
  final spotifyAuth = SpotifyAuth();
  AppController get c => widget.controller;

  @override
  void dispose() {
    spotifyAuth.dispose();
    search.dispose();
    super.dispose();
  }

  Future<void> _openSpotify() async {
    try {
      await c.pause();
    } catch (_) {}
    if (!mounted) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => SpotifyScreen(auth: spotifyAuth)),
    );
  }

  Future<void> _openSpotifyPlaylist() async {
    if (c.loading) return;
    try {
      await c.pause();
    } catch (_) {}
    if (!mounted) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => const SpotifyPlaylistScreen()),
    );
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: c,
    builder: (context, _) => Scaffold(
      body: SafeArea(
        bottom: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 760),
            child: Column(
              children: [
                if (c.error != null)
                  MaterialBanner(
                    content: Text(c.error!),
                    actions: [
                      TextButton(
                        onPressed: c.clearError,
                        child: const Text('Dismiss'),
                      ),
                    ],
                  ),
                if (c.libraryBusy) const LinearProgressIndicator(minHeight: 2),
                Expanded(
                  child: !c.initialized
                      ? const Center(child: CircularProgressIndicator())
                      : IndexedStack(
                          index: tab,
                          children: [
                            _home(),
                            _search(),
                            _podcasts(),
                            _library(),
                          ],
                        ),
                ),
                if (c.current != null) _miniPlayer(),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (value) => setState(() => tab = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.search_rounded),
            label: 'Search',
          ),
          NavigationDestination(
            icon: Icon(Icons.mic_none_rounded),
            selectedIcon: Icon(Icons.mic_rounded),
            label: 'Podcasts',
          ),
          NavigationDestination(
            icon: Icon(Icons.library_music_outlined),
            selectedIcon: Icon(Icons.library_music),
            label: 'Library',
          ),
        ],
      ),
    ),
  );

  Widget _heading(String eyebrow, String title, {Widget? trailing}) => Padding(
    padding: const EdgeInsets.fromLTRB(24, 24, 24, 18),
    child: Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                eyebrow,
                style: const TextStyle(
                  color: muted,
                  fontSize: 11,
                  letterSpacing: 2.4,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              Text(title, style: Theme.of(context).textTheme.headlineLarge),
            ],
          ),
        ),
        if (trailing != null) trailing,
      ],
    ),
  );

  Widget _home() => ListView(
    key: const PageStorageKey('home'),
    children: [
      _heading(
        'YOUR EVERYDAY SOUNDTRACK',
        'Find your frequency.',
        trailing: Container(
          width: 42,
          height: 42,
          decoration: const BoxDecoration(
            color: accent,
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.graphic_eq_rounded, color: Colors.black),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Wrap(
          spacing: 8,
          children: [
            for (final entry in [
              'For you',
              'Music',
              'Podcasts',
            ].asMap().entries)
              ChoiceChip(
                label: Text(entry.value),
                selected: filter == entry.key,
                selectedColor: accent,
                showCheckmark: false,
                labelStyle: TextStyle(
                  color: filter == entry.key ? Colors.black : Colors.white,
                ),
                onSelected: (_) => setState(() => filter = entry.key),
              ),
          ],
        ),
      ),
      const SizedBox(height: 24),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Wrap(
          spacing: 10,
          runSpacing: 8,
          children: [
            FilledButton.icon(
              onPressed: c.libraryBusy ? null : c.importMusic,
              icon: const Icon(Icons.audio_file_outlined),
              label: const Text('Import music'),
            ),
            OutlinedButton.icon(
              onPressed: _discoverPodcasts,
              icon: const Icon(Icons.podcasts),
              label: const Text('Find podcasts'),
            ),
          ],
        ),
      ),
      if (!c.hasUserContent)
        const Padding(
          padding: EdgeInsets.fromLTRB(24, 16, 24, 20),
          child: Text(
            'Your player, your collection. Import audio from your phone or follow a podcast to get started. The Sona samples below let you try the player.',
            style: TextStyle(color: muted),
          ),
        ),
      if (c.recentItems.isNotEmpty) ...[
        _section('Pick up where you left off'),
        ...c.recentItems.take(3).map((m) => _row(m, c.recentItems)),
      ],
      if (filter != 2 && c.music.isNotEmpty) _hero(c.music.first),
      if (filter != 2) ...[
        _section(
          'Your music',
          subtitle:
              'Play directly in Sona. Keep listening with your screen locked.',
        ),
        _cards(c.music),
      ],
      if (filter != 1) ...[
        _section(
          'Good company',
          subtitle: 'Fresh perspectives, one episode at a time.',
        ),
        ...c.podcasts.map((m) => _row(m, c.podcasts)),
      ],
      const Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'SONA 2.0 / YOUR MUSIC. YOUR MOMENT.',
          style: TextStyle(color: muted, fontSize: 10, letterSpacing: 1.8),
        ),
      ),
    ],
  );

  Widget _hero(MediaItem item) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 24),
    child: Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: const LinearGradient(
          colors: [Color(0xFF33482C), Color(0xFF1C261B)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.auto_awesome, size: 15, color: accent),
                SizedBox(width: 8),
                Text(
                  'FROM YOUR COLLECTION',
                  style: TextStyle(
                    color: accent,
                    fontSize: 10,
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Less noise.\nMore feeling.',
                        style: TextStyle(
                          fontSize: 30,
                          height: 1.05,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -1,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        item.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Color(0xFFBECDB6)),
                      ),
                      const SizedBox(height: 16),
                      FilledButton.icon(
                        onPressed: c.loading
                            ? null
                            : () => _play(item, c.music),
                        icon: const Icon(Icons.play_arrow_rounded),
                        label: const Text('Press play'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                CoverArt(
                  item: item,
                  size: MediaQuery.sizeOf(context).width < 370 ? 80 : 112,
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );

  Widget _section(String title, {String? subtitle}) => Padding(
    padding: const EdgeInsets.fromLTRB(24, 28, 24, 16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge),
        if (subtitle != null) ...[
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: muted)),
        ],
      ],
    ),
  );

  Widget _cards(List<MediaItem> items) => SizedBox(
    height: 236,
    child: ListView.separated(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      itemCount: items.length,
      separatorBuilder: (_, index) => const SizedBox(width: 16),
      itemBuilder: (_, i) {
        final item = items[i];
        return SizedBox(
          width: 164,
          child: InkWell(
            borderRadius: BorderRadius.circular(22),
            onTap: c.loading ? null : () => _play(item, items),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CoverArt(item: item, size: 164),
                const SizedBox(height: 10),
                Text(
                  item.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 3),
                Text(
                  item.category,
                  style: const TextStyle(color: muted, fontSize: 12),
                ),
              ],
            ),
          ),
        );
      },
    ),
  );

  Widget _row(
    MediaItem item,
    List<MediaItem> collection, {
    UserPlaylist? playlist,
  }) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
    leading: CoverArt(item: item, size: 56),
    title: Text(
      item.title,
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        fontWeight: FontWeight.w600,
        color: c.current?.id == item.id ? accent : Colors.white,
      ),
    ),
    subtitle: Text(
      '${item.creator}${item.isLocal || c.library.downloads.containsKey(item.id) ? ' · Offline' : ''}',
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: const TextStyle(color: muted, fontSize: 12),
    ),
    onTap: c.loading ? null : () => _play(item, collection),
    trailing: PopupMenuButton<String>(
      tooltip: 'Track options',
      onSelected: (action) {
        if (action == 'like') c.toggleLike(item);
        if (action == 'add') _addToPlaylist(item);
        if (action == 'next') c.playNext(item);
        if (action == 'download') c.download(item);
        if (action == 'cancel') c.cancelDownload(item.id);
        if (action == 'deleteDownload') c.removeDownload(item);
        if (action == 'deleteItem') _deleteItem(item);
        if (action == 'remove' && playlist != null)
          c.removeFromPlaylist(playlist, item);
      },
      itemBuilder: (_) => [
        PopupMenuItem(
          value: 'like',
          child: Text(
            c.liked(item) ? 'Remove from favourites' : 'Add to favourites',
          ),
        ),
        const PopupMenuItem(value: 'add', child: Text('Add to playlist')),
        const PopupMenuItem(value: 'next', child: Text('Play next')),
        if (item.feedUrl != null &&
            !c.library.downloads.containsKey(item.id) &&
            !c.downloading.containsKey(item.id))
          const PopupMenuItem(
            value: 'download',
            child: Text('Download episode'),
          ),
        if (c.downloading.containsKey(item.id))
          const PopupMenuItem(value: 'cancel', child: Text('Cancel download')),
        if (c.library.downloads.containsKey(item.id))
          const PopupMenuItem(
            value: 'deleteDownload',
            child: Text('Remove download'),
          ),
        if (c.library.items.any((i) => i.id == item.id))
          const PopupMenuItem(
            value: 'deleteItem',
            child: Text('Remove from Sona'),
          ),
        if (playlist != null)
          const PopupMenuItem(
            value: 'remove',
            child: Text('Remove from playlist'),
          ),
      ],
    ),
  );

  Widget _search() {
    final normalized = query.trim().toLowerCase();
    final matches = c.catalog
        .where(
          (m) => '${m.title} ${m.creator} ${m.category}'.toLowerCase().contains(
            normalized,
          ),
        )
        .toList();
    return ListView(
      key: const PageStorageKey('search'),
      children: [
        _heading('FOLLOW YOUR CURIOSITY', 'Discover.'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: TextField(
            controller: search,
            onChanged: (value) => setState(() => query = value),
            decoration: InputDecoration(
              hintText: 'Songs, podcasts, creators',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: query.isEmpty
                  ? null
                  : IconButton(
                      tooltip: 'Clear search',
                      icon: const Icon(Icons.close),
                      onPressed: () {
                        search.clear();
                        setState(() => query = '');
                      },
                    ),
            ),
          ),
        ),
        if (normalized.isEmpty) ...[
          _section('Explore a mood'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: ['Your music', 'Podcasts', 'Chill', 'Focus']
                  .map(
                    (category) => ActionChip(
                      label: Text(category),
                      onPressed: () {
                        search.text = category;
                        setState(() => query = category);
                      },
                    ),
                  )
                  .toList(),
            ),
          ),
        ],
        _section(
          normalized.isEmpty
              ? 'Browse everything'
              : '${matches.length} results',
        ),
        if (matches.isEmpty)
          const _Empty(
            icon: Icons.search_off,
            title: 'Nothing here yet',
            body: 'Try a title, creator, or another category.',
          ),
        ...matches.map((m) => _row(m, matches)),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _podcasts() => ListView(
    key: const PageStorageKey('podcasts'),
    children: [
      _heading('IDEAS WORTH YOUR TIME', 'Listen a little closer.'),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Text(
          'A fresh thought for your walk, your commute, or your quiet hour.',
          style: const TextStyle(color: muted),
        ),
      ),
      Padding(
        padding: const EdgeInsets.all(24),
        child: Wrap(
          spacing: 8,
          children: [
            FilledButton.icon(
              onPressed: _discoverPodcasts,
              icon: const Icon(Icons.search),
              label: const Text('Find podcasts'),
            ),
            OutlinedButton.icon(
              onPressed: c.libraryBusy || c.library.feeds.isEmpty
                  ? null
                  : c.refreshFeeds,
              icon: const Icon(Icons.refresh),
              label: const Text('Refresh feeds'),
            ),
          ],
        ),
      ),
      ...c.library.feeds.map(
        (feed) => ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 24),
          leading: const Icon(Icons.rss_feed, color: accent),
          title: Text(feed.title),
          onTap: () => _collection(
            feed.title,
            () => c.podcasts.where((p) => p.feedUrl == feed.url).toList(),
          ),
          trailing: IconButton(
            tooltip: 'Unsubscribe',
            icon: const Icon(Icons.remove_circle_outline),
            onPressed: c.libraryBusy ? null : () => _unsubscribe(feed),
          ),
        ),
      ),
      _section('Episodes in your library'),
      _cards(c.podcasts),
      _section(
        'All episodes',
        subtitle: 'Your listening position is saved automatically.',
      ),
      ...c.podcasts.map(
        (m) => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _row(m, c.podcasts),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 16),
              child: Text(
                (c.library.progress[m.id] ?? 0) > 0
                    ? 'Continue from ${clock(Duration(milliseconds: c.library.progress[m.id]!))}'
                    : m.description,
                style: const TextStyle(color: muted, fontSize: 12),
              ),
            ),
          ],
        ),
      ),
    ],
  );

  Widget _library() => ListView(
    key: const PageStorageKey('library'),
    children: [
      _heading(
        'ALL YOUR GOOD FINDS',
        'Your library.',
        trailing: IconButton.filledTonal(
          tooltip: 'Create playlist',
          onPressed: _createPlaylist,
          icon: const Icon(Icons.add),
        ),
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.audio_file, color: accent),
        title: const Text('Import music'),
        subtitle: const Text('Choose audio files from your phone'),
        onTap: c.libraryBusy ? null : c.importMusic,
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.link, color: accent),
        title: const Text('Add an audio link'),
        subtitle: const Text('Stream your hosted music directly in Sona'),
        onTap: _audioLink,
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.download_done, color: accent),
        title: const Text('Available offline'),
        subtitle: Text(
          '${c.offlineItems.length} imported tracks and downloaded episodes',
        ),
        onTap: () => _collection('Available offline', () => c.offlineItems),
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.history, color: accent),
        title: const Text('Recently played'),
        onTap: () => _collection('Recently played', () => c.recentItems),
      ),
      if (c.downloading.isNotEmpty) ...[
        _section(
          'Downloads in progress',
          subtitle: 'Keep Sona open until your downloads finish.',
        ),
        ...c.downloading.entries.map(
          (entry) => ListTile(
            title: Text(
              c.catalog.where((i) => i.id == entry.key).firstOrNull?.title ??
                  'Episode',
            ),
            subtitle: LinearProgressIndicator(value: entry.value),
            trailing: IconButton(
              tooltip: 'Cancel download',
              icon: const Icon(Icons.close),
              onPressed: () => c.cancelDownload(entry.key),
            ),
          ),
        ),
      ],
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            color: accent,
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Icon(Icons.favorite, color: Color(0xFF25311A)),
        ),
        title: const Text(
          'Favourites',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text('${c.likedItems.length} saved tracks & episodes'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _collection('Favourites', () => c.likedItems),
      ),
      _section('Your playlists'),
      if (c.library.playlists.isEmpty)
        _Empty(
          icon: Icons.queue_music,
          title: 'Make it your own',
          body:
              'Create a playlist, then use a track’s menu to add your favourites.',
          action: TextButton.icon(
            onPressed: _createPlaylist,
            icon: const Icon(Icons.add),
            label: const Text('Create playlist'),
          ),
        ),
      ...c.library.playlists.map(
        (p) => ListTile(
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 8,
          ),
          leading: Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: const Color(0xFF31382C),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.queue_music, color: accent),
          ),
          title: Text(p.name),
          subtitle: Text('${p.itemIds.length} items'),
          onTap: () =>
              _collection(p.name, () => c.playlistItems(p), playlist: p),
          trailing: PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'rename')
                _renamePlaylist(p);
              else
                _deletePlaylist(p);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'rename', child: Text('Rename')),
              PopupMenuItem(value: 'delete', child: Text('Delete')),
            ],
          ),
        ),
      ),
      const Divider(),
      ExpansionTile(
        title: const Text('Optional Spotify connection'),
        subtitle: const Text('Spotify playback opens in Spotify'),
        children: [
          ListTile(
            title: const Text('Your Spotify top tracks'),
            trailing: const Icon(Icons.open_in_new),
            onTap: _openSpotify,
          ),
          ListTile(
            title: const Text('Spotify playlist embed'),
            trailing: const Icon(Icons.open_in_new),
            onTap: c.loading ? null : _openSpotifyPlaylist,
          ),
        ],
      ),
      const Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'Sona 2.0.1 · Your library is stored on this device. Imported audio is copied into Sona; uninstalling removes those copies and saved downloads.',
          style: TextStyle(color: muted, fontSize: 12),
        ),
      ),
      const SizedBox(height: 24),
    ],
  );

  Future<void> _audioLink() async {
    var title = '', address = '';
    final values = await showDialog<List<String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add an audio link'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                onChanged: (v) => title = v,
                decoration: const InputDecoration(labelText: 'Track title'),
              ),
              const SizedBox(height: 12),
              TextField(
                onChanged: (v) => address = v,
                keyboardType: TextInputType.url,
                autocorrect: false,
                decoration: const InputDecoration(
                  labelText: 'Direct HTTPS audio URL',
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Use a direct audio file address from your own or licensed catalog. Spotify and YouTube page links are not audio files.',
                style: TextStyle(fontSize: 12),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, [title, address]),
            child: const Text('Add'),
          ),
        ],
      ),
    );
    if (values != null) await c.addAudioLink(values[0], values[1]);
  }

  void _discoverPodcasts() => Navigator.of(context).push<void>(
    MaterialPageRoute(builder: (_) => PodcastDiscovery(controller: c)),
  );

  Future<void> _deleteItem(MediaItem item) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove from Sona?'),
        content: Text(
          'Remove “${item.title}” and its saved copy from Sona? Your original phone file is kept.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
    if (yes == true) await c.removeItem(item);
  }

  Future<void> _unsubscribe(PodcastFeed feed) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Unsubscribe?'),
        content: Text(
          'Stop refreshing ${feed.title}? Episodes already in your library are kept.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Unsubscribe'),
          ),
        ],
      ),
    );
    if (yes == true) await c.unsubscribe(feed);
  }

  Future<void> _renamePlaylist(UserPlaylist playlist) async {
    var name = playlist.name;
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename playlist'),
        content: TextFormField(
          initialValue: name,
          maxLength: 60,
          onChanged: (value) => name = value,
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (name.trim().isNotEmpty) Navigator.pop(ctx, name);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (result != null) c.renamePlaylist(playlist, result);
  }

  Future<void> _sleep() async {
    final minutes = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(title: Text('Sleep timer')),
            for (final n in [0, 15, 30, 45, 60])
              ListTile(
                title: Text(n == 0 ? 'Off' : '$n minutes'),
                onTap: () => Navigator.pop(ctx, n),
              ),
          ],
        ),
      ),
    );
    if (minutes != null) c.setSleepTimer(minutes);
  }

  Future<UserPlaylist?> _createPlaylist() async {
    String name = '';
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('A mix of your own'),
        content: TextField(
          autofocus: true,
          maxLength: 60,
          decoration: const InputDecoration(hintText: 'Playlist name'),
          onChanged: (value) => name = value,
          onSubmitted: (value) {
            if (value.trim().isNotEmpty) Navigator.pop(context, value);
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (name.trim().isNotEmpty) Navigator.pop(context, name);
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
    if (result == null || !mounted) return null;
    return c.createPlaylist(result);
  }

  Future<void> _deletePlaylist(UserPlaylist playlist) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete playlist?'),
        content: Text('Remove “${playlist.name}” from your library?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) c.deletePlaylist(playlist);
  }

  Future<void> _addToPlaylist(MediaItem item) async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.5,
          child: ListView(
            children: [
              const ListTile(
                title: Text(
                  'Add to playlist',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.add),
                title: const Text('New playlist'),
                onTap: () => Navigator.pop(context, 'new'),
              ),
              ...c.library.playlists.map(
                (p) => ListTile(
                  leading: const Icon(Icons.queue_music),
                  title: Text(p.name),
                  trailing: p.itemIds.contains(item.id)
                      ? const Icon(Icons.check, color: accent)
                      : null,
                  onTap: () => Navigator.pop(context, p.id),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (!mounted || selected == null) return;
    UserPlaylist? playlist;
    if (selected == 'new') {
      playlist = await _createPlaylist();
    } else {
      playlist = c.library.playlists.where((p) => p.id == selected).firstOrNull;
    }
    if (playlist == null || !mounted) return;
    c.addToPlaylist(playlist, item);
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('Added to ${playlist.name}')));
  }

  void _collection(
    String title,
    List<MediaItem> Function() items, {
    UserPlaylist? playlist,
  }) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.72,
          child: AnimatedBuilder(
            animation: c,
            builder: (context, _) {
              final collection = items();
              return ListView(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      title,
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                  ),
                  if (collection.isEmpty)
                    const _Empty(
                      icon: Icons.music_note,
                      title: 'Your next favourite is waiting',
                      body:
                          'Browse the collection and save something you love.',
                    ),
                  ...collection.map(
                    (m) => _row(m, collection, playlist: playlist),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  void _play(MediaItem item, List<MediaItem> collection) {
    unawaited(c.playItem(item, from: collection));
  }

  Widget _miniPlayer() {
    final item = c.current!;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
      child: Material(
        color: Color.lerp(Color(item.color), const Color(0xFF151915), 0.8),
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: _fullPlayer,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 4, 8),
                child: Row(
                  children: [
                    CoverArt(item: item, size: 44),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          Text(
                            item.creator,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: muted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: c.liked(item)
                          ? 'Remove favourite'
                          : 'Save favourite',
                      onPressed: () => c.toggleLike(item),
                      icon: Icon(
                        c.liked(item) ? Icons.favorite : Icons.favorite_border,
                        color: c.liked(item) ? accent : Colors.white,
                        size: 21,
                      ),
                    ),
                    _playButton(compact: true),
                  ],
                ),
              ),
              StreamBuilder<Duration>(
                stream: c.player.positionStream,
                builder: (_, snapshot) {
                  final total = c.player.duration?.inMilliseconds ?? 0;
                  final position = snapshot.data?.inMilliseconds ?? 0;
                  return LinearProgressIndicator(
                    minHeight: 2,
                    value: total > 0
                        ? (position / total).clamp(0.0, 1.0).toDouble()
                        : 0,
                    backgroundColor: Colors.white12,
                    color: accent,
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  bool get _playing =>
      c.player.playing && c.player.processingState != ProcessingState.completed;

  Widget _playButton({bool compact = false}) => c.loading
      ? SizedBox(
          width: compact ? 48 : 76,
          height: compact ? 48 : 76,
          child: const Center(
            child: SizedBox.square(
              dimension: 24,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ),
        )
      : IconButton.filled(
          tooltip: _playing ? 'Pause' : 'Play',
          style: IconButton.styleFrom(
            backgroundColor: compact ? Colors.transparent : accent,
            foregroundColor: compact ? Colors.white : Colors.black,
            minimumSize: Size.square(compact ? 48 : 76),
          ),
          onPressed: c.togglePlayback,
          icon: Icon(
            _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
            size: compact ? 32 : 46,
          ),
        );

  void _fullPlayer() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: const Color(0xFF161C16),
      builder: (sheetContext) => AnimatedBuilder(
        animation: c,
        builder: (context, _) {
          final item = c.current;
          if (item == null)
            return const SizedBox(
              height: 200,
              child: Center(child: Text('Choose something to play.')),
            );
          return FractionallySizedBox(
            heightFactor: 0.98,
            child: SafeArea(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 560),
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(28, 12, 28, 32),
                    children: [
                      Row(
                        children: [
                          IconButton(
                            tooltip: 'Close player',
                            onPressed: () => Navigator.pop(sheetContext),
                            icon: const Icon(Icons.keyboard_arrow_down),
                          ),
                          Expanded(
                            child: Text(
                              item.isPodcast
                                  ? 'NOW PLAYING / PODCAST'
                                  : 'NOW PLAYING / SONA',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                fontSize: 10,
                                letterSpacing: 2,
                                color: muted,
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: 'Add to playlist',
                            onPressed: () => _addToPlaylist(item),
                            icon: const Icon(Icons.playlist_add),
                          ),
                        ],
                      ),
                      const SizedBox(height: 24),
                      LayoutBuilder(
                        builder: (_, constraints) => Center(
                          child: CoverArt(
                            item: item,
                            size: constraints.maxWidth,
                          ),
                        ),
                      ),
                      const SizedBox(height: 28),
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item.title,
                                  style: Theme.of(
                                    context,
                                  ).textTheme.headlineMedium,
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  item.creator,
                                  style: const TextStyle(color: muted),
                                ),
                              ],
                            ),
                          ),
                          IconButton(
                            tooltip: c.liked(item)
                                ? 'Remove favourite'
                                : 'Save favourite',
                            onPressed: () => c.toggleLike(item),
                            icon: Icon(
                              c.liked(item)
                                  ? Icons.favorite
                                  : Icons.favorite_border,
                              color: c.liked(item) ? accent : Colors.white,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      if (c.error != null)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Text(
                            c.error!,
                            style: const TextStyle(color: Colors.orangeAccent),
                          ),
                        ),
                      StreamBuilder<Duration?>(
                        stream: c.player.durationStream,
                        builder: (_, durationSnapshot) =>
                            StreamBuilder<Duration>(
                              stream: c.player.positionStream,
                              builder: (_, positionSnapshot) {
                                final duration =
                                    durationSnapshot.data ??
                                    c.player.duration ??
                                    Duration.zero;
                                final position =
                                    positionSnapshot.data ?? c.player.position;
                                final totalMs = duration.inMilliseconds;
                                return Column(
                                  children: [
                                    Slider(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 14,
                                      ),
                                      value: totalMs > 0
                                          ? position.inMilliseconds
                                                .clamp(0, totalMs)
                                                .toDouble()
                                          : 0,
                                      max: totalMs > 0 ? totalMs.toDouble() : 1,
                                      onChanged: c.loading || totalMs == 0
                                          ? null
                                          : (value) => c.seek(
                                              Duration(
                                                milliseconds: value.round(),
                                              ),
                                            ),
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          clock(position),
                                          style: const TextStyle(
                                            color: muted,
                                            fontSize: 12,
                                          ),
                                        ),
                                        Text(
                                          clock(duration),
                                          style: const TextStyle(
                                            color: muted,
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                );
                              },
                            ),
                      ),
                      const SizedBox(height: 18),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          if (item.isPodcast)
                            TextButton(
                              onPressed: c.loading ? null : c.cycleSpeed,
                              child: Text('${c.speed}×'),
                            )
                          else
                            IconButton(
                              tooltip: 'Shuffle',
                              onPressed: c.toggleShuffle,
                              icon: Icon(
                                Icons.shuffle,
                                color: c.shuffle ? accent : muted,
                              ),
                            ),
                          IconButton(
                            tooltip: item.isPodcast
                                ? 'Back 10 seconds'
                                : 'Previous track',
                            onPressed: c.loading
                                ? null
                                : () => item.isPodcast
                                      ? c.seek(
                                          c.player.position -
                                              const Duration(seconds: 10),
                                        )
                                      : c.previous(),
                            icon: Icon(
                              item.isPodcast
                                  ? Icons.replay_10
                                  : Icons.skip_previous_rounded,
                              size: 32,
                            ),
                          ),
                          _playButton(),
                          IconButton(
                            tooltip: item.isPodcast
                                ? 'Forward 10 seconds'
                                : 'Next track',
                            onPressed: c.loading
                                ? null
                                : () => item.isPodcast
                                      ? c.seek(
                                          c.player.position +
                                              const Duration(seconds: 10),
                                        )
                                      : c.next(),
                            icon: Icon(
                              item.isPodcast
                                  ? Icons.forward_10
                                  : Icons.skip_next_rounded,
                              size: 32,
                            ),
                          ),
                          IconButton(
                            tooltip: 'Repeat current item',
                            onPressed: c.toggleRepeat,
                            icon: Icon(
                              Icons.repeat_one,
                              color: c.repeat ? accent : muted,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Center(
                        child: TextButton.icon(
                          onPressed: _sleep,
                          icon: const Icon(Icons.bedtime_outlined),
                          label: Text(
                            c.sleepUntil == null
                                ? 'Sleep timer'
                                : 'Sleep timer is on',
                          ),
                        ),
                      ),
                      if (item.feedUrl != null)
                        Center(
                          child: TextButton.icon(
                            onPressed: c.downloading.containsKey(item.id)
                                ? null
                                : () => c.library.downloads.containsKey(item.id)
                                      ? c.removeDownload(item)
                                      : c.download(item),
                            icon: Icon(
                              c.library.downloads.containsKey(item.id)
                                  ? Icons.download_done
                                  : Icons.download,
                            ),
                            label: Text(
                              c.downloading.containsKey(item.id)
                                  ? 'Downloading…'
                                  : c.library.downloads.containsKey(item.id)
                                  ? 'Remove download'
                                  : 'Download episode',
                            ),
                          ),
                        ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.04),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Text(
                          item.description,
                          style: const TextStyle(color: muted),
                        ),
                      ),
                      const SizedBox(height: 24),
                      const Text(
                        'IN THIS QUEUE',
                        style: TextStyle(
                          color: muted,
                          fontSize: 11,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 8),
                      ...c.queue.map(
                        (m) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: CoverArt(item: m, size: 44),
                          title: Text(m.title),
                          trailing: m.id == item.id
                              ? const Icon(Icons.graphic_eq, color: accent)
                              : null,
                          onTap: c.loading ? null : () => _play(m, c.queue),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({
    required this.icon,
    required this.title,
    required this.body,
    this.action,
  });
  final IconData icon;
  final String title;
  final String body;
  final Widget? action;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(30),
    child: Column(
      children: [
        Icon(icon, size: 44, color: accent),
        const SizedBox(height: 16),
        Text(
          title,
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 8),
        Text(
          body,
          textAlign: TextAlign.center,
          style: const TextStyle(color: muted),
        ),
        if (action != null) ...[const SizedBox(height: 12), action!],
      ],
    ),
  );
}
