import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../controllers/app_controller.dart';
import '../models/media_item.dart';
import '../services/spotify_auth.dart';
import 'cover_art.dart';
import 'spotify_screen.dart';
import 'spotify_playlist_screen.dart';

const accent = Color(0xFFC9F27A);
const muted = Color(0xFFA4ACA3);

String clock(Duration value) {
  final minutes = value.inMinutes.toString();
  final seconds = (value.inSeconds % 60).toString().padLeft(2, '0');
  return '$minutes:$seconds';
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.controller});
  final AppController controller;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int tab = 0;
  int filter = 0;
  String query = '';
  final search = TextEditingController();
  final spotifyAuth = SpotifyAuth();
  AppController get c => widget.controller;

  @override
  void dispose() { spotifyAuth.dispose(); search.dispose(); super.dispose(); }

  Future<void> _openSpotify() async {
    try { await c.player.pause(); } catch (_) { }
    if (!mounted) return;
    await Navigator.of(context).push<void>(MaterialPageRoute(
      builder: (_) => SpotifyScreen(auth: spotifyAuth)));
  }

  Future<void> _openSpotifyPlaylist() async {
    if (c.loading) return;
    try { await c.player.pause(); } catch (_) { }
    if (!mounted) return;
    await Navigator.of(context).push<void>(MaterialPageRoute(
      builder: (_) => const SpotifyPlaylistScreen()));
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: c,
    builder: (context, _) => Scaffold(
      body: SafeArea(bottom: false, child: Center(child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 760),
        child: Column(children: [
          if (c.error != null) MaterialBanner(
            content: Text(c.error!),
            actions: [TextButton(onPressed: c.clearError, child: const Text('Dismiss'))]),
          Expanded(child: !c.initialized
            ? const Center(child: CircularProgressIndicator())
            : IndexedStack(index: tab, children: [_home(), _search(), _podcasts(), _library()])),
          if (c.current != null) _miniPlayer(),
        ]),
      ))),
      bottomNavigationBar: NavigationBar(selectedIndex: tab,
        onDestinationSelected: (value) => setState(() => tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search_rounded), label: 'Search'),
          NavigationDestination(icon: Icon(Icons.mic_none_rounded), selectedIcon: Icon(Icons.mic_rounded), label: 'Podcasts'),
          NavigationDestination(icon: Icon(Icons.library_music_outlined), selectedIcon: Icon(Icons.library_music), label: 'Library'),
        ]),
    ),
  );

  Widget _heading(String eyebrow, String title, {Widget? trailing}) => Padding(
    padding: const EdgeInsets.fromLTRB(24, 24, 24, 18),
    child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(eyebrow, style: const TextStyle(color: muted, fontSize: 11, letterSpacing: 2.4, fontWeight: FontWeight.w700)),
      const SizedBox(height: 8),
      Text(title, style: Theme.of(context).textTheme.headlineLarge),
    ])), if (trailing != null) trailing]),
  );

  Widget _home() => ListView(key: const PageStorageKey('home'), children: [
    _heading('YOUR EVERYDAY SOUNDTRACK', 'Find your frequency.', trailing:
      Container(width: 42, height: 42, decoration: const BoxDecoration(color: accent, shape: BoxShape.circle),
        child: const Icon(Icons.graphic_eq_rounded, color: Colors.black))),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 24), child: Wrap(spacing: 8, children: [
      for (final entry in ['For you', 'Music', 'Podcasts'].asMap().entries)
        ChoiceChip(label: Text(entry.value), selected: filter == entry.key,
          selectedColor: accent, showCheckmark: false,
          labelStyle: TextStyle(color: filter == entry.key ? Colors.black : Colors.white),
          onSelected: (_) => setState(() => filter = entry.key)),
    ])),
    const SizedBox(height: 24),
    if (filter != 2) Padding(padding: const EdgeInsets.fromLTRB(24, 0, 24, 20), child: Card(
      margin: EdgeInsets.zero, child: ListTile(
        leading: const Icon(Icons.queue_music, color: accent),
        title: const Text('Your Spotify playlist'),
        subtitle: const Text('Open the Spotify player'),
        trailing: const Icon(Icons.chevron_right), onTap: c.loading ? null : _openSpotifyPlaylist))),
    if (filter != 2 && c.music.isNotEmpty) _hero(c.music.first),
    if (filter != 2) ...[
      _section('Made for this moment', subtitle: 'Original sounds. A little escape.'),
      _cards(c.music),
    ],
    if (filter != 1) ...[
      _section('Good company', subtitle: 'Fresh perspectives, one episode at a time.'),
      ...c.podcasts.map((m) => _row(m, c.podcasts)),
    ],
    const Padding(padding: EdgeInsets.all(24), child: Text('DEMO COLLECTION / SONA ORIGINALS',
      style: TextStyle(color: muted, fontSize: 10, letterSpacing: 1.8))),
  ]);

  Widget _hero(MediaItem item) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 24),
    child: Container(decoration: BoxDecoration(borderRadius: BorderRadius.circular(26),
      gradient: const LinearGradient(colors: [Color(0xFF33482C), Color(0xFF1C261B)],
        begin: Alignment.topLeft, end: Alignment.bottomRight)),
      child: Padding(padding: const EdgeInsets.all(22), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [Icon(Icons.auto_awesome, size: 15, color: accent), SizedBox(width: 8),
          Text('THE DAILY RESET', style: TextStyle(color: accent, fontSize: 10, letterSpacing: 2))]),
        const SizedBox(height: 18),
        Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Less noise.\nMore feeling.', style: TextStyle(fontSize: 30, height: 1.05,
              fontWeight: FontWeight.w800, letterSpacing: -1)),
            const SizedBox(height: 12),
            const Text('A softer place to land.', style: TextStyle(color: Color(0xFFBECDB6))),
            const SizedBox(height: 16),
            FilledButton.icon(onPressed: c.loading ? null : () => _play(item, c.music),
              icon: const Icon(Icons.play_arrow_rounded), label: const Text('Press play')),
          ])),
          const SizedBox(width: 8),
          CoverArt(item: item, size: MediaQuery.sizeOf(context).width < 370 ? 80 : 112),
        ]),
      ])),
    ),
  );

  Widget _section(String title, {String? subtitle}) => Padding(
    padding: const EdgeInsets.fromLTRB(24, 28, 24, 16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: Theme.of(context).textTheme.titleLarge),
      if (subtitle != null) ...[const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: muted))],
    ]),
  );

  Widget _cards(List<MediaItem> items) => SizedBox(height: 236,
    child: ListView.separated(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 24),
      itemCount: items.length, separatorBuilder: (_, index) => const SizedBox(width: 16),
      itemBuilder: (_, i) { final item = items[i]; return SizedBox(width: 164, child: InkWell(
        borderRadius: BorderRadius.circular(22), onTap: c.loading ? null : () => _play(item, items),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CoverArt(item: item, size: 164), const SizedBox(height: 10),
          Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 3), Text(item.category, style: const TextStyle(color: muted, fontSize: 12)),
        ]),
      )); }),
  );

  Widget _row(MediaItem item, List<MediaItem> collection, {UserPlaylist? playlist}) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
    leading: CoverArt(item: item, size: 56),
    title: Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis,
      style: TextStyle(fontWeight: FontWeight.w600, color: c.current?.id == item.id ? accent : Colors.white)),
    subtitle: Text(item.creator, maxLines: 1, overflow: TextOverflow.ellipsis,
      style: const TextStyle(color: muted, fontSize: 12)),
    onTap: c.loading ? null : () => _play(item, collection),
    trailing: PopupMenuButton<String>(tooltip: 'Track options',
      onSelected: (action) {
        if (action == 'like') c.toggleLike(item);
        if (action == 'add') _addToPlaylist(item);
        if (action == 'remove' && playlist != null) c.removeFromPlaylist(playlist, item);
      },
      itemBuilder: (_) => [
        PopupMenuItem(value: 'like', child: Text(c.liked(item) ? 'Remove from favourites' : 'Add to favourites')),
        const PopupMenuItem(value: 'add', child: Text('Add to playlist')),
        if (playlist != null) const PopupMenuItem(value: 'remove', child: Text('Remove from playlist')),
      ]),
  );

  Widget _search() {
    final normalized = query.trim().toLowerCase();
    final matches = c.catalog.where((m) => '${m.title} ${m.creator} ${m.category}'.toLowerCase().contains(normalized)).toList();
    return ListView(key: const PageStorageKey('search'), children: [
      _heading('FOLLOW YOUR CURIOSITY', 'Discover.'),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 24), child: TextField(
        controller: search, onChanged: (value) => setState(() => query = value),
        decoration: InputDecoration(hintText: 'Songs, podcasts, creators', prefixIcon: const Icon(Icons.search),
          suffixIcon: query.isEmpty ? null : IconButton(tooltip: 'Clear search', icon: const Icon(Icons.close),
            onPressed: () { search.clear(); setState(() => query = ''); })))),
      if (normalized.isEmpty) ...[
        _section('Explore a mood'),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 24), child: Wrap(spacing: 8, runSpacing: 8,
          children: ['Chill', 'Focus', 'Electronic', 'Creativity', 'Lifestyle'].map((category) => ActionChip(
            label: Text(category), onPressed: () { search.text = category; setState(() => query = category); })).toList())),
      ],
      _section(normalized.isEmpty ? 'Browse everything' : '${matches.length} results'),
      if (matches.isEmpty) const _Empty(icon: Icons.search_off, title: 'Nothing here yet',
        body: 'Try a title, creator, or another category.'),
      ...matches.map((m) => _row(m, matches)),
      const SizedBox(height: 24),
    ]);
  }

  Widget _podcasts() => ListView(key: const PageStorageKey('podcasts'), children: [
    _heading('IDEAS WORTH YOUR TIME', 'Listen a little closer.'),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 24), child: Text(
      'A fresh thought for your walk, your commute, or your quiet hour.', style: const TextStyle(color: muted))),
    _section('Featured conversations'),
    _cards(c.podcasts),
    _section('All episodes', subtitle: 'Your listening position is saved automatically.'),
    ...c.podcasts.map((m) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _row(m, c.podcasts),
      Padding(padding: const EdgeInsets.fromLTRB(24, 0, 24, 16), child: Text(
        (c.library.progress[m.id] ?? 0) > 0
          ? 'Continue from ${clock(Duration(milliseconds: c.library.progress[m.id]!))}' : m.description,
        style: const TextStyle(color: muted, fontSize: 12))),
    ])),
  ]);

  Widget _library() => ListView(key: const PageStorageKey('library'), children: [
    _heading('ALL YOUR GOOD FINDS', 'Your library.', trailing: IconButton.filledTonal(
      tooltip: 'Create playlist', onPressed: _createPlaylist, icon: const Icon(Icons.add))),
    ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      leading: const CircleAvatar(backgroundColor: Color(0xFF1DB954),
        child: Icon(Icons.queue_music, color: Colors.black)),
      title: const Text('Your Spotify playlist', style: TextStyle(fontWeight: FontWeight.w700)),
      subtitle: const Text('Listen with the embedded Spotify player'),
      trailing: const Icon(Icons.chevron_right), onTap: c.loading ? null : _openSpotifyPlaylist),
    ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      leading: const CircleAvatar(backgroundColor: Color(0xFF1DB954),
        child: Icon(Icons.link, color: Colors.black)),
      title: const Text('Connect Spotify', style: TextStyle(fontWeight: FontWeight.w700)),
      subtitle: const Text('Your top tracks, linked to Spotify'),
      trailing: const Icon(Icons.chevron_right), onTap: _openSpotify),
    ListTile(contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      leading: Container(width: 56, height: 56, decoration: BoxDecoration(color: accent,
        borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.favorite, color: Color(0xFF25311A))),
      title: const Text('Favourites', style: TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text('${c.likedItems.length} saved tracks & episodes'),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => _collection('Favourites', () => c.likedItems)),
    _section('Your playlists'),
    if (c.library.playlists.isEmpty) _Empty(icon: Icons.queue_music, title: 'Make it your own',
      body: 'Create a playlist, then use a track’s menu to add your favourites.',
      action: TextButton.icon(onPressed: _createPlaylist, icon: const Icon(Icons.add), label: const Text('Create playlist'))),
    ...c.library.playlists.map((p) => ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      leading: Container(width: 56, height: 56, decoration: BoxDecoration(color: const Color(0xFF31382C),
        borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.queue_music, color: accent)),
      title: Text(p.name), subtitle: Text('${p.itemIds.length} items'),
      onTap: () => _collection(p.name, () => c.playlistItems(p), playlist: p),
      trailing: IconButton(tooltip: 'Delete playlist', icon: const Icon(Icons.delete_outline, size: 21),
        onPressed: () => _deletePlaylist(p)),
    )),
    const SizedBox(height: 24),
  ]);

  Future<UserPlaylist?> _createPlaylist() async {
    String name = '';
    final result = await showDialog<String>(context: context, builder: (context) => AlertDialog(
      title: const Text('A mix of your own'),
      content: TextField(autofocus: true, maxLength: 60, decoration: const InputDecoration(hintText: 'Playlist name'),
        onChanged: (value) => name = value, onSubmitted: (value) {
          if (value.trim().isNotEmpty) Navigator.pop(context, value);
        }),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
        FilledButton(onPressed: () { if (name.trim().isNotEmpty) Navigator.pop(context, name); }, child: const Text('Create'))],
    ));
    if (result == null || !mounted) return null;
    return c.createPlaylist(result);
  }

  Future<void> _deletePlaylist(UserPlaylist playlist) async {
    final confirmed = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Delete playlist?'), content: Text('Remove “${playlist.name}” from your library?'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Delete'))]));
    if (confirmed == true && mounted) c.deletePlaylist(playlist);
  }

  Future<void> _addToPlaylist(MediaItem item) async {
    final selected = await showModalBottomSheet<String>(context: context, isScrollControlled: true,
      showDragHandle: true, builder: (context) => SafeArea(child: SizedBox(
        height: MediaQuery.sizeOf(context).height * 0.5,
        child: ListView(children: [
          const ListTile(title: Text('Add to playlist', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
          ListTile(leading: const Icon(Icons.add), title: const Text('New playlist'),
            onTap: () => Navigator.pop(context, 'new')),
          ...c.library.playlists.map((p) => ListTile(leading: const Icon(Icons.queue_music), title: Text(p.name),
            trailing: p.itemIds.contains(item.id) ? const Icon(Icons.check, color: accent) : null,
            onTap: () => Navigator.pop(context, p.id))),
        ]),
      )));
    if (!mounted || selected == null) return;
    UserPlaylist? playlist;
    if (selected == 'new') { playlist = await _createPlaylist(); }
    else { playlist = c.library.playlists.where((p) => p.id == selected).firstOrNull; }
    if (playlist == null || !mounted) return;
    c.addToPlaylist(playlist, item);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Added to ${playlist.name}')));
  }

  void _collection(String title, List<MediaItem> Function() items, {UserPlaylist? playlist}) {
    showModalBottomSheet<void>(context: context, isScrollControlled: true, showDragHandle: true,
      builder: (context) => SafeArea(child: SizedBox(height: MediaQuery.sizeOf(context).height * 0.72,
        child: AnimatedBuilder(animation: c, builder: (context, _) {
          final collection = items();
          return ListView(children: [
            Padding(padding: const EdgeInsets.all(24), child: Text(title, style: Theme.of(context).textTheme.headlineMedium)),
            if (collection.isEmpty) const _Empty(icon: Icons.music_note, title: 'Your next favourite is waiting',
              body: 'Browse the collection and save something you love.'),
            ...collection.map((m) => _row(m, collection, playlist: playlist)),
          ]);
        }),
      )));
  }

  void _play(MediaItem item, List<MediaItem> collection) {
    unawaited(c.playItem(item, from: collection));
  }

  Widget _miniPlayer() {
    final item = c.current!;
    return Padding(padding: const EdgeInsets.fromLTRB(12, 4, 12, 4), child: Material(
      color: Color.lerp(Color(item.color), const Color(0xFF151915), 0.8),
      borderRadius: BorderRadius.circular(16), clipBehavior: Clip.antiAlias,
      child: InkWell(onTap: _fullPlayer, child: Column(mainAxisSize: MainAxisSize.min, children: [
        Padding(padding: const EdgeInsets.fromLTRB(10, 8, 4, 8), child: Row(children: [
          CoverArt(item: item, size: 44), const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
            Text(item.creator, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: muted, fontSize: 11)),
          ])),
          IconButton(tooltip: c.liked(item) ? 'Remove favourite' : 'Save favourite', onPressed: () => c.toggleLike(item),
            icon: Icon(c.liked(item) ? Icons.favorite : Icons.favorite_border, color: c.liked(item) ? accent : Colors.white, size: 21)),
          _playButton(compact: true),
        ])),
        StreamBuilder<Duration>(stream: c.player.positionStream, builder: (_, snapshot) {
          final total = c.player.duration?.inMilliseconds ?? 0;
          final position = snapshot.data?.inMilliseconds ?? 0;
          return LinearProgressIndicator(minHeight: 2,
            value: total > 0 ? (position / total).clamp(0.0, 1.0).toDouble() : 0,
            backgroundColor: Colors.white12, color: accent);
        }),
      ])),
    ));
  }

  bool get _playing => c.player.playing && c.player.processingState != ProcessingState.completed;

  Widget _playButton({bool compact = false}) => c.loading
    ? SizedBox(width: compact ? 48 : 76, height: compact ? 48 : 76,
        child: const Center(child: SizedBox.square(dimension: 24, child: CircularProgressIndicator(strokeWidth: 2))))
    : IconButton.filled(
        tooltip: _playing ? 'Pause' : 'Play',
        style: IconButton.styleFrom(backgroundColor: compact ? Colors.transparent : accent,
          foregroundColor: compact ? Colors.white : Colors.black, minimumSize: Size.square(compact ? 48 : 76)),
        onPressed: c.togglePlayback, icon: Icon(_playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
          size: compact ? 32 : 46));

  void _fullPlayer() {
    showModalBottomSheet<void>(context: context, isScrollControlled: true, useSafeArea: true,
      backgroundColor: const Color(0xFF161C16),
      builder: (sheetContext) => AnimatedBuilder(animation: c, builder: (context, _) {
        final item = c.current!;
        return FractionallySizedBox(heightFactor: 0.98, child: SafeArea(child: Center(
          child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 560), child: ListView(
            padding: const EdgeInsets.fromLTRB(28, 12, 28, 32), children: [
              Row(children: [IconButton(tooltip: 'Close player', onPressed: () => Navigator.pop(sheetContext),
                icon: const Icon(Icons.keyboard_arrow_down)),
                Expanded(child: Text(item.isPodcast ? 'NOW PLAYING / PODCAST' : 'NOW PLAYING / SONA',
                  textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, letterSpacing: 2, color: muted))),
                IconButton(tooltip: 'Add to playlist', onPressed: () => _addToPlaylist(item), icon: const Icon(Icons.playlist_add)),
              ]),
              const SizedBox(height: 24),
              LayoutBuilder(builder: (_, constraints) => Center(child: CoverArt(item: item, size: constraints.maxWidth))),
              const SizedBox(height: 28),
              Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(item.title, style: Theme.of(context).textTheme.headlineMedium),
                const SizedBox(height: 6), Text(item.creator, style: const TextStyle(color: muted)),
              ])), IconButton(tooltip: c.liked(item) ? 'Remove favourite' : 'Save favourite',
                onPressed: () => c.toggleLike(item), icon: Icon(c.liked(item) ? Icons.favorite : Icons.favorite_border,
                  color: c.liked(item) ? accent : Colors.white))]),
              const SizedBox(height: 16),
              if (c.error != null) Padding(padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(c.error!, style: const TextStyle(color: Colors.orangeAccent))),
              StreamBuilder<Duration?>(stream: c.player.durationStream, builder: (_, durationSnapshot) =>
                StreamBuilder<Duration>(stream: c.player.positionStream, builder: (_, positionSnapshot) {
                  final duration = durationSnapshot.data ?? c.player.duration ?? Duration.zero;
                  final position = positionSnapshot.data ?? c.player.position;
                  final totalMs = duration.inMilliseconds;
                  return Column(children: [
                    Slider(padding: const EdgeInsets.symmetric(vertical: 14),
                      value: totalMs > 0 ? position.inMilliseconds.clamp(0, totalMs).toDouble() : 0,
                      max: totalMs > 0 ? totalMs.toDouble() : 1,
                      onChanged: c.loading || totalMs == 0 ? null : (value) => c.seek(Duration(milliseconds: value.round()))),
                    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      Text(clock(position), style: const TextStyle(color: muted, fontSize: 12)),
                      Text(clock(duration), style: const TextStyle(color: muted, fontSize: 12)),
                    ]),
                  ]);
                })),
              const SizedBox(height: 18),
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                if (item.isPodcast) TextButton(onPressed: c.loading ? null : c.cycleSpeed, child: Text('${c.speed}×'))
                else IconButton(tooltip: 'Shuffle', onPressed: c.toggleShuffle,
                  icon: Icon(Icons.shuffle, color: c.shuffle ? accent : muted)),
                IconButton(tooltip: item.isPodcast ? 'Back 10 seconds' : 'Previous track',
                  onPressed: c.loading ? null : () => item.isPodcast
                    ? c.seek(c.player.position - const Duration(seconds: 10)) : c.previous(),
                  icon: Icon(item.isPodcast ? Icons.replay_10 : Icons.skip_previous_rounded, size: 32)),
                _playButton(),
                IconButton(tooltip: item.isPodcast ? 'Forward 10 seconds' : 'Next track',
                  onPressed: c.loading ? null : () => item.isPodcast
                    ? c.seek(c.player.position + const Duration(seconds: 10)) : c.next(),
                  icon: Icon(item.isPodcast ? Icons.forward_10 : Icons.skip_next_rounded, size: 32)),
                IconButton(tooltip: 'Repeat current item', onPressed: c.toggleRepeat,
                  icon: Icon(Icons.repeat_one, color: c.repeat ? accent : muted)),
              ]),
              const SizedBox(height: 28),
              Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.04), borderRadius: BorderRadius.circular(18)),
                child: Text(item.description, style: const TextStyle(color: muted))),
              const SizedBox(height: 24),
              const Text('IN THIS QUEUE', style: TextStyle(color: muted, fontSize: 11, letterSpacing: 2)),
              const SizedBox(height: 8),
              ...c.queue.map((m) => ListTile(contentPadding: EdgeInsets.zero,
                leading: CoverArt(item: m, size: 44), title: Text(m.title),
                trailing: m.id == item.id ? const Icon(Icons.graphic_eq, color: accent) : null,
                onTap: c.loading ? null : () => _play(m, c.queue))),
            ],
          )),
        )));
      }));
  }
}

class _Empty extends StatelessWidget {
  const _Empty({required this.icon, required this.title, required this.body, this.action});
  final IconData icon;
  final String title;
  final String body;
  final Widget? action;

  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.all(30), child: Column(children: [
    Icon(icon, size: 44, color: accent), const SizedBox(height: 16),
    Text(title, textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleMedium),
    const SizedBox(height: 8), Text(body, textAlign: TextAlign.center, style: const TextStyle(color: muted)),
    if (action != null) ...[const SizedBox(height: 12), action!],
  ]));
}
