import 'dart:async';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../controllers/app_controller.dart';
import '../models/media_item.dart';
import 'cover_art.dart';
import 'spotify_companion_screen.dart';
import 'spotify_playlist_screen.dart';
import 'package:url_launcher/url_launcher.dart';

const accent = Color(0xFFC9F27A);
const muted = Color(0xFFA4ACA3);

String clock(Duration value) {
  final minutes = value.inMinutes.toString();
  final seconds = (value.inSeconds % 60).toString().padLeft(2, '0');
  return '$minutes:$seconds';
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.controller});
  final AppController controller;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> with WidgetsBindingObserver {
  int tab = 0;
  String query = '';
  final search = TextEditingController();
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    unawaited(c.setForeground(state == AppLifecycleState.resumed));
  }

  void _searchFor(String value) {
    search.text = value;
    setState(() {
      query = value;
      tab = 1;
    });
    unawaited(c.searchOnline(value));
  }

  AppController get c => widget.controller;

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    search.dispose();
    super.dispose();
  }

  Future<void> _openSpotify() async {
    try {
      await c.pause();
    } catch (_) {}
    if (!mounted) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => const SpotifyCompanionScreen()),
    );
  }

  Future<void> _openSpotifyPlaylist() async {
    if (c.loading) return;
    try {
      await c.pause();
    } catch (_) {}
    if (!mounted) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => const SpotifyPlaylistScreen()),
    );
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: c,
    builder: (context, _) => Scaffold(
      body: SafeArea(
        bottom: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 760),
            child: Column(
              children: [
                if (c.error != null && c.playbackError == null)
                  MaterialBanner(
                    content: Text(c.error!),
                    actions: [
                      TextButton(
                        onPressed: c.clearError,
                        child: const Text('Dismiss'),
                      ),
                    ],
                  ),
                if (c.libraryBusy) const LinearProgressIndicator(minHeight: 2),
                Expanded(
                  child: !c.initialized
                      ? const Center(child: CircularProgressIndicator())
                      : IndexedStack(
                          index: tab,
                          children: [_home(), _search(), _library()],
                        ),
                ),
                if (c.current != null) _miniPlayer(),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        height: 72,
        selectedIndex: tab,
        onDestinationSelected: (value) => setState(() => tab = value),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.search_rounded),
            label: 'Search',
          ),
          NavigationDestination(
            icon: Icon(Icons.library_music_outlined),
            selectedIcon: Icon(Icons.library_music),
            label: 'Library',
          ),
        ],
      ),
    ),
  );

  Widget _heading(String eyebrow, String title, {Widget? trailing}) => Padding(
    padding: const EdgeInsets.fromLTRB(24, 24, 24, 18),
    child: Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                eyebrow,
                style: const TextStyle(
                  color: muted,
                  fontSize: 11,
                  letterSpacing: 2.4,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              Text(title, style: Theme.of(context).textTheme.headlineLarge),
            ],
          ),
        ),
        if (trailing != null) trailing,
      ],
    ),
  );

  Widget _home() => RefreshIndicator(
    onRefresh: () => c.loadHome(useCache: false),
    child: ListView(
      key: const PageStorageKey('home'),
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 20, 24, 8),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset(
                  'branding/sona-icon.png',
                  width: 36,
                  height: 36,
                ),
              ),
              const SizedBox(width: 10),
              const Text(
                'sona',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  letterSpacing: -1.2,
                ),
              ),
              const Spacer(),
              IconButton(
                tooltip: 'Your library',
                onPressed: () => setState(() => tab = 2),
                icon: const Icon(Icons.library_music_outlined),
              ),
            ],
          ),
        ),
        _heading('A LITTLE ESCAPE, EVERY DAY', 'Stay in your rhythm.'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () => setState(() => tab = 1),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: const Color(0xFF1B1E20),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white.withValues(alpha: .07)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.search, color: accent),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'What do you want to hear?',
                      style: TextStyle(color: muted),
                    ),
                  ),
                  Icon(Icons.arrow_forward, size: 18),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 22),
        _editorial(),
        _section(
          'Made for your mood',
          subtitle: 'Find the sound that fits right now.',
        ),
        _moods(),
        if (c.recentItems.isNotEmpty) ...[
          _section(
            'Back to your favourites',
            subtitle: 'Your recent rotation.',
          ),
          ...c.recentItems.take(3).map((m) => _row(m, c.recentItems)),
        ],
        for (final title in AppController.homeQueries.keys) ...[
          _section(
            title,
            subtitle: title.startsWith('Malayalam')
                ? 'Close to home.'
                : title.startsWith('Tamil')
                ? 'Melodies that stay with you.'
                : 'A different kind of everyday.',
          ),
          if (c.homeLoading.contains(title) &&
              (c.homeSongs[title]?.isEmpty ?? true))
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 40),
              child: LinearProgressIndicator(minHeight: 2),
            ),
          if (c.homeSongs[title]?.isNotEmpty == true)
            _cards(c.homeSongs[title]!),
          if (c.homeErrors[title] != null)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Text(
                c.homeErrors[title]!,
                style: const TextStyle(color: muted),
              ),
            ),
        ],
        if (c.music.isNotEmpty) ...[
          _section('Your collection'),
          _cards(c.music),
        ],
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 30, 24, 32),
          child: Row(
            children: [
              const Expanded(
                child: Text(
                  'YOUR MUSIC. YOUR MOMENT.',
                  style: TextStyle(
                    color: muted,
                    fontSize: 10,
                    letterSpacing: 2,
                  ),
                ),
              ),
              IconButton(
                tooltip: 'Refresh discoveries',
                onPressed: c.homeLoading.isEmpty
                    ? () => c.loadHome(useCache: false)
                    : null,
                icon: const Icon(Icons.refresh, size: 20),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  Widget _editorial() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 24),
    child: Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF343F34), Color(0xFF1B2525), Color(0xFF1C2027)],
        ),
        border: Border.all(color: Colors.white.withValues(alpha: .08)),
      ),
      child: Stack(
        children: [
          const Positioned(
            right: -36,
            top: -22,
            child: ExcludeSemantics(
              child: Icon(
                Icons.album_outlined,
                size: 240,
                color: Color(0x159DCC7B),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'THE SLOW EDIT',
                  style: TextStyle(
                    color: accent,
                    letterSpacing: 2.6,
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'Less rush.\nMore music.',
                  style: TextStyle(
                    fontSize: 34,
                    fontWeight: FontWeight.w700,
                    height: 1.12,
                    letterSpacing: -1.2,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'A softer soundtrack to your day.',
                  style: TextStyle(color: Color(0xFFBBC6BC)),
                ),
                const SizedBox(height: 22),
                FilledButton.icon(
                  onPressed: () => _searchFor('chill songs official audio'),
                  icon: const Icon(Icons.arrow_forward_rounded, size: 18),
                  label: const Text('Explore chill'),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );

  Widget _moods() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 24),
    child: Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final entry in const {
          'Chill': 'chill songs',
          'Focus': 'instrumental focus music',
          'After hours': 'late night songs',
          'Feel good': 'feel good songs',
        }.entries)
          ActionChip(
            label: Text(entry.key),
            avatar: Icon(
              entry.key == 'After hours'
                  ? Icons.nights_stay_outlined
                  : Icons.waves,
              size: 16,
            ),
            onPressed: () => _searchFor(entry.value),
          ),
      ],
    ),
  );

  Widget _section(String title, {String? subtitle}) => Padding(
    padding: const EdgeInsets.fromLTRB(24, 28, 24, 16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge),
        if (subtitle != null) ...[
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: muted)),
        ],
      ],
    ),
  );

  Widget _cards(List<MediaItem> items) => SizedBox(
    height: 254 + (MediaQuery.textScalerOf(context).scale(14) - 14) * 3,
    child: ListView.separated(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      itemCount: items.length,
      separatorBuilder: (_, index) => const SizedBox(width: 16),
      itemBuilder: (_, i) {
        final item = items[i];
        return SizedBox(
          width: 164,
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: c.loading ? null : () => _play(item, items),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    CoverArt(item: item, size: 164),
                    Positioned(
                      right: 10,
                      bottom: 10,
                      child: Container(
                        width: 34,
                        height: 34,
                        decoration: const BoxDecoration(
                          color: Color(0xDD101314),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.play_arrow_rounded,
                          color: accent,
                          size: 22,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  item.title,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 14,
                    height: 1.25,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 5),
                Text(
                  item.creator,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: muted, fontSize: 12),
                ),
              ],
            ),
          ),
        );
      },
    ),
  );

  Widget _row(
    MediaItem item,
    List<MediaItem> collection, {
    UserPlaylist? playlist,
  }) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 6),
    leading: CoverArt(item: item, size: 56),
    title: Text(
      item.title,
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        fontWeight: FontWeight.w600,
        color: c.current?.id == item.id ? accent : Colors.white,
      ),
    ),
    subtitle: Text(
      '${item.creator}${item.isLocal || c.library.downloads.containsKey(item.id) ? ' · Offline' : ''}',
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: const TextStyle(color: muted, fontSize: 12),
    ),
    onTap: c.loading ? null : () => _play(item, collection),
    trailing: PopupMenuButton<String>(
      tooltip: 'Track options',
      onSelected: (action) {
        if (action == 'like') c.toggleLike(item);
        if (action == 'add') _addToPlaylist(item);
        if (action == 'next') c.playNext(item);
        if (action == 'deleteItem') _deleteItem(item);
        if (action == 'remove' && playlist != null)
          c.removeFromPlaylist(playlist, item);
      },
      itemBuilder: (_) => [
        PopupMenuItem(
          value: 'like',
          child: Text(
            c.liked(item) ? 'Remove from favourites' : 'Add to favourites',
          ),
        ),
        const PopupMenuItem(value: 'add', child: Text('Add to playlist')),
        const PopupMenuItem(value: 'next', child: Text('Play next')),
        if (c.library.items.any((i) => i.id == item.id))
          const PopupMenuItem(
            value: 'deleteItem',
            child: Text('Remove from Sona'),
          ),
        if (playlist != null)
          const PopupMenuItem(
            value: 'remove',
            child: Text('Remove from playlist'),
          ),
      ],
    ),
  );

  Widget _search() {
    final normalized = query.trim().toLowerCase();
    final saved = c.catalog
        .where(
          (m) => '${m.title} ${m.creator}'.toLowerCase().contains(normalized),
        )
        .toList();
    return ListView(
      key: const PageStorageKey('search'),
      children: [
        _heading('YOUR NEXT FAVOURITE', 'Discover.'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: TextField(
            controller: search,
            textInputAction: TextInputAction.search,
            onChanged: (value) {
              setState(() => query = value);
              if (value.trim().isEmpty) unawaited(c.searchOnline(''));
            },
            onSubmitted: _searchFor,
            decoration: InputDecoration(
              hintText: 'Search songs or artists online',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(
                tooltip: 'Search online',
                icon: const Icon(Icons.arrow_forward),
                onPressed: () => _searchFor(search.text),
              ),
            ),
          ),
        ),
        if (normalized.isEmpty) ...[
          _section('Explore a mood'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children:
                  [
                        'Malayalam songs',
                        'Chill music',
                        'Focus music',
                        'Tamil songs',
                      ]
                      .map(
                        (q) => ActionChip(
                          label: Text(q),
                          onPressed: () => _searchFor(q),
                        ),
                      )
                      .toList(),
            ),
          ),
        ],
        if (c.onlineQuery.isNotEmpty)
          _section('YouTube results', subtitle: c.onlineQuery),
        if (c.searching)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator()),
          ),
        if (c.onlineError != null)
          _Empty(
            icon: Icons.cloud_off,
            title: 'Could not load songs',
            body: c.onlineError!,
            action: TextButton(
              onPressed: () => c.onlineResults.isEmpty
                  ? c.searchOnline(c.onlineQuery)
                  : c.moreOnline(),
              child: const Text('Retry'),
            ),
          ),
        if (!c.searching &&
            c.onlineError == null &&
            c.onlineQuery.isNotEmpty &&
            c.onlineResults.isEmpty)
          const _Empty(
            icon: Icons.search_off,
            title: 'No songs found',
            body: 'Try a different song or artist.',
          ),
        ...c.onlineResults.map((m) => _row(m, c.onlineResults)),
        if (c.canLoadMore)
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextButton(
              onPressed: c.loadingMore ? null : c.moreOnline,
              child: Text(c.loadingMore ? 'Loading…' : 'Load more'),
            ),
          ),
        if (saved.isNotEmpty) ...[
          _section('On your shelf'),
          ...saved.map((m) => _row(m, saved)),
        ],
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _library() => ListView(
    key: const PageStorageKey('library'),
    children: [
      _heading(
        'ALL YOUR GOOD FINDS',
        'Your library.',
        trailing: IconButton.filledTonal(
          tooltip: 'Create playlist',
          onPressed: _createPlaylist,
          icon: const Icon(Icons.add),
        ),
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            color: accent,
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Icon(Icons.favorite, color: Color(0xFF25311A)),
        ),
        title: const Text(
          'Favourites',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text('${c.likedItems.length} saved songs'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _collection('Favourites', () => c.likedItems),
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.audio_file, color: accent),
        title: const Text('Import music'),
        subtitle: const Text('Choose audio files from your phone'),
        onTap: c.libraryBusy ? null : c.importMusic,
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.link, color: accent),
        title: const Text('Add an audio link'),
        subtitle: const Text('Stream your hosted music directly in Sona'),
        onTap: _audioLink,
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.download_done, color: accent),
        title: const Text('Available offline'),
        subtitle: Text('${c.offlineItems.length} tracks on this device'),
        onTap: () => _collection('Available offline', () => c.offlineItems),
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.history, color: accent),
        title: const Text('Recently played'),
        onTap: () => _collection('Recently played', () => c.recentItems),
      ),
      _section('Your playlists'),
      if (c.library.playlists.isEmpty)
        _Empty(
          icon: Icons.queue_music,
          title: 'Make it your own',
          body:
              'Create a playlist, then use a track’s menu to add your favourites.',
          action: TextButton.icon(
            onPressed: _createPlaylist,
            icon: const Icon(Icons.add),
            label: const Text('Create playlist'),
          ),
        ),
      ...c.library.playlists.map(
        (p) => ListTile(
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 8,
          ),
          leading: Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: const Color(0xFF25292A),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.queue_music, color: accent),
          ),
          title: Text(p.name),
          subtitle: Text('${c.playlistItems(p).length} songs'),
          onTap: () =>
              _collection(p.name, () => c.playlistItems(p), playlist: p),
          trailing: PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'rename')
                _renamePlaylist(p);
              else
                _deletePlaylist(p);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'rename', child: Text('Rename')),
              PopupMenuItem(value: 'delete', child: Text('Delete')),
            ],
          ),
        ),
      ),
      const Divider(),
      ListTile(
        leading: const Icon(Icons.info_outline),
        title: const Text('About Sona'),
        subtitle: const Text('Version 4.1.0 · Your music, refined'),
        onTap: () => showAboutDialog(
          context: context,
          applicationName: 'Sona',
          applicationVersion: '4.1.0',
          applicationIcon: Image.asset(
            'branding/sona-icon.png',
            width: 48,
            height: 48,
          ),
          children: [
            const Text(
              'Online playback uses the YouTube extractor bundled with Musify. Sona is not affiliated with YouTube, Spotify or Musify.',
            ),
          ],
        ),
      ),
      ExpansionTile(
        title: const Text('Optional Spotify connection'),
        subtitle: const Text('Browse Spotify and control a Spotify device'),
        children: [
          ListTile(
            title: const Text('Open Spotify companion'),
            trailing: const Icon(Icons.open_in_new),
            onTap: _openSpotify,
          ),
          ListTile(
            title: const Text('Spotify playlist embed'),
            trailing: const Icon(Icons.open_in_new),
            onTap: c.loading ? null : _openSpotifyPlaylist,
          ),
        ],
      ),
      const Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'Your library lives on this device. Uninstalling Sona removes saved playlists and imported copies.',
          style: TextStyle(color: muted, fontSize: 12),
        ),
      ),
      const SizedBox(height: 24),
    ],
  );

  Future<void> _audioLink() async {
    var title = '', address = '';
    final values = await showDialog<List<String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add an audio link'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                onChanged: (v) => title = v,
                decoration: const InputDecoration(labelText: 'Track title'),
              ),
              const SizedBox(height: 12),
              TextField(
                onChanged: (v) => address = v,
                keyboardType: TextInputType.url,
                autocorrect: false,
                decoration: const InputDecoration(
                  labelText: 'Direct HTTPS audio URL',
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Use a direct audio file address from your own or licensed catalog. Spotify and YouTube page links are not audio files.',
                style: TextStyle(fontSize: 12),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, [title, address]),
            child: const Text('Add'),
          ),
        ],
      ),
    );
    if (values != null) await c.addAudioLink(values[0], values[1]);
  }

  Future<void> _deleteItem(MediaItem item) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove from Sona?'),
        content: Text(
          'Remove “${item.title}” and its saved copy from Sona? Your original phone file is kept.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
    if (yes == true) await c.removeItem(item);
  }

  Future<void> _renamePlaylist(UserPlaylist playlist) async {
    var name = playlist.name;
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename playlist'),
        content: TextFormField(
          initialValue: name,
          maxLength: 60,
          onChanged: (value) => name = value,
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (name.trim().isNotEmpty) Navigator.pop(ctx, name);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (result != null) c.renamePlaylist(playlist, result);
  }

  Future<void> _sleep() async {
    final minutes = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(title: Text('Sleep timer')),
            for (final n in [0, 15, 30, 45, 60])
              ListTile(
                title: Text(n == 0 ? 'Off' : '$n minutes'),
                onTap: () => Navigator.pop(ctx, n),
              ),
          ],
        ),
      ),
    );
    if (minutes != null) c.setSleepTimer(minutes);
  }

  Future<UserPlaylist?> _createPlaylist() async {
    String name = '';
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('A mix of your own'),
        content: TextField(
          autofocus: true,
          maxLength: 60,
          decoration: const InputDecoration(hintText: 'Playlist name'),
          onChanged: (value) => name = value,
          onSubmitted: (value) {
            if (value.trim().isNotEmpty) Navigator.pop(context, value);
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (name.trim().isNotEmpty) Navigator.pop(context, name);
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
    if (result == null || !mounted) return null;
    return c.createPlaylist(result);
  }

  Future<void> _deletePlaylist(UserPlaylist playlist) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete playlist?'),
        content: Text('Remove “${playlist.name}” from your library?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) c.deletePlaylist(playlist);
  }

  Future<void> _addToPlaylist(MediaItem item) async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.5,
          child: ListView(
            children: [
              const ListTile(
                title: Text(
                  'Add to playlist',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.add),
                title: const Text('New playlist'),
                onTap: () => Navigator.pop(context, 'new'),
              ),
              ...c.library.playlists.map(
                (p) => ListTile(
                  leading: const Icon(Icons.queue_music),
                  title: Text(p.name),
                  trailing: p.itemIds.contains(item.id)
                      ? const Icon(Icons.check, color: accent)
                      : null,
                  onTap: () => Navigator.pop(context, p.id),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (!mounted || selected == null) return;
    UserPlaylist? playlist;
    if (selected == 'new') {
      playlist = await _createPlaylist();
    } else {
      playlist = c.library.playlists.where((p) => p.id == selected).firstOrNull;
    }
    if (playlist == null || !mounted) return;
    c.addToPlaylist(playlist, item);
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('Added to ${playlist.name}')));
  }

  void _collection(
    String title,
    List<MediaItem> Function() items, {
    UserPlaylist? playlist,
  }) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.72,
          child: AnimatedBuilder(
            animation: c,
            builder: (context, _) {
              final collection = items();
              return ListView(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      title,
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                  ),
                  if (collection.isEmpty)
                    const _Empty(
                      icon: Icons.music_note,
                      title: 'Your next favourite is waiting',
                      body:
                          'Browse the collection and save something you love.',
                    ),
                  ...collection.map(
                    (m) => _row(m, collection, playlist: playlist),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  void _play(MediaItem item, List<MediaItem> collection) {
    unawaited(c.playItem(item, from: collection));
  }

  Widget _miniPlayer() {
    final item = c.current!;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
      child: Material(
        color: const Color(0xFF232A27),
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: _fullPlayer,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 4, 8),
                child: Row(
                  children: [
                    CoverArt(item: item, size: 44),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          Text(
                            c.playbackError != null
                                ? 'Playback unavailable · Tap for details'
                                : c.loading
                                ? 'Getting your song ready…'
                                : item.creator,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: muted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: c.liked(item)
                          ? 'Remove favourite'
                          : 'Save favourite',
                      onPressed: () => c.toggleLike(item),
                      icon: Icon(
                        c.liked(item) ? Icons.favorite : Icons.favorite_border,
                        color: c.liked(item) ? accent : Colors.white,
                        size: 21,
                      ),
                    ),
                    _playButton(compact: true),
                  ],
                ),
              ),
              StreamBuilder<Duration>(
                stream: c.player.positionStream,
                builder: (_, snapshot) {
                  final total = c.player.duration?.inMilliseconds ?? 0;
                  final position = snapshot.data?.inMilliseconds ?? 0;
                  return LinearProgressIndicator(
                    minHeight: 2,
                    value: total > 0
                        ? (position / total).clamp(0.0, 1.0).toDouble()
                        : 0,
                    backgroundColor: Colors.white12,
                    color: accent,
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  bool get _playing =>
      c.player.playing && c.player.processingState != ProcessingState.completed;

  Widget _playButton({bool compact = false}) => c.loading
      ? SizedBox(
          width: compact ? 48 : 76,
          height: compact ? 48 : 76,
          child: const Center(
            child: SizedBox.square(
              dimension: 24,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ),
        )
      : IconButton.filled(
          tooltip: _playing ? 'Pause' : 'Play',
          style: IconButton.styleFrom(
            backgroundColor: compact ? Colors.transparent : accent,
            foregroundColor: compact ? Colors.white : Colors.black,
            minimumSize: Size.square(compact ? 48 : 76),
          ),
          onPressed: c.togglePlayback,
          icon: Icon(
            _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
            size: compact ? 32 : 46,
          ),
        );

  Future<void> _openOnYoutube(MediaItem item) async {
    if (!item.isYoutube) return;
    final uri = Uri.https('www.youtube.com', '/watch', {
      'v': item.source.substring(8),
    });
    try {
      if (await launchUrl(uri, mode: LaunchMode.externalApplication)) return;
    } catch (_) {}
    if (mounted)
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open YouTube on this device.')),
      );
  }

  Widget _timeline() => StreamBuilder<Duration?>(
    stream: c.player.durationStream,
    builder: (_, durationSnapshot) => StreamBuilder<Duration>(
      stream: c.player.positionStream,
      builder: (_, positionSnapshot) {
        final unavailable = c.loading || c.playbackError != null;
        final duration = unavailable
            ? Duration.zero
            : durationSnapshot.data ?? c.player.duration ?? Duration.zero;
        final position = unavailable
            ? Duration.zero
            : positionSnapshot.data ?? c.player.position;
        final total = duration.inMilliseconds;
        return Column(
          children: [
            Slider(
              value: total > 0
                  ? position.inMilliseconds.clamp(0, total).toDouble()
                  : 0,
              max: total > 0 ? total.toDouble() : 1,
              onChanged: unavailable || total == 0
                  ? null
                  : (v) => c.seek(Duration(milliseconds: v.round())),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    clock(position),
                    style: const TextStyle(color: muted, fontSize: 12),
                  ),
                  Text(
                    total == 0 ? '—:—' : clock(duration),
                    style: const TextStyle(color: muted, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    ),
  );

  void _fullPlayer() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: const Color(0xFF131719),
      builder: (sheetContext) => AnimatedBuilder(
        animation: c,
        builder: (context, _) {
          final item = c.current;
          if (item == null) return const SizedBox.shrink();
          final artSize = (MediaQuery.sizeOf(context).height * .32).clamp(
            160.0,
            340.0,
          );
          return FractionallySizedBox(
            heightFactor: .98,
            child: SafeArea(
              child: DecoratedBox(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF25312B),
                      Color(0xFF131719),
                      Color(0xFF111315),
                    ],
                  ),
                ),
                child: Center(
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 520),
                    child: ListView(
                      padding: const EdgeInsets.fromLTRB(24, 10, 24, 24),
                      children: [
                        Row(
                          children: [
                            IconButton(
                              tooltip: 'Close player',
                              onPressed: () => Navigator.pop(sheetContext),
                              icon: const Icon(
                                Icons.keyboard_arrow_down_rounded,
                              ),
                            ),
                            const Expanded(
                              child: Column(
                                children: [
                                  Text(
                                    'NOW PLAYING',
                                    style: TextStyle(
                                      fontSize: 10,
                                      color: muted,
                                      letterSpacing: 2.4,
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    'Your moment',
                                    style: TextStyle(fontSize: 13),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              tooltip: 'Add to playlist',
                              onPressed: () => _addToPlaylist(item),
                              icon: const Icon(Icons.playlist_add_rounded),
                            ),
                          ],
                        ),
                        const SizedBox(height: 22),
                        LayoutBuilder(
                          builder: (_, bounds) => Center(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(22),
                                boxShadow: const [
                                  BoxShadow(
                                    color: Color(0x66000000),
                                    blurRadius: 38,
                                    offset: Offset(0, 18),
                                  ),
                                ],
                              ),
                              child: CoverArt(
                                item: item,
                                size: artSize
                                    .clamp(0, bounds.maxWidth)
                                    .toDouble(),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 26),
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Tooltip(
                                    message: item.title,
                                    child: Text(
                                      item.title,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        fontSize: 23,
                                        height: 1.2,
                                        letterSpacing: -.5,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 7),
                                  Text(
                                    item.creator,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: muted,
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            IconButton(
                              tooltip: c.liked(item)
                                  ? 'Remove favourite'
                                  : 'Save favourite',
                              onPressed: () => c.toggleLike(item),
                              icon: Icon(
                                c.liked(item)
                                    ? Icons.favorite
                                    : Icons.favorite_border,
                                color: c.liked(item) ? accent : Colors.white,
                                size: 26,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        if (c.loading)
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 8),
                            child: Text(
                              'Getting your song ready…',
                              style: TextStyle(color: muted, fontSize: 12),
                            ),
                          ),
                        _timeline(),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                              tooltip: 'Shuffle',
                              isSelected: c.shuffle,
                              onPressed: c.toggleShuffle,
                              icon: Icon(
                                Icons.shuffle_rounded,
                                color: c.shuffle ? accent : muted,
                                size: 21,
                              ),
                            ),
                            IconButton(
                              tooltip: 'Previous song',
                              onPressed: c.loading ? null : c.previous,
                              icon: const Icon(
                                Icons.skip_previous_rounded,
                                size: 32,
                              ),
                            ),
                            _playButton(),
                            IconButton(
                              tooltip: 'Next song',
                              onPressed: c.loading ? null : () => c.next(),
                              icon: const Icon(
                                Icons.skip_next_rounded,
                                size: 32,
                              ),
                            ),
                            IconButton(
                              tooltip: 'Repeat song',
                              isSelected: c.repeat,
                              onPressed: c.toggleRepeat,
                              icon: Icon(
                                Icons.repeat_one_rounded,
                                color: c.repeat ? accent : muted,
                                size: 21,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Wrap(
                          alignment: WrapAlignment.spaceBetween,
                          spacing: 12,
                          children: [
                            TextButton.icon(
                              onPressed: _sleep,
                              icon: const Icon(
                                Icons.bedtime_outlined,
                                size: 18,
                              ),
                              label: Text(
                                c.sleepUntil == null
                                    ? 'Sleep timer'
                                    : 'Timer on',
                              ),
                            ),
                            TextButton.icon(
                              onPressed: () =>
                                  _collection('Up next', () => c.queue),
                              icon: const Icon(Icons.queue_music, size: 20),
                              label: const Text('Queue'),
                            ),
                          ],
                        ),
                        if (c.playbackError != null)
                          Container(
                            margin: const EdgeInsets.only(top: 16),
                            padding: const EdgeInsets.all(16),
                            decoration: BoxDecoration(
                              color: const Color(0xFF30291F),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'Playback unavailable',
                                  style: TextStyle(
                                    color: Color(0xFFEBC58E),
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  c.playbackError!,
                                  style: const TextStyle(
                                    color: Color(0xFFD2C3AD),
                                    fontSize: 13,
                                  ),
                                ),
                                if (item.isYoutube)
                                  TextButton.icon(
                                    onPressed: () => _openOnYoutube(item),
                                    icon: const Icon(
                                      Icons.open_in_new,
                                      size: 16,
                                    ),
                                    label: const Text('Open in YouTube'),
                                  ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({
    required this.icon,
    required this.title,
    required this.body,
    this.action,
  });
  final IconData icon;
  final String title;
  final String body;
  final Widget? action;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(30),
    child: Column(
      children: [
        Icon(icon, size: 44, color: accent),
        const SizedBox(height: 16),
        Text(
          title,
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 8),
        Text(
          body,
          textAlign: TextAlign.center,
          style: const TextStyle(color: muted),
        ),
        if (action != null) ...[const SizedBox(height: 12), action!],
      ],
    ),
  );
}
