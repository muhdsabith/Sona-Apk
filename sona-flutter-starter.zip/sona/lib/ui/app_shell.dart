import 'dart:async';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import '../controllers/app_controller.dart';
import '../models/media_item.dart';
import 'cover_art.dart';
import 'olam_theme.dart';
import 'wave_track.dart';
import '../controllers/last_fm_controller.dart';
import '../models/track_model.dart';
import 'last_fm_widgets.dart';
import 'youtube_player_screen.dart';
import 'spotify_companion_screen.dart';
import 'spotify_playlist_screen.dart';
import 'package:url_launcher/url_launcher.dart';

String clock(Duration value) {
  final minutes = value.inMinutes.toString();
  final seconds = (value.inSeconds % 60).toString().padLeft(2, '0');
  return '$minutes:$seconds';
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.controller});
  final AppController controller;
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> with WidgetsBindingObserver {
  int tab = 0;
  final charts = LastFmController();
  bool _openingOnline = false;
  int homeFilter = 0;
  String sortOrder = 'recommended';
  String query = '';
  final search = TextEditingController();
  @override
  void initState() {
    super.initState();
    unawaited(charts.initialize());
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    unawaited(c.setForeground(state == AppLifecycleState.resumed));
  }

  void _searchFor(String value) {
    search.text = value;
    setState(() {
      query = value;
      tab = 1;
    });
    unawaited(c.searchOnline(value));
  }

  AppController get c => widget.controller;

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    search.dispose();
    charts.dispose();
    super.dispose();
  }

  Future<void> _openSpotify() async {
    try {
      await c.pause();
    } catch (_) {}
    if (!mounted) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => const SpotifyCompanionScreen()),
    );
  }

  Future<void> _openSpotifyPlaylist() async {
    if (c.loading) return;
    try {
      await c.pause();
    } catch (_) {}
    if (!mounted) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => const SpotifyPlaylistScreen()),
    );
  }

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: Listenable.merge([c, charts]),
    builder: (context, _) => Scaffold(
      body: SafeArea(
        bottom: false,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 760),
            child: Column(
              children: [
                if (c.error != null && c.playbackError == null)
                  MaterialBanner(
                    content: Text(c.error!),
                    actions: [
                      TextButton(
                        onPressed: c.clearError,
                        child: const Text('Dismiss'),
                      ),
                    ],
                  ),
                if (c.libraryBusy) const LinearProgressIndicator(minHeight: 2),
                Expanded(
                  child: !c.initialized
                      ? const Center(child: CircularProgressIndicator())
                      : IndexedStack(
                          index: tab,
                          children: [
                            _home(),
                            _search(),
                            _chartsPage(),
                            _library(),
                            _settingsPage(),
                          ],
                        ),
                ),
                if (c.current != null) _miniPlayer(),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        minimum: const EdgeInsets.fromLTRB(18, 8, 18, 12),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(32),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xEB33313D), Color(0xEB22212B)],
                ),
                borderRadius: BorderRadius.circular(32),
                border: Border.all(color: hairline),
              ),
              child: NavigationBar(
                backgroundColor: Colors.transparent,
                height: 72,
                selectedIndex: tab,
                onDestinationSelected: (value) => setState(() => tab = value),
                destinations: const [
                  NavigationDestination(
                    icon: Icon(Icons.home_outlined),
                    selectedIcon: Icon(Icons.home_rounded),
                    label: 'Home',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.search_rounded),
                    label: 'Search',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.bar_chart_rounded),
                    label: 'Charts',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.library_music_outlined),
                    selectedIcon: Icon(Icons.library_music),
                    label: 'Library',
                  ),
                  NavigationDestination(
                    icon: Icon(Icons.settings_outlined),
                    label: 'Settings',
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    ),
  );

  Widget _heading(String eyebrow, String title, {Widget? trailing}) => Padding(
    padding: const EdgeInsets.fromLTRB(24, 24, 24, 18),
    child: Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                eyebrow,
                style: const TextStyle(
                  color: muted,
                  fontSize: 11,
                  letterSpacing: 2.4,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 8),
              Text(title, style: Theme.of(context).textTheme.headlineLarge),
            ],
          ),
        ),
        if (trailing != null) trailing,
      ],
    ),
  );

  List<MediaItem> get _frontTracks {
    Iterable<MediaItem> items;
    if (homeFilter == 4) {
      items = c.offlineItems;
    } else if (homeFilter > 0) {
      final key = AppController.homeQueries.keys.elementAt(homeFilter - 1);
      items = c.homeSongs[key] ?? [];
    } else {
      items = [
        ...c.recentItems,
        ...c.homeSongs.values.expand((songs) => songs),
      ];
    }
    final ids = <String>{};
    final tracks = items.where((item) => ids.add(item.id)).toList();
    if (sortOrder == 'title')
      tracks.sort(
        (a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()),
      );
    if (sortOrder == 'artist')
      tracks.sort(
        (a, b) => a.creator.toLowerCase().compareTo(b.creator.toLowerCase()),
      );
    return tracks;
  }

  Widget _home() {
    final tracks = _frontTracks;
    return RefreshIndicator(
      onRefresh: () => c.loadHome(useCache: false),
      child: ListView(
        key: const PageStorageKey('tracks'),
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 22, 24, 0),
            child: Row(
              children: [
                ClipOval(
                  child: Image.asset(
                    'branding/olam-icon.png',
                    width: 48,
                    height: 48,
                  ),
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text(
                    'OLAM',
                    style: TextStyle(
                      letterSpacing: 3,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                IconButton.filledTonal(
                  tooltip: 'Search',
                  onPressed: () => setState(() => tab = 1),
                  icon: const Icon(Icons.search),
                ),
                const SizedBox(width: 6),
                IconButton.filledTonal(
                  tooltip: 'Favourites',
                  onPressed: () =>
                      _collection('Favourites', () => c.likedItems),
                  icon: const Icon(Icons.favorite_border),
                ),
              ],
            ),
          ),
          _heading('A LITTLE MUSIC, JUST FOR YOU', 'Hello, music lover.'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Material(
              color: paper,
              borderRadius: BorderRadius.circular(28),
              child: InkWell(
                borderRadius: BorderRadius.circular(28),
                onTap: () => setState(() => tab = 1),
                child: const Padding(
                  padding: EdgeInsets.all(18),
                  child: Row(
                    children: [
                      Icon(Icons.search_rounded, color: accent),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Songs, artists and favourites',
                          style: TextStyle(color: muted),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              children: [
                for (final entry in [
                  'For you',
                  'Malayalam',
                  'Tamil',
                  'English',
                  'On device',
                ].asMap().entries)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(
                        entry.value,
                        style: TextStyle(
                          color: homeFilter == entry.key ? cream : ink,
                        ),
                      ),
                      selected: homeFilter == entry.key,
                      showCheckmark: false,
                      onSelected: (_) => setState(() => homeFilter = entry.key),
                    ),
                  ),
              ],
            ),
          ),
          _section('Curated & trending'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: FeatureCard(
              title: 'Discover the charts',
              subtitle: 'Explore the songs listeners love. Powered by Last.fm.',
              icon: Icons.auto_awesome_rounded,
              onTap: () => setState(() => tab = 2),
            ),
          ),
          if (charts.tracks.isNotEmpty) ...[
            _section(
              'Top tracks on Last.fm',
              subtitle: 'Tap a track to find it on YouTube',
            ),
            ...charts.tracks
                .take(3)
                .toList()
                .asMap()
                .entries
                .map((entry) => _chartTile(entry.value, entry.key + 1)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: () => setState(() => tab = 2),
                  child: const Text('See all charts'),
                ),
              ),
            ),
          ],
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 12, 16, 0),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    homeFilter == 4
                        ? '${tracks.length} local songs'
                        : '${tracks.length} songs to explore',
                    style: const TextStyle(color: muted, fontSize: 12),
                  ),
                ),
                PopupMenuButton<String>(
                  tooltip: 'Sort songs',
                  initialValue: sortOrder,
                  onSelected: (value) => setState(() => sortOrder = value),
                  icon: const Icon(Icons.sort_rounded, size: 21),
                  itemBuilder: (_) => const [
                    PopupMenuItem(
                      value: 'recommended',
                      child: Text('Original order'),
                    ),
                    PopupMenuItem(value: 'title', child: Text('Song title')),
                    PopupMenuItem(value: 'artist', child: Text('Artist')),
                  ],
                ),
              ],
            ),
          ),
          if (c.homeLoading.isNotEmpty && homeFilter != 4)
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 24),
              child: LinearProgressIndicator(minHeight: 1),
            ),
          if (tracks.isEmpty && (homeFilter == 4 || c.homeLoading.isEmpty))
            _Empty(
              icon: Icons.music_note_outlined,
              title: homeFilter == 4
                  ? 'Bring your music along'
                  : 'Find your next favourite',
              body: homeFilter == 4
                  ? 'Import audio from your phone to listen offline.'
                  : 'Search for a song or pull down to refresh.',
              action: TextButton(
                onPressed: homeFilter == 4
                    ? (c.libraryBusy ? null : c.importMusic)
                    : () => setState(() => tab = 1),
                child: Text(homeFilter == 4 ? 'Import music' : 'Search music'),
              ),
            ),
          if (tracks.isNotEmpty) ...[
            _section(homeFilter == 4 ? 'Your music' : 'Discover on YouTube'),
            _musicCards(tracks.take(8).toList(), tracks),
            _section('All tracks'),
          ],
          ...tracks.map((item) => _row(item, tracks)),
          if (c.homeErrors.isNotEmpty && homeFilter != 4)
            Padding(
              padding: const EdgeInsets.all(24),
              child: Text(
                'Some discoveries could not refresh. Your saved results are still here. Pull down to try again.',
                style: const TextStyle(color: muted, fontSize: 12),
              ),
            ),
          _backgroundCard(),
          const SizedBox(height: 18),
          const Center(
            child: Text(
              'LET THE MUSIC FLOW',
              style: TextStyle(color: muted, fontSize: 9, letterSpacing: 2.4),
            ),
          ),
        ],
      ),
    );
  }

  Widget _backgroundCard() => Container(
    margin: const EdgeInsets.fromLTRB(24, 24, 24, 0),
    padding: const EdgeInsets.all(22),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(28),
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF292532), Color(0xFF17161E)],
      ),
      border: Border.all(color: const Color(0xFF494252)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Icon(Icons.headphones_rounded, color: accent),
            SizedBox(width: 10),
            Expanded(
              child: Text(
                'YOUR MUSIC. ANYWHERE.',
                style: TextStyle(
                  color: accent,
                  fontSize: 11,
                  letterSpacing: 1.4,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 14),
        const Text(
          'Screen off. Music on.',
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.w700,
            height: 1.15,
          ),
        ),
        const SizedBox(height: 10),
        const Text(
          'Import your songs or add a direct audio link for background listening and lock-screen controls.',
          style: TextStyle(color: ink, height: 1.5),
        ),
        const SizedBox(height: 16),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            FilledButton.icon(
              onPressed: c.libraryBusy ? null : c.importMusic,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Import songs'),
            ),
            OutlinedButton(
              onPressed: _audioLink,
              child: const Text('Add audio link'),
            ),
            if (c.catalog.any((item) => !item.isYoutube))
              TextButton(
                onPressed: () => _collection(
                  'Background listening',
                  () => c.catalog.where((item) => !item.isYoutube).toList(),
                ),
                child: const Text('Play my music'),
              ),
          ],
        ),
        const SizedBox(height: 10),
        const Text(
          'YouTube videos play while their screen is open.',
          style: TextStyle(color: muted, fontSize: 12),
        ),
      ],
    ),
  );

  Widget _musicCards(
    List<MediaItem> items,
    List<MediaItem> collection,
  ) => SingleChildScrollView(
    scrollDirection: Axis.horizontal,
    padding: const EdgeInsets.symmetric(horizontal: 24),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final item in items)
          Padding(
            padding: const EdgeInsets.only(right: 14),
            child: SizedBox(
              width: 174,
              child: Material(
                color: paper,
                borderRadius: BorderRadius.circular(26),
                clipBehavior: Clip.antiAlias,
                child: InkWell(
                  onTap: c.loading ? null : () => _play(item, collection),
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        CoverArt(item: item, size: 154),
                        const SizedBox(height: 12),
                        Text(
                          item.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          item.creator,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: muted, fontSize: 12),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Icon(
                              item.isYoutube
                                  ? Icons.smart_display_outlined
                                  : Icons.headphones_rounded,
                              size: 14,
                              color: accent,
                            ),
                            const SizedBox(width: 6),
                            Text(
                              item.isYoutube ? 'YouTube' : 'Background play',
                              style: const TextStyle(
                                color: accent,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    ),
  );

  Future<void> _editLastFmKey() async {
    var value = '';
    final key = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Last.fm API key'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Paste your API key to show top tracks. No API secret or Last.fm password is needed. The key is saved on this device.',
              ),
              const SizedBox(height: 18),
              TextField(
                obscureText: true,
                autocorrect: false,
                enableSuggestions: false,
                onChanged: (text) => value = text,
                decoration: const InputDecoration(
                  labelText: 'API key',
                  hintText: 'Paste your key',
                ),
              ),
              const SizedBox(height: 10),
              TextButton(
                onPressed: () =>
                    _openWeb('https://www.last.fm/api/account/create'),
                child: const Text('Get a Last.fm API key'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          if (charts.configured)
            TextButton(
              onPressed: () => Navigator.pop(ctx, ''),
              child: const Text('Remove key'),
            ),
          FilledButton(
            onPressed: () {
              if (value.trim().isNotEmpty) Navigator.pop(ctx, value.trim());
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (key == null || !mounted) return;
    final saved = await charts.saveKey(key);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          saved
              ? (key.isEmpty ? 'Last.fm key removed.' : 'Last.fm key saved.')
              : 'Could not save your key.',
        ),
      ),
    );
  }

  Future<void> _openWeb(String address) async {
    final uri = Uri.tryParse(address);
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) return;
    try {
      if (await launchUrl(uri, mode: LaunchMode.externalApplication)) return;
    } catch (_) {}
    if (mounted)
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open this link.')),
      );
  }

  Widget _chartTile(Track track, int rank) => ChartTrackTile(
    track: track,
    rank: rank,
    onSearch: () => _searchFor('${track.name} ${track.artistName}'),
    onOpen: () => _openWeb(track.url),
  );

  Widget _chartsPage() => RefreshIndicator(
    onRefresh: () => charts.load(force: true),
    child: ListView(
      key: const PageStorageKey('charts'),
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.only(bottom: 28),
      children: [
        _heading(
          'POWERED BY LAST.FM',
          'The charts',
          trailing: IconButton(
            tooltip: 'Refresh charts',
            onPressed: charts.loading || !charts.configured
                ? null
                : () => charts.load(force: true),
            icon: const Icon(Icons.refresh_rounded),
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 24),
          child: Text(
            'Global top tracks. Tap a song to search for a playable version on YouTube.',
            style: TextStyle(color: muted),
          ),
        ),
        const SizedBox(height: 20),
        if (!charts.ready || charts.loading)
          const LinearProgressIndicator(minHeight: 2),
        if (charts.ready && !charts.configured)
          Padding(
            padding: const EdgeInsets.all(24),
            child: FeatureCard(
              title: 'Your next favourite awaits',
              subtitle:
                  'Add your Last.fm API key to bring real chart discoveries here.',
              icon: Icons.insights_rounded,
              onTap: () {
                if (!charts.saving) _editLastFmKey();
              },
            ),
          ),
        if (charts.error != null)
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(charts.error!),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  children: [
                    TextButton(
                      onPressed: _editLastFmKey,
                      child: const Text('Check API key'),
                    ),
                    TextButton(
                      onPressed: charts.loading
                          ? null
                          : () => charts.load(force: true),
                      child: const Text('Retry'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        if (charts.ready &&
            charts.configured &&
            !charts.loading &&
            charts.error == null &&
            charts.tracks.isEmpty)
          const _Empty(
            icon: Icons.music_note_outlined,
            title: 'No chart tracks yet',
            body: 'Pull down to refresh later.',
          ),
        ...charts.tracks.asMap().entries.map(
          (entry) => _chartTile(entry.value, entry.key + 1),
        ),
        Padding(
          padding: const EdgeInsets.all(24),
          child: TextButton.icon(
            onPressed: () => _openWeb('https://www.last.fm/charts'),
            icon: const Icon(Icons.open_in_new, size: 16),
            label: const Text('Explore Last.fm'),
          ),
        ),
      ],
    ),
  );

  Widget _settingsPage() => ListView(
    key: const PageStorageKey('settings'),
    padding: const EdgeInsets.only(bottom: 28),
    children: [
      _heading('MAKE YOURSELF AT HOME', 'Settings'),
      _section('Music discovery'),
      ListTile(
        leading: const Icon(Icons.insights_rounded),
        title: const Text('Last.fm API key'),
        subtitle: Text(
          charts.configured
              ? 'Key saved · Tap to replace or remove'
              : 'Set up top tracks and charts',
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: () {
          if (!charts.saving) _editLastFmKey();
        },
      ),
      ListTile(
        leading: const Icon(Icons.refresh_rounded),
        title: const Text('Refresh YouTube discoveries'),
        subtitle: const Text('Update the songs on Home'),
        onTap: c.homeLoading.isEmpty ? () => c.loadHome(useCache: false) : null,
      ),
      _section('Your music'),
      ListTile(
        leading: const Icon(Icons.audio_file_outlined),
        title: const Text('Import songs'),
        subtitle: const Text('Audio files from your phone'),
        onTap: c.libraryBusy ? null : c.importMusic,
      ),
      ListTile(
        leading: const Icon(Icons.link_rounded),
        title: const Text('Add a direct audio link'),
        subtitle: const Text('For your own or licensed music'),
        onTap: _audioLink,
      ),
      const Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'Imported songs and direct audio streams support background listening and lock-screen controls. YouTube videos need the player screen open.',
          style: TextStyle(color: muted, height: 1.5),
        ),
      ),
      _section('Connections'),
      ListTile(
        leading: const Icon(Icons.speaker_group_outlined),
        title: const Text('Spotify companion'),
        subtitle: const Text('Control playback on your Spotify device'),
        trailing: const Icon(Icons.chevron_right),
        onTap: _openSpotify,
      ),
      ListTile(
        leading: const Icon(Icons.playlist_play_rounded),
        title: const Text('Spotify playlist'),
        trailing: const Icon(Icons.chevron_right),
        onTap: _openSpotifyPlaylist,
      ),
      _section('About'),
      const ListTile(
        leading: Icon(Icons.waves_rounded),
        title: Text('Olam 4.5.0'),
        subtitle: Text('Let the music flow.'),
      ),
      const Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'Your library and API settings live on this device. Uninstalling removes saved playlists and imported copies. Chart metadata is provided by Last.fm; it does not supply audio files.',
          style: TextStyle(color: muted, fontSize: 12),
        ),
      ),
    ],
  );

  Widget _section(String title, {String? subtitle}) => Padding(
    padding: const EdgeInsets.fromLTRB(24, 28, 24, 16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleLarge),
        if (subtitle != null) ...[
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: muted)),
        ],
      ],
    ),
  );

  Widget _row(
    MediaItem item,
    List<MediaItem> collection, {
    UserPlaylist? playlist,
  }) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
    child: Material(
      color: paper,
      borderRadius: BorderRadius.circular(22),
      clipBehavior: Clip.antiAlias,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        leading: CoverArt(item: item, size: 46),
        title: Text(
          item.title,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: c.current?.id == item.id ? accent : ink,
          ),
        ),
        subtitle: Text(
          '${item.creator}${item.isLocal || c.library.downloads.containsKey(item.id)
              ? ' · Offline'
              : item.isYoutube
              ? ' · YouTube'
              : ' · Background play'}',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: muted, fontSize: 12),
        ),
        onTap: c.loading ? null : () => _play(item, collection),
        trailing: PopupMenuButton<String>(
          tooltip: 'Track options',
          onSelected: (action) {
            if (action == 'like') c.toggleLike(item);
            if (action == 'add') _addToPlaylist(item);
            if (action == 'next') c.playNext(item);
            if (action == 'deleteItem') _deleteItem(item);
            if (action == 'remove' && playlist != null)
              c.removeFromPlaylist(playlist, item);
          },
          itemBuilder: (_) => [
            PopupMenuItem(
              value: 'like',
              child: Text(
                c.liked(item) ? 'Remove from favourites' : 'Add to favourites',
              ),
            ),
            const PopupMenuItem(value: 'add', child: Text('Add to playlist')),
            if (!item.isYoutube)
              const PopupMenuItem(value: 'next', child: Text('Play next')),
            if (c.library.items.any((i) => i.id == item.id))
              const PopupMenuItem(
                value: 'deleteItem',
                child: Text('Remove from Olam'),
              ),
            if (playlist != null)
              const PopupMenuItem(
                value: 'remove',
                child: Text('Remove from playlist'),
              ),
          ],
        ),
      ),
    ),
  );

  Widget _search() {
    final normalized = query.trim().toLowerCase();
    final saved = c.catalog
        .where(
          (m) => '${m.title} ${m.creator}'.toLowerCase().contains(normalized),
        )
        .toList();
    return ListView(
      key: const PageStorageKey('search'),
      children: [
        _heading('FIND YOUR FREQUENCY', 'Search'),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: TextField(
            controller: search,
            textInputAction: TextInputAction.search,
            onChanged: (value) {
              setState(() => query = value);
              if (value.trim().isEmpty) unawaited(c.searchOnline(''));
            },
            onSubmitted: _searchFor,
            decoration: InputDecoration(
              hintText: 'Search songs or artists online',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: IconButton(
                tooltip: 'Search online',
                icon: const Icon(Icons.arrow_forward),
                onPressed: () => _searchFor(search.text),
              ),
            ),
          ),
        ),
        if (normalized.isEmpty) ...[
          _section('Pick your mood'),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: LayoutBuilder(
              builder: (_, bounds) {
                final columns = bounds.maxWidth < 280 ? 1 : 2;
                final width = (bounds.maxWidth - (columns - 1) * 12) / columns;
                final moods = <(String, String, Color, IconData)>[
                  (
                    'Malayalam',
                    'Malayalam songs',
                    lavender,
                    Icons.waves_rounded,
                  ),
                  (
                    'Slow down',
                    'Chill music',
                    accent,
                    Icons.nights_stay_outlined,
                  ),
                  (
                    'Deep focus',
                    'Focus music',
                    const Color(0xFFA9B8EE),
                    Icons.graphic_eq_rounded,
                  ),
                  (
                    'Tamil',
                    'Tamil songs',
                    const Color(0xFFF0B6A5),
                    Icons.music_note_rounded,
                  ),
                ];
                return Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    for (final mood in moods)
                      SizedBox(
                        width: width,
                        child: Material(
                          color: mood.$3,
                          borderRadius: BorderRadius.circular(24),
                          clipBehavior: Clip.antiAlias,
                          child: InkWell(
                            onTap: () => _searchFor(mood.$2),
                            child: Padding(
                              padding: const EdgeInsets.all(18),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Icon(mood.$4, color: cream, size: 28),
                                  const SizedBox(height: 22),
                                  Text(
                                    mood.$1,
                                    style: const TextStyle(
                                      color: cream,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 17,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
        ],
        if (c.onlineQuery.isNotEmpty)
          _section('YouTube results', subtitle: c.onlineQuery),
        if (c.searching)
          const Padding(
            padding: EdgeInsets.all(24),
            child: Center(child: CircularProgressIndicator()),
          ),
        if (c.onlineError != null)
          _Empty(
            icon: Icons.cloud_off,
            title: 'Could not load songs',
            body: c.onlineError!,
            action: TextButton(
              onPressed: () => c.onlineResults.isEmpty
                  ? c.searchOnline(c.onlineQuery)
                  : c.moreOnline(),
              child: const Text('Retry'),
            ),
          ),
        if (!c.searching &&
            c.onlineError == null &&
            c.onlineQuery.isNotEmpty &&
            c.onlineResults.isEmpty)
          const _Empty(
            icon: Icons.search_off,
            title: 'No songs found',
            body: 'Try a different song or artist.',
          ),
        ...c.onlineResults.map((m) => _row(m, c.onlineResults)),
        if (c.canLoadMore)
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextButton(
              onPressed: c.loadingMore ? null : c.moreOnline,
              child: Text(c.loadingMore ? 'Loading…' : 'Load more'),
            ),
          ),
        if (saved.isNotEmpty) ...[
          _section('On your shelf'),
          ...saved.map((m) => _row(m, saved)),
        ],
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _library() => ListView(
    key: const PageStorageKey('library'),
    children: [
      _heading(
        'YOUR PERSONAL COLLECTION',
        'Saved & loved',
        trailing: IconButton.filledTonal(
          tooltip: 'Create playlist',
          onPressed: _createPlaylist,
          icon: const Icon(Icons.add),
        ),
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            color: accent,
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Icon(Icons.favorite, color: cream),
        ),
        title: const Text(
          'Favourites',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text('${c.likedItems.length} saved songs'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _collection('Favourites', () => c.likedItems),
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.audio_file, color: accent),
        title: const Text('Import music'),
        subtitle: const Text(
          'Play with the screen off and use lock-screen controls',
        ),
        onTap: c.libraryBusy ? null : c.importMusic,
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.link, color: accent),
        title: const Text('Add an audio link'),
        subtitle: const Text(
          'Direct audio streams support background listening',
        ),
        onTap: _audioLink,
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.download_done, color: accent),
        title: const Text('Available offline'),
        subtitle: Text('${c.offlineItems.length} tracks on this device'),
        onTap: () => _collection('Available offline', () => c.offlineItems),
      ),
      ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        leading: const Icon(Icons.history, color: accent),
        title: const Text('Recently played'),
        onTap: () => _collection('Recently played', () => c.recentItems),
      ),
      _section(
        'Made by you',
        subtitle: 'Playlists for every version of your day',
      ),
      if (c.library.playlists.isEmpty)
        _Empty(
          icon: Icons.queue_music,
          title: 'Make it your own',
          body:
              'Create a playlist, then use a track’s menu to add your favourites.',
          action: TextButton.icon(
            onPressed: _createPlaylist,
            icon: const Icon(Icons.add),
            label: const Text('Create playlist'),
          ),
        ),
      ...c.library.playlists.map(
        (p) => ListTile(
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 24,
            vertical: 8,
          ),
          leading: Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              color: paper,
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.queue_music, color: accent),
          ),
          title: Text(p.name),
          subtitle: Text('${c.playlistItems(p).length} songs'),
          onTap: () =>
              _collection(p.name, () => c.playlistItems(p), playlist: p),
          trailing: PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'rename')
                _renamePlaylist(p);
              else
                _deletePlaylist(p);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'rename', child: Text('Rename')),
              PopupMenuItem(value: 'delete', child: Text('Delete')),
            ],
          ),
        ),
      ),
      const Divider(),
      ListTile(
        leading: const Icon(Icons.info_outline),
        title: const Text('About Olam'),
        subtitle: const Text('Version 4.5.0 · Let the music flow'),
        onTap: () => showAboutDialog(
          context: context,
          applicationName: 'Olam',
          applicationVersion: '4.5.0',
          applicationIcon: Image.asset(
            'branding/olam-icon.png',
            width: 48,
            height: 48,
          ),
          children: [
            const Text(
              'Online video playback uses the official YouTube embedded player. Search uses the extractor bundled with Musify. Olam is an independent app.',
            ),
          ],
        ),
      ),
      ExpansionTile(
        title: const Text('Optional Spotify connection'),
        subtitle: const Text('Browse Spotify and control a Spotify device'),
        children: [
          ListTile(
            title: const Text('Open Spotify companion'),
            trailing: const Icon(Icons.open_in_new),
            onTap: _openSpotify,
          ),
          ListTile(
            title: const Text('Spotify playlist embed'),
            trailing: const Icon(Icons.open_in_new),
            onTap: c.loading ? null : _openSpotifyPlaylist,
          ),
        ],
      ),
      const Padding(
        padding: EdgeInsets.all(24),
        child: Text(
          'Your library lives on this device. Uninstalling Olam removes saved playlists and imported copies.',
          style: TextStyle(color: muted, fontSize: 12),
        ),
      ),
      const SizedBox(height: 24),
    ],
  );

  Future<void> _audioLink() async {
    var title = '', address = '';
    final values = await showDialog<List<String>>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add an audio link'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                onChanged: (v) => title = v,
                decoration: const InputDecoration(labelText: 'Track title'),
              ),
              const SizedBox(height: 12),
              TextField(
                onChanged: (v) => address = v,
                keyboardType: TextInputType.url,
                autocorrect: false,
                decoration: const InputDecoration(
                  labelText: 'Direct HTTPS audio URL',
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Use a direct audio file address from your own or licensed catalog. Spotify and YouTube page links are not audio files.',
                style: TextStyle(fontSize: 12),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, [title, address]),
            child: const Text('Add'),
          ),
        ],
      ),
    );
    if (values != null) await c.addAudioLink(values[0], values[1]);
  }

  Future<void> _deleteItem(MediaItem item) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove from Olam?'),
        content: Text(
          'Remove “${item.title}” and its saved copy from Olam? Your original phone file is kept.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
    if (yes == true) await c.removeItem(item);
  }

  Future<void> _renamePlaylist(UserPlaylist playlist) async {
    var name = playlist.name;
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Rename playlist'),
        content: TextFormField(
          initialValue: name,
          maxLength: 60,
          onChanged: (value) => name = value,
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (name.trim().isNotEmpty) Navigator.pop(ctx, name);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (result != null) c.renamePlaylist(playlist, result);
  }

  Future<void> _sleep() async {
    final minutes = await showModalBottomSheet<int>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const ListTile(title: Text('Sleep timer')),
            for (final n in [0, 15, 30, 45, 60])
              ListTile(
                title: Text(n == 0 ? 'Off' : '$n minutes'),
                onTap: () => Navigator.pop(ctx, n),
              ),
          ],
        ),
      ),
    );
    if (minutes != null) c.setSleepTimer(minutes);
  }

  Future<UserPlaylist?> _createPlaylist() async {
    String name = '';
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('A mix of your own'),
        content: TextField(
          autofocus: true,
          maxLength: 60,
          decoration: const InputDecoration(hintText: 'Playlist name'),
          onChanged: (value) => name = value,
          onSubmitted: (value) {
            if (value.trim().isNotEmpty) Navigator.pop(context, value);
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              if (name.trim().isNotEmpty) Navigator.pop(context, name);
            },
            child: const Text('Create'),
          ),
        ],
      ),
    );
    if (result == null || !mounted) return null;
    return c.createPlaylist(result);
  }

  Future<void> _deletePlaylist(UserPlaylist playlist) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete playlist?'),
        content: Text('Remove “${playlist.name}” from your library?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) c.deletePlaylist(playlist);
  }

  Future<void> _addToPlaylist(MediaItem item) async {
    final selected = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.5,
          child: ListView(
            children: [
              const ListTile(
                title: Text(
                  'Add to playlist',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.add),
                title: const Text('New playlist'),
                onTap: () => Navigator.pop(context, 'new'),
              ),
              ...c.library.playlists.map(
                (p) => ListTile(
                  leading: const Icon(Icons.queue_music),
                  title: Text(p.name),
                  trailing: p.itemIds.contains(item.id)
                      ? const Icon(Icons.check, color: accent)
                      : null,
                  onTap: () => Navigator.pop(context, p.id),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (!mounted || selected == null) return;
    UserPlaylist? playlist;
    if (selected == 'new') {
      playlist = await _createPlaylist();
    } else {
      playlist = c.library.playlists.where((p) => p.id == selected).firstOrNull;
    }
    if (playlist == null || !mounted) return;
    c.addToPlaylist(playlist, item);
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('Added to ${playlist.name}')));
  }

  void _collection(
    String title,
    List<MediaItem> Function() items, {
    UserPlaylist? playlist,
  }) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * 0.72,
          child: AnimatedBuilder(
            animation: c,
            builder: (context, _) {
              final collection = items();
              return ListView(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text(
                      title,
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                  ),
                  if (collection.isEmpty)
                    const _Empty(
                      icon: Icons.music_note,
                      title: 'Your next favourite is waiting',
                      body:
                          'Browse the collection and save something you love.',
                    ),
                  ...collection.map(
                    (m) => _row(m, collection, playlist: playlist),
                  ),
                ],
              );
            },
          ),
        ),
      ),
    );
  }

  Future<void> _play(MediaItem item, List<MediaItem> collection) async {
    if (!item.isYoutube) {
      await c.playItem(item, from: collection);
      return;
    }
    if (_openingOnline) return;
    _openingOnline = true;
    try {
      await c.prepareEmbeddedPlayback();
      if (!mounted) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute(
          builder: (_) => YoutubePlayerScreen(
            item: item,
            items: collection,
            controller: c,
            onAddToPlaylist: _addToPlaylist,
          ),
        ),
      );
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not open the player. Please try again.'),
          ),
        );
    } finally {
      _openingOnline = false;
    }
  }

  Widget _miniPlayer() {
    final item = c.current!;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
      child: Material(
        color: paper,
        borderRadius: BorderRadius.circular(16),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: _fullPlayer,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 4, 8),
                child: Row(
                  children: [
                    CoverArt(item: item, size: 44),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            item.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          Text(
                            c.playbackError != null
                                ? 'Playback unavailable · Tap for details'
                                : c.loading
                                ? 'Getting your song ready…'
                                : item.creator,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(color: muted, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                    _playButton(compact: true),
                    IconButton(
                      tooltip: 'Next song',
                      onPressed: c.loading ? null : () => c.next(),
                      icon: const Icon(Icons.skip_next_rounded, size: 25),
                    ),
                  ],
                ),
              ),
              StreamBuilder<Duration>(
                stream: c.player.positionStream,
                builder: (_, snapshot) {
                  final total = c.player.duration?.inMilliseconds ?? 0;
                  final position = snapshot.data?.inMilliseconds ?? 0;
                  return LinearProgressIndicator(
                    minHeight: 2,
                    value: total > 0
                        ? (position / total).clamp(0.0, 1.0).toDouble()
                        : 0,
                    backgroundColor: hairline,
                    color: accent,
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  bool get _playing =>
      c.player.playing && c.player.processingState != ProcessingState.completed;

  Widget _playButton({bool compact = false}) => c.loading
      ? SizedBox(
          width: compact ? 48 : 64,
          height: compact ? 48 : 64,
          child: const Center(
            child: SizedBox.square(
              dimension: 24,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ),
        )
      : IconButton.filled(
          tooltip: _playing ? 'Pause' : 'Play',
          style: IconButton.styleFrom(
            backgroundColor: compact ? Colors.transparent : accent,
            foregroundColor: compact ? ink : cream,
            minimumSize: Size.square(compact ? 48 : 64),
          ),
          onPressed: c.togglePlayback,
          icon: Icon(
            _playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
            size: compact ? 28 : 40,
          ),
        );

  Future<void> _openOnYoutube(MediaItem item) async {
    if (!item.isYoutube) return;
    final uri = Uri.https('www.youtube.com', '/watch', {
      'v': item.source.substring(8),
    });
    try {
      if (await launchUrl(uri, mode: LaunchMode.externalApplication)) return;
    } catch (_) {}
    if (mounted)
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open YouTube on this device.')),
      );
  }

  Widget _timeline() => StreamBuilder<Duration?>(
    stream: c.player.durationStream,
    builder: (_, durationSnapshot) => StreamBuilder<Duration>(
      stream: c.player.positionStream,
      builder: (_, positionSnapshot) {
        final unavailable = c.loading || c.playbackError != null;
        final duration = unavailable
            ? Duration.zero
            : durationSnapshot.data ?? c.player.duration ?? Duration.zero;
        final position = unavailable
            ? Duration.zero
            : positionSnapshot.data ?? c.player.position;
        final total = duration.inMilliseconds;
        return Column(
          children: [
            SliderTheme(
              data: SliderTheme.of(
                context,
              ).copyWith(trackShape: const WaveTrack()),
              child: Slider(
                semanticFormatterCallback: (value) =>
                    clock(Duration(milliseconds: value.round())),
                value: total > 0
                    ? position.inMilliseconds.clamp(0, total).toDouble()
                    : 0,
                max: total > 0 ? total.toDouble() : 1,
                onChanged: unavailable || total == 0
                    ? null
                    : (v) => c.seek(Duration(milliseconds: v.round())),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    clock(position),
                    style: const TextStyle(color: muted, fontSize: 12),
                  ),
                  Text(
                    total == 0 ? '—:—' : clock(duration),
                    style: const TextStyle(color: muted, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    ),
  );

  void _fullPlayer() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      showDragHandle: false,
      backgroundColor: paper,
      builder: (sheetContext) => AnimatedBuilder(
        animation: c,
        builder: (context, _) {
          final item = c.current;
          if (item == null) return const SizedBox.shrink();
          final artSize = (MediaQuery.sizeOf(context).height * .37).clamp(
            180.0,
            370.0,
          );
          return FractionallySizedBox(
            heightFactor: .98,
            child: SafeArea(
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 520),
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
                    children: [
                      Row(
                        children: [
                          IconButton(
                            tooltip: 'Close player',
                            onPressed: () => Navigator.pop(sheetContext),
                            icon: const Icon(Icons.keyboard_arrow_down_rounded),
                          ),
                          const Expanded(
                            child: Center(
                              child: Text(
                                'NOW PLAYING',
                                style: TextStyle(
                                  color: muted,
                                  fontSize: 10,
                                  letterSpacing: 2,
                                ),
                              ),
                            ),
                          ),
                          IconButton(
                            tooltip: c.liked(item)
                                ? 'Remove favourite'
                                : 'Save favourite',
                            onPressed: () => c.toggleLike(item),
                            icon: Icon(
                              c.liked(item)
                                  ? Icons.favorite_rounded
                                  : Icons.favorite_outline_rounded,
                              color: c.liked(item) ? accent : ink,
                              size: 21,
                            ),
                          ),
                          IconButton(
                            tooltip: 'Add to playlist',
                            onPressed: () => _addToPlaylist(item),
                            icon: const Icon(
                              Icons.playlist_add_rounded,
                              size: 23,
                            ),
                          ),
                          IconButton(
                            tooltip: 'Queue',
                            onPressed: () =>
                                _collection('Up next', () => c.queue),
                            icon: const Icon(
                              Icons.queue_music_rounded,
                              size: 22,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 28),
                      LayoutBuilder(
                        builder: (_, bounds) => Center(
                          child: CoverArt(
                            item: item,
                            size: artSize.clamp(0, bounds.maxWidth).toDouble(),
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      Tooltip(
                        message: item.title,
                        child: Text(
                          item.title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: ink,
                            fontSize: 24,
                            height: 1.25,
                            fontWeight: FontWeight.w700,
                            letterSpacing: -.4,
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        item.creator,
                        textAlign: TextAlign.center,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: muted, fontSize: 13),
                      ),
                      const SizedBox(height: 16),
                      if (c.loading)
                        const Padding(
                          padding: EdgeInsets.only(bottom: 8),
                          child: Text(
                            'Getting your song ready…',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: muted, fontSize: 12),
                          ),
                        ),
                      _timeline(),
                      const SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          IconButton(
                            tooltip: 'Shuffle',
                            onPressed: c.toggleShuffle,
                            isSelected: c.shuffle,
                            icon: Icon(
                              Icons.shuffle_rounded,
                              color: c.shuffle ? accent : muted,
                              size: 20,
                            ),
                          ),
                          IconButton(
                            tooltip: 'Previous song',
                            onPressed: c.loading ? null : c.previous,
                            icon: const Icon(
                              Icons.skip_previous_rounded,
                              size: 29,
                            ),
                          ),
                          _playButton(),
                          IconButton(
                            tooltip: 'Next song',
                            onPressed: c.loading ? null : () => c.next(),
                            icon: const Icon(Icons.skip_next_rounded, size: 29),
                          ),
                          IconButton(
                            tooltip: 'Repeat song',
                            onPressed: c.toggleRepeat,
                            isSelected: c.repeat,
                            icon: Icon(
                              Icons.repeat_one_rounded,
                              color: c.repeat ? accent : muted,
                              size: 20,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Center(
                        child: TextButton.icon(
                          onPressed: _sleep,
                          icon: const Icon(Icons.bedtime_outlined, size: 17),
                          label: Text(
                            c.sleepUntil == null
                                ? 'Sleep timer'
                                : 'Sleep timer is on',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                      ),
                      if (c.playbackError != null)
                        Container(
                          margin: const EdgeInsets.only(top: 16),
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: paper,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Playback unavailable',
                                style: TextStyle(
                                  color: accent,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                c.playbackError!,
                                style: const TextStyle(
                                  color: ink,
                                  fontSize: 12,
                                ),
                              ),
                              if (item.isYoutube)
                                TextButton.icon(
                                  onPressed: () => _openOnYoutube(item),
                                  icon: const Icon(Icons.open_in_new, size: 15),
                                  label: const Text('Open in YouTube'),
                                ),
                            ],
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({
    required this.icon,
    required this.title,
    required this.body,
    this.action,
  });
  final IconData icon;
  final String title;
  final String body;
  final Widget? action;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(30),
    child: Column(
      children: [
        Icon(icon, size: 44, color: accent),
        const SizedBox(height: 16),
        Text(
          title,
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 8),
        Text(
          body,
          textAlign: TextAlign.center,
          style: const TextStyle(color: muted),
        ),
        if (action != null) ...[const SizedBox(height: 12), action!],
      ],
    ),
  );
}
