import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const accent = Color(0xFFC7A0FF);
const ink = Color(0xFFF6F2FF);
const muted = Color(0xFFB7ACC9);
const cream = Color(0xFF0C0A10);
const paper = Color(0xFF211A2F);
const hairline = Color(0xFF493B60);

ThemeData olamTheme() => ThemeData(
  useMaterial3: true,
  brightness: Brightness.dark,
  scaffoldBackgroundColor: cream,
  colorScheme: ColorScheme.fromSeed(
    seedColor: accent,
    brightness: Brightness.dark,
    primary: accent,
    onPrimary: cream,
    surface: cream,
    onSurface: ink,
    secondary: const Color(0xFFD89EFF),
    outline: hairline,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: cream,
    foregroundColor: ink,
    elevation: 0,
    scrolledUnderElevation: 0,
    centerTitle: true,
    systemOverlayStyle: SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      statusBarBrightness: Brightness.dark,
      systemNavigationBarColor: cream,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  ),
  dividerTheme: const DividerThemeData(
    color: hairline,
    thickness: .6,
    space: 24,
  ),
  iconTheme: const IconThemeData(color: ink, size: 22),
  sliderTheme: const SliderThemeData(
    trackHeight: 2,
    activeTrackColor: accent,
    inactiveTrackColor: hairline,
    thumbColor: accent,
    thumbShape: RoundSliderThumbShape(enabledThumbRadius: 5),
  ),
  chipTheme: ChipThemeData(
    backgroundColor: cream,
    selectedColor: const Color(0xFF6630B3),
    side: const BorderSide(color: hairline),
    labelStyle: const TextStyle(fontSize: 12, color: ink),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
  ),
  filledButtonTheme: FilledButtonThemeData(
    style: FilledButton.styleFrom(
      backgroundColor: accent,
      foregroundColor: cream,
      padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
    ),
  ),
  bottomSheetTheme: const BottomSheetThemeData(
    backgroundColor: cream,
    surfaceTintColor: Colors.transparent,
    showDragHandle: true,
  ),
  snackBarTheme: const SnackBarThemeData(
    behavior: SnackBarBehavior.floating,
    backgroundColor: ink,
    contentTextStyle: TextStyle(color: cream),
  ),
  navigationBarTheme: NavigationBarThemeData(
    backgroundColor: cream,
    indicatorColor: paper,
    elevation: 0,
    labelTextStyle: WidgetStateProperty.resolveWith(
      (states) => TextStyle(
        color: states.contains(WidgetState.selected) ? accent : muted,
        fontSize: 11,
        fontWeight: FontWeight.w600,
      ),
    ),
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: paper,
    hintStyle: const TextStyle(color: muted),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(24),
      borderSide: BorderSide.none,
    ),
  ),
  textTheme: const TextTheme(
    headlineLarge: TextStyle(
      color: ink,
      fontSize: 28,
      fontWeight: FontWeight.w700,
      letterSpacing: -.8,
    ),
    headlineMedium: TextStyle(
      color: ink,
      fontSize: 24,
      fontWeight: FontWeight.w700,
      letterSpacing: -.5,
    ),
    titleLarge: TextStyle(
      color: ink,
      fontSize: 20,
      fontWeight: FontWeight.w600,
    ),
    titleMedium: TextStyle(
      color: ink,
      fontSize: 15,
      fontWeight: FontWeight.w600,
    ),
    bodyMedium: TextStyle(color: ink, fontSize: 14, height: 1.45),
  ),
);
