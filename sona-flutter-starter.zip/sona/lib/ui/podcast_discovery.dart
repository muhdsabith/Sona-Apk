import 'package:flutter/material.dart';
import '../controllers/app_controller.dart';
import '../models/media_item.dart';
import '../services/apis.dart';

class PodcastDiscovery extends StatefulWidget {
  const PodcastDiscovery({super.key, required this.controller});
  final AppController controller;
  @override
  State<PodcastDiscovery> createState() => _PodcastDiscoveryState();
}

class _PodcastDiscoveryState extends State<PodcastDiscovery> {
  final _search = TextEditingController();
  final _feed = TextEditingController();
  final _api = PodcastApi();
  List<PodcastFeed> _results = [];
  bool _busy = false, _searched = false;
  String? _error;
  Future<void> _find() async {
    if (_busy || _search.text.trim().isEmpty) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final result = await _api.search(_search.text);
      if (mounted)
        setState(() {
          _results = result;
          _searched = true;
        });
    } catch (_) {
      if (mounted)
        setState(
          () => _error =
              'Could not search podcasts. Try again or add an RSS feed below.',
        );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _add(String url) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    final added = await widget.controller.subscribe(url);
    if (!mounted) return;
    if (added) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Podcast added. Its episodes are ready in Podcasts.'),
        ),
      );
    } else {
      _error = widget.controller.error ?? 'Could not add this feed.';
    }
    setState(() => _busy = false);
  }

  @override
  void dispose() {
    _search.dispose();
    _feed.dispose();
    _api.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Find podcasts')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        Text(
          'A new voice. A new idea.',
          style: Theme.of(context).textTheme.headlineMedium,
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _search,
          enabled: !_busy,
          onSubmitted: (_) => _find(),
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            hintText: 'Try Malayalam, science, stories…',
            suffixIcon: IconButton(
              onPressed: _busy ? null : _find,
              icon: const Icon(Icons.search),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          children: ['Malayalam', 'Stories', 'Science', 'Technology']
              .map(
                (term) => ActionChip(
                  label: Text(term),
                  onPressed: _busy
                      ? null
                      : () {
                          _search.text = term;
                          _find();
                        },
                ),
              )
              .toList(),
        ),
        if (_busy)
          const Padding(
            padding: EdgeInsets.all(20),
            child: LinearProgressIndicator(),
          ),
        if (_error != null)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(
              _error!,
              style: const TextStyle(color: Colors.orangeAccent),
            ),
          ),
        if (_searched && _results.isEmpty)
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('No podcasts found. Try another name or language.'),
          ),
        ..._results.map((feed) {
          final added = widget.controller.library.feeds.any(
            (f) => f.url == feed.url,
          );
          return ListTile(
            contentPadding: const EdgeInsets.symmetric(vertical: 6),
            leading: feed.artworkUrl == null
                ? const Icon(Icons.podcasts)
                : ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.network(
                      feed.artworkUrl!,
                      width: 52,
                      height: 52,
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => const SizedBox.square(
                        dimension: 52,
                        child: Icon(Icons.podcasts),
                      ),
                    ),
                  ),
            title: Text(
              feed.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: Text(
              feed.creator,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            trailing: IconButton(
              tooltip: added ? 'Subscribed' : 'Subscribe',
              onPressed: _busy || added ? null : () => _add(feed.url),
              icon: Icon(added ? Icons.check_circle : Icons.add_circle_outline),
            ),
          );
        }),
        const SizedBox(height: 28),
        Text(
          'Have a podcast feed?',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 8),
        const Text('Paste its HTTPS RSS address to follow it directly.'),
        const SizedBox(height: 12),
        TextField(
          controller: _feed,
          enabled: !_busy,
          keyboardType: TextInputType.url,
          autocorrect: false,
          decoration: const InputDecoration(hintText: 'https://…/feed.xml'),
        ),
        const SizedBox(height: 12),
        FilledButton.icon(
          onPressed: _busy ? null : () => _add(_feed.text.trim()),
          icon: const Icon(Icons.rss_feed),
          label: const Text('Add podcast feed'),
        ),
        const SizedBox(height: 24),
        const Text(
          'Podcast search uses the Apple podcast directory. Episodes stream directly from their publishers. Availability depends on the publisher.',
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ],
    ),
  );
}
