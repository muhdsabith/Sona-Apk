import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

class SpotifyPlaylistScreen extends StatefulWidget {
  const SpotifyPlaylistScreen({super.key});
  static const playlistId = '0OfjG2a49jVbnXSWMA0suD';
  static final playlistUrl = Uri.https('open.spotify.com', '/playlist/$playlistId');
  static final embedUrl = Uri.https('open.spotify.com', '/embed/playlist/$playlistId',
    {'utm_source': 'generator', 'theme': '0'});

  @override
  State<SpotifyPlaylistScreen> createState() => _SpotifyPlaylistScreenState();
}

class _SpotifyPlaylistScreenState extends State<SpotifyPlaylistScreen> with WidgetsBindingObserver {
  late final WebViewController _controller;
  Future<void> _navigation = Future<void>.value();
  bool _ready = false;
  bool _loading = true;
  bool _suspended = false;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller = WebViewController();
    unawaited(_initialize());
  }

  Future<void> _initialize() async {
    try {
      await _controller.setJavaScriptMode(JavaScriptMode.unrestricted);
      await _controller.setBackgroundColor(const Color(0xFF101210));
      await _controller.setNavigationDelegate(NavigationDelegate(
        onPageStarted: (url) {
          if (mounted && url != 'about:blank' && !_suspended) {
            setState(() { _loading = true; _failed = false; });
          }
        },
        onPageFinished: (url) {
          if (mounted && url != 'about:blank' && !_suspended) setState(() => _loading = false);
        },
        onWebResourceError: (error) {
          if (mounted && !_suspended && error.isForMainFrame == true) {
            setState(() { _failed = true; _loading = false; });
          }
        },
        onNavigationRequest: (request) {
          if (request.url == 'about:blank') return NavigationDecision.navigate;
          if (!request.isMainFrame) return NavigationDecision.navigate;
          final uri = Uri.tryParse(request.url);
          if (uri != null && uri.scheme == 'https' && uri.host == 'open.spotify.com' &&
              uri.path.startsWith('/embed/')) return NavigationDecision.navigate;
          if (uri != null && ((uri.scheme == 'https' &&
              (uri.host == 'spotify.com' || uri.host.endsWith('.spotify.com'))) || uri.scheme == 'spotify')) {
            unawaited(_openExternal(uri));
          }
          return NavigationDecision.prevent;
        },
      ));
      if (!mounted) return;
      _ready = true;
      if (!_suspended) _load();
    } catch (_) {
      if (mounted) setState(() { _failed = true; _loading = false; });
    }
  }

  void _scheduleNavigation(Uri uri) {
    _navigation = _navigation.then((_) async {
      if (!mounted && uri.toString() != 'about:blank') return;
      await _controller.loadRequest(uri);
    }).catchError((Object _) {
      if (mounted && !_suspended && uri.toString() != 'about:blank') {
        setState(() { _failed = true; _loading = false; });
      }
    });
  }

  void _load() {
    if (!_ready) { unawaited(_initialize()); return; }
    setState(() { _failed = false; _loading = true; });
    _scheduleNavigation(SpotifyPlaylistScreen.embedUrl);
  }

  Future<void> _openExternal(Uri uri) async {
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) throw StateError('Cannot open URL');
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open Spotify. Try again or use your browser.')));
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _suspended = true;
      if (_ready) _scheduleNavigation(Uri.parse('about:blank'));
    } else if (state == AppLifecycleState.resumed && _suspended) {
      _suspended = false;
      if (_ready) _load();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    if (_ready) _scheduleNavigation(Uri.parse('about:blank'));
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Spotify playlist'), actions: [
      IconButton(tooltip: 'Reload playlist', onPressed: _loading ? null : _load, icon: const Icon(Icons.refresh)),
    ]),
    body: SafeArea(child: Column(children: [
      if (_loading) const LinearProgressIndicator(minHeight: 2),
      Expanded(child: Stack(children: [
        WebViewWidget(controller: _controller),
        if (_failed) ColoredBox(color: const Color(0xFF101210), child: Center(child: Padding(
          padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.wifi_off, size: 40), const SizedBox(height: 16),
            const Text('Could not load the playlist', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            const Text('Check your connection and try again, or open the playlist in Spotify.', textAlign: TextAlign.center),
            const SizedBox(height: 16), FilledButton(onPressed: _load, child: const Text('Try again')),
          ]),
        ))),
      ])),
      Padding(padding: const EdgeInsets.fromLTRB(20, 12, 20, 16), child: Column(children: [
        const Text('Playback availability is determined by Spotify.', textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12, color: Colors.white70)),
        const SizedBox(height: 8),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          onPressed: () => _openExternal(SpotifyPlaylistScreen.playlistUrl),
          icon: const Icon(Icons.open_in_new, size: 18), label: const Text('Open in Spotify'))),
      ])),
    ])),
  );
}
