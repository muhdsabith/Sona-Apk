import 'package:flutter/material.dart';
import '../models/track_model.dart';
import 'olam_theme.dart';

class ChartTrackTile extends StatelessWidget {
  const ChartTrackTile({
    super.key,
    required this.track,
    required this.rank,
    required this.onSearch,
    required this.onOpen,
  });
  final Track track;
  final int rank;
  final VoidCallback onSearch, onOpen;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
    child: Material(
      color: paper,
      borderRadius: BorderRadius.circular(22),
      child: ListTile(
        contentPadding: const EdgeInsets.fromLTRB(12, 8, 4, 8),
        leading: SizedBox.square(
          dimension: 52,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: track.imageUrl.isEmpty
                ? _fallback()
                : Image.network(
                    track.imageUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (_, _, _) => _fallback(),
                  ),
          ),
        ),
        title: Text(
          track.name,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          track.artistName,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: muted, fontSize: 12),
        ),
        onTap: onSearch,
        trailing: PopupMenuButton<String>(
          tooltip: 'Song actions',
          onSelected: (value) => value == 'search' ? onSearch() : onOpen(),
          itemBuilder: (_) => [
            const PopupMenuItem(
              value: 'search',
              child: Text('Find on YouTube'),
            ),
            if (track.url.isNotEmpty)
              const PopupMenuItem(
                value: 'open',
                child: Text('View on Last.fm'),
              ),
          ],
        ),
      ),
    ),
  );
  Widget _fallback() => ColoredBox(
    color: const Color(0xFF34283E),
    child: Center(
      child: Text(
        rank.toString().padLeft(2, '0'),
        style: const TextStyle(
          color: lavender,
          fontSize: 19,
          fontWeight: FontWeight.w700,
        ),
      ),
    ),
  );
}

class FeatureCard extends StatelessWidget {
  const FeatureCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
    this.color = lavender,
  });
  final String title, subtitle;
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  @override
  Widget build(BuildContext context) => Material(
    color: color,
    borderRadius: BorderRadius.circular(30),
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      color: cream,
                      fontWeight: FontWeight.w800,
                      fontSize: 23,
                      height: 1.15,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Icon(icon, color: cream, size: 36),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              subtitle,
              style: const TextStyle(color: Color(0xFF33263B), height: 1.4),
            ),
            const SizedBox(height: 18),
            const CircleAvatar(
              backgroundColor: cream,
              radius: 22,
              child: Icon(Icons.arrow_forward_rounded, color: Colors.white),
            ),
          ],
        ),
      ),
    ),
  );
}
