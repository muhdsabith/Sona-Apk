import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../controllers/app_controller.dart';
import '../models/media_item.dart';
import '../services/youtube_embed.dart';
import 'olam_theme.dart';

class YoutubePlayerScreen extends StatefulWidget {
  const YoutubePlayerScreen({
    super.key,
    required this.item,
    required this.items,
    required this.controller,
    required this.onAddToPlaylist,
  });
  final MediaItem item;
  final List<MediaItem> items;
  final AppController controller;
  final Future<void> Function(MediaItem) onAddToPlaylist;
  @override
  State<YoutubePlayerScreen> createState() => _YoutubePlayerScreenState();
}

class _YoutubePlayerScreenState extends State<YoutubePlayerScreen>
    with WidgetsBindingObserver {
  late final WebViewController _web;
  late MediaItem _item;
  late final List<MediaItem> _queue;
  Future<void> _navigation = Future<void>.value();
  Timer? _watchdog;
  bool _initialized = false, _suspended = false, _loading = true;
  String? _error;
  final Set<String> _recorded = {};

  @override
  void initState() {
    super.initState();
    _item = widget.item;
    final ids = <String>{};
    _queue = [
      widget.item,
      ...widget.items,
    ].where((m) => m.isYoutube && ids.add(m.id)).toList();
    _web = WebViewController();
    WidgetsBinding.instance.addObserver(this);
    unawaited(_initialize());
  }

  Future<void> _initialize() async {
    try {
      await _web.setJavaScriptMode(JavaScriptMode.unrestricted);
      await _web.setBackgroundColor(Colors.black);
      await _web.addJavaScriptChannel(
        'RaagaPlayer',
        onMessageReceived: _message,
      );
      await _web.setNavigationDelegate(
        NavigationDelegate(
          onNavigationRequest: (request) {
            if (!request.isMainFrame || request.url == 'about:blank')
              return NavigationDecision.navigate;
            final uri = Uri.tryParse(request.url);
            if (uri != null &&
                uri.scheme == 'https' &&
                uri.origin == YoutubeEmbed.origin)
              return NavigationDecision.navigate;
            if (uri != null &&
                uri.scheme == 'https' &&
                (uri.host == 'youtube.com' ||
                    uri.host.endsWith('.youtube.com') ||
                    uri.host == 'youtu.be')) {
              unawaited(_openExternal(uri));
            }
            return NavigationDecision.prevent;
          },
          onWebResourceError: (error) {
            if (error.isForMainFrame == true && mounted && !_suspended) {
              _fail(
                'The YouTube player could not load. Check your connection and retry.',
              );
            }
          },
        ),
      );
      if (!mounted) return;
      _initialized = true;
      if (!_suspended) _load();
    } catch (_) {
      _fail(
        'The player could not start. Update Android System WebView or Chrome, then reopen Raaga.',
      );
    }
  }

  void _fail(String message) {
    _watchdog?.cancel();
    if (mounted)
      setState(() {
        _error = message;
        _loading = false;
      });
  }

  void _message(JavaScriptMessage message) {
    if (!mounted || _suspended) return;
    try {
      final data = jsonDecode(message.message) as Map<String, dynamic>;
      if (data['videoId'] != YoutubeEmbed.idFromSource(_item.source)) return;
      if (data['type'] == 'ready') {
        _watchdog?.cancel();
        setState(() {
          _loading = false;
          _error = null;
        });
      } else if (data['type'] == 'error') {
        _fail(YoutubeEmbed.errorMessage((data['value'] as num).toInt()));
      } else if (data['type'] == 'loadError') {
        _fail('YouTube did not load. Check your connection and tap Retry.');
      } else if (data['type'] == 'state' && data['value'] == 1) {
        setState(() {
          _error = null;
          _loading = false;
        });
        if (_recorded.add(_item.id))
          unawaited(widget.controller.recordEmbeddedPlay(_item));
      }
    } catch (_) {}
  }

  void _enqueue(Future<void> Function() action) {
    _navigation = _navigation.then((_) => action()).catchError((Object _) {
      if (mounted && !_suspended)
        _fail('The player could not load. Tap Retry.');
    });
  }

  void _load() {
    if (!_initialized || _suspended || !mounted) return;
    final source = _item.source;
    setState(() {
      _loading = true;
      _error = null;
    });
    _watchdog?.cancel();
    _watchdog = Timer(const Duration(seconds: 25), () {
      if (mounted && _loading && !_suspended)
        _fail('YouTube is taking too long to load. Tap Retry or open YouTube.');
    });
    _enqueue(() async {
      if (!mounted || _suspended || _item.source != source) return;
      await _web.loadHtmlString(
        YoutubeEmbed.html(source),
        baseUrl: '${YoutubeEmbed.origin}/',
      );
    });
  }

  Future<void> _pause() async {
    try {
      await _web.runJavaScript('pauseRaaga();');
    } catch (_) {}
  }

  void _select(MediaItem item) {
    if (item.id == _item.id) return;
    _enqueue(_pause);
    setState(() => _item = item);
    _load();
  }

  Future<void> _openExternal(Uri uri) async {
    await _pause();
    try {
      if (await launchUrl(uri, mode: LaunchMode.externalApplication)) return;
    } catch (_) {}
    if (mounted)
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Could not open YouTube.')));
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive) unawaited(_pause());
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.hidden ||
        state == AppLifecycleState.detached) {
      _suspended = true;
      _watchdog?.cancel();
      _enqueue(() => _web.loadRequest(Uri.parse('about:blank')));
    } else if (state == AppLifecycleState.resumed) {
      if (_suspended) {
        _suspended = false;
        _load();
      } else {
        unawaited(
          _web.runJavaScript('visible=true;').catchError((Object _) {}),
        );
      }
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _watchdog?.cancel();
    _enqueue(() => _web.loadRequest(Uri.parse('about:blank')));
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Raaga · YouTube'),
      actions: [
        IconButton(
          tooltip: 'Open in YouTube',
          onPressed: () => _openExternal(
            Uri.https('www.youtube.com', '/watch', {
              'v': YoutubeEmbed.idFromSource(_item.source),
            }),
          ),
          icon: const Icon(Icons.open_in_new, size: 20),
        ),
      ],
    ),
    body: SafeArea(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: LayoutBuilder(
            builder: (context, bounds) => Column(
              children: [
                SizedBox(
                  height: math
                      .max(200, math.min(340, bounds.maxHeight * .44))
                      .toDouble(),
                  width: double.infinity,
                  child: WebViewWidget(controller: _web),
                ),
                if (_loading) const LinearProgressIndicator(minHeight: 2),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.all(20),
                    children: [
                      Text(
                        _item.title,
                        style: const TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w700,
                          color: accent,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Text(_item.creator, style: const TextStyle(color: muted)),
                      const SizedBox(height: 12),
                      const Text(
                        'Tap Play in the YouTube player above. Keep this screen open to listen.',
                        style: TextStyle(fontSize: 12, color: muted),
                      ),
                      if (_error != null) ...[
                        const SizedBox(height: 12),
                        Text(_error!, style: const TextStyle(color: accent)),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: TextButton.icon(
                            onPressed: _initialized ? _load : _initialize,
                            icon: const Icon(Icons.refresh),
                            label: const Text('Retry'),
                          ),
                        ),
                      ],
                      AnimatedBuilder(
                        animation: widget.controller,
                        builder: (_, _) => Wrap(
                          spacing: 12,
                          children: [
                            TextButton.icon(
                              onPressed: () =>
                                  widget.controller.toggleLike(_item),
                              icon: Icon(
                                widget.controller.liked(_item)
                                    ? Icons.favorite
                                    : Icons.favorite_border,
                              ),
                              label: Text(
                                widget.controller.liked(_item)
                                    ? 'Saved'
                                    : 'Save',
                              ),
                            ),
                            TextButton.icon(
                              onPressed: () async {
                                await _pause();
                                await widget.onAddToPlaylist(_item);
                                if (mounted) {
                                  try {
                                    await _web.runJavaScript('visible=true;');
                                  } catch (_) {}
                                }
                              },
                              icon: const Icon(Icons.playlist_add),
                              label: const Text('Add to playlist'),
                            ),
                          ],
                        ),
                      ),
                      if (_queue.length > 1) ...[
                        const Divider(),
                        const Text(
                          'In this collection',
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        ..._queue.map(
                          (item) => ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: Text(
                              item.title,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 13,
                                color: item.id == _item.id ? accent : ink,
                              ),
                            ),
                            subtitle: Text(
                              item.creator,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: Icon(
                              item.id == _item.id
                                  ? Icons.play_circle_outline
                                  : Icons.chevron_right,
                              size: 20,
                            ),
                            onTap: () => _select(item),
                          ),
                        ),
                      ],
                      const SizedBox(height: 16),
                      const Text(
                        'Video playback is provided by YouTube. Local music still supports background audio.',
                        style: TextStyle(fontSize: 11, color: muted),
                      ),
                      TextButton(
                        onPressed: () => launchUrl(
                          Uri.parse('https://policies.google.com/privacy'),
                          mode: LaunchMode.externalApplication,
                        ),
                        child: const Text('Google privacy policy'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}
