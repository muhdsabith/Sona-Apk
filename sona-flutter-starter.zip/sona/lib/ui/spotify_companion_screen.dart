import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../controllers/spotify_companion_controller.dart';
import '../models/spotify_content.dart';
import '../services/spotify_auth.dart';
import '../services/spotify_companion_api.dart';

const _lime = Color(0xFFC9F27A);
const _muted = Color(0xFFB4BCAF);

class SpotifyCompanionScreen extends StatefulWidget {
  const SpotifyCompanionScreen({super.key});
  @override
  State<SpotifyCompanionScreen> createState() => _SpotifyCompanionScreenState();
}

class _SpotifyCompanionScreenState extends State<SpotifyCompanionScreen>
    with WidgetsBindingObserver {
  final c = SpotifyCompanionController();
  final _clientId = TextEditingController();
  int tab = 0;
  bool _wasConnected = false;
  int _session = 0;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    c.addListener(_changed);
    unawaited(_initialize());
  }

  Future<void> _initialize() async {
    await c.initialize();
    if (mounted) _clientId.text = c.clientId;
  }

  void _changed() {
    if (!mounted) return;
    if (_wasConnected != c.connected) {
      _session++;
      _wasConnected = c.connected;
    }
    setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) c.setForeground(true);
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.detached)
      c.setForeground(false);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    c.removeListener(_changed);
    c.dispose();
    _clientId.dispose();
    super.dispose();
  }

  Future<void> _open(Uri url) async {
    try {
      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
        throw const SpotifyRemoteException(
          'Could not open Spotify. Make sure the Spotify app is installed.',
        );
      }
    } catch (e) {
      c.report(e);
    }
  }

  Future<void> _openSpotify() async {
    try {
      if (await launchUrl(
        Uri.parse('spotify:'),
        mode: LaunchMode.externalApplication,
      ))
        return;
    } catch (_) {}
    await _open(Uri.parse('https://open.spotify.com/'));
  }

  void _toast(String message) {
    if (mounted)
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _devices() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => _DevicePicker(controller: c, openSpotify: _openSpotify),
    );
  }

  void _collection(SpotifyContent item) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => _CollectionScreen(
          item: item,
          controller: c,
          onPlay: _play,
          onMenu: _menu,
          onOpen: _open,
        ),
      ),
    );
  }

  Future<void> _play(SpotifyContent item) async {
    if (!item.playable) {
      _toast('Spotify cannot play this item on your account.');
      return;
    }
    if (item.type == 'show') {
      _collection(item);
      return;
    }
    if (c.target == null) await _devices();
    if (!mounted || !c.connected || c.target == null) return;
    await c.play(item);
  }

  void _menu(SpotifyContent item) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(title: Text(item.title), subtitle: Text(item.subtitle)),
            if (item.isAudio)
              ListTile(
                leading: const Icon(Icons.queue_music),
                title: const Text('Add to Spotify queue'),
                onTap: () async {
                  Navigator.pop(ctx);
                  if (await c.action('queue', uri: item.uri))
                    _toast('Added to Spotify queue');
                },
              ),
            if (['track', 'episode', 'album', 'show'].contains(item.type))
              ListTile(
                leading: const Icon(Icons.favorite_border),
                title: const Text('Save to Spotify library'),
                onTap: () async {
                  Navigator.pop(ctx);
                  if (await c.save(item)) _toast('Saved to Spotify library');
                },
              ),
            ListTile(
              leading: const Icon(Icons.open_in_new),
              title: const Text('Open in Spotify'),
              onTap: () {
                Navigator.pop(ctx);
                _open(item.webUrl);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _player() => showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    builder: (_) => _FullPlayer(
      controller: c,
      devices: _devices,
      openSpotify: _openSpotify,
      onMenu: _menu,
      onQueue: _queue,
    ),
  );
  void _queue() => Navigator.of(context).push(
    MaterialPageRoute<void>(
      builder: (_) => Scaffold(
        appBar: AppBar(title: const Text('Spotify queue')),
        body: _ContentList(
          key: ValueKey('queue-$_session'),
          controller: c,
          load: (_) async => SpotifyPage(await c.api.queue(), null),
          empty: 'Your Spotify queue is empty. Add a track from Search.',
          onTap: _play,
          onMenu: _menu,
        ),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text(
        'Sona',
        style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: -1),
      ),
      actions: [
        if (c.connected)
          IconButton(
            onPressed: _devices,
            tooltip: 'Spotify devices',
            icon: const Icon(Icons.devices),
          ),
      ],
    ),
    body: SafeArea(
      child: Column(
        children: [
          if (c.error != null)
            MaterialBanner(
              content: Text(c.error!),
              actions: [
                TextButton(
                  onPressed: c.clearError,
                  child: const Text('Dismiss'),
                ),
              ],
            ),
          if (c.connecting || c.commanding)
            const LinearProgressIndicator(minHeight: 2),
          Expanded(
            child: !c.ready
                ? const Center(child: CircularProgressIndicator())
                : !c.connected
                ? _login()
                : IndexedStack(
                    index: tab,
                    children: [
                      _home(),
                      _SearchTab(
                        key: ValueKey('search-$_session'),
                        controller: c,
                        onTap: (i) =>
                            i.isCollection ? _collection(i) : _play(i),
                        onMenu: _menu,
                      ),
                      _LibraryTab(
                        key: ValueKey('library-$_session'),
                        controller: c,
                        onTap: (i) =>
                            i.isCollection ? _collection(i) : _play(i),
                        onMenu: _menu,
                      ),
                      _settings(),
                    ],
                  ),
          ),
          if (c.connected) _miniPlayer(),
        ],
      ),
    ),
    bottomNavigationBar: c.connected
        ? NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.home_outlined),
                selectedIcon: Icon(Icons.home),
                label: 'For you',
              ),
              NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
              NavigationDestination(
                icon: Icon(Icons.library_music_outlined),
                label: 'Library',
              ),
              NavigationDestination(
                icon: Icon(Icons.settings_outlined),
                label: 'Settings',
              ),
            ],
          )
        : null,
  );
  Widget _login() => ListView(
    padding: const EdgeInsets.all(24),
    children: [
      const Text(
        'Your Spotify.\nYour Sona.',
        style: TextStyle(
          fontSize: 40,
          height: 1.1,
          fontWeight: FontWeight.w800,
          letterSpacing: -1.5,
        ),
      ),
      const SizedBox(height: 16),
      const Text(
        'Search music and podcasts, browse your library, and control Spotify from here.',
        style: TextStyle(fontSize: 16, color: _muted),
      ),
      const SizedBox(height: 24),
      const _InfoCard(
        icon: Icons.speaker,
        title: 'Spotify plays the audio',
        body:
            'Use Spotify Premium on this phone. Open Spotify and play something, then return to Sona. Background playback and lock-screen controls stay with Spotify.',
      ),
      const SizedBox(height: 24),
      TextField(
        controller: _clientId,
        enabled: !c.connecting,
        autocorrect: false,
        enableSuggestions: false,
        decoration: const InputDecoration(
          labelText: 'Spotify Client ID',
          helperText: 'Use your existing developer app. No client secret.',
        ),
      ),
      const SizedBox(height: 16),
      FilledButton.icon(
        onPressed: c.connecting ? null : () => c.connect(_clientId.text),
        icon: const Icon(Icons.link),
        label: const Text('Connect Spotify'),
      ),
      TextButton(
        onPressed: c.connecting
            ? null
            : () => c.connect(_clientId.text, fresh: true),
        child: const Text('Try Chrome login'),
      ),
      OutlinedButton.icon(
        onPressed: _openSpotify,
        icon: const Icon(Icons.open_in_new),
        label: const Text('Open Spotify'),
      ),
      const SizedBox(height: 20),
      _setup(),
    ],
  );
  Widget _setup() => ExpansionTile(
    tilePadding: EdgeInsets.zero,
    title: const Text('Connection setup'),
    children: [
      const Text(
        'Keep Web API enabled and the same redirect URI in your Spotify developer dashboard. Reconnect to grant the new library and playback permissions.',
      ),
      const SizedBox(height: 12),
      const SelectableText(SpotifyAuth.redirectUri),
      TextButton.icon(
        onPressed: () async {
          await Clipboard.setData(
            const ClipboardData(text: SpotifyAuth.redirectUri),
          );
          _toast('Redirect URI copied');
        },
        icon: const Icon(Icons.copy, size: 18),
        label: const Text('Copy redirect URI'),
      ),
      const Text(
        'The app owner needs Premium. Test accounts must be allowed in the developer dashboard. Playback controls also require Premium on the connected account.',
      ),
      TextButton(
        onPressed: () =>
            _open(Uri.parse('https://developer.spotify.com/dashboard')),
        child: const Text('Open developer dashboard'),
      ),
    ],
  );
  Widget _home() => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(24, 14, 24, 8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Made of your favourites.',
              style: TextStyle(
                fontSize: 30,
                fontWeight: FontWeight.w800,
                letterSpacing: -1,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Your top tracks on Spotify',
              style: TextStyle(color: _muted),
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              children: [
                ActionChip(
                  avatar: const Icon(Icons.devices, size: 18),
                  label: const Text('Choose your phone'),
                  onPressed: _devices,
                ),
                ActionChip(
                  avatar: const Icon(Icons.open_in_new, size: 18),
                  label: const Text('Open Spotify'),
                  onPressed: _openSpotify,
                ),
              ],
            ),
          ],
        ),
      ),
      Expanded(
        child: _TopTracks(
          key: ValueKey('top-$_session'),
          controller: c,
          onTap: _play,
          onMenu: _menu,
        ),
      ),
    ],
  );
  Widget _settings() => ListView(
    padding: const EdgeInsets.all(24),
    children: [
      const Text(
        'Your connection',
        style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 16),
      _InfoCard(
        icon: Icons.check_circle_outline,
        title: 'Connected to Spotify',
        body:
            'Audio plays through Spotify. Sona sends playback commands over the internet using Spotify Connect.',
      ),
      ListTile(
        contentPadding: EdgeInsets.zero,
        leading: const Icon(Icons.devices),
        title: const Text('Playback device'),
        subtitle: Text(c.deviceName),
        onTap: _devices,
      ),
      OutlinedButton(
        onPressed: _openSpotify,
        child: const Text('Open Spotify'),
      ),
      const SizedBox(height: 16),
      _setup(),
      const SizedBox(height: 24),
      const Text('Privacy', style: TextStyle(fontWeight: FontWeight.bold)),
      const Text(
        'Only your Client ID is saved on this phone. Access and refresh tokens stay in memory and are cleared when you disconnect or the app process closes. Your music library stays with Spotify.',
      ),
      const SizedBox(height: 16),
      const Text(
        'Sona 3.0 · Spotify companion\nAn independent app. Music, artwork, and playback are provided by Spotify.',
        style: TextStyle(color: _muted, fontSize: 12),
      ),
      const SizedBox(height: 20),
      OutlinedButton(
        onPressed: c.commanding ? null : c.disconnect,
        child: const Text('Disconnect Spotify'),
      ),
    ],
  );
  Widget _miniPlayer() {
    final item = c.playback.item;
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 8),
      child: Material(
        color: const Color(0xFF293121),
        borderRadius: BorderRadius.circular(18),
        child: ListTile(
          onTap: _player,
          leading: _Art(item?.imageUrl, size: 44),
          title: Text(
            item?.title ?? 'Ready when Spotify is',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          subtitle: Text(
            '${c.deviceName} · Spotify',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          trailing: IconButton(
            tooltip: c.playback.playing ? 'Pause Spotify' : 'Resume Spotify',
            onPressed: c.allows(c.playback.playing ? 'pausing' : 'resuming')
                ? () => c.playback.playing ? c.action('pause') : c.play()
                : null,
            icon: Icon(
              c.playback.playing
                  ? Icons.pause_circle_filled
                  : Icons.play_circle_fill,
              size: 40,
              color: _lime,
            ),
          ),
        ),
      ),
    );
  }
}

class _Art extends StatelessWidget {
  const _Art(this.url, {this.size = 52});
  final String? url;
  final double size;
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(10),
    child: SizedBox.square(
      dimension: size,
      child: url == null
          ? _fallback()
          : Image.network(
              url!,
              fit: BoxFit.contain,
              errorBuilder: (_, _, _) => _fallback(),
            ),
    ),
  );
  Widget _fallback() => const ColoredBox(
    color: Color(0xFF293121),
    child: Icon(Icons.music_note, color: _lime),
  );
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({
    required this.icon,
    required this.title,
    required this.body,
  });
  final IconData icon;
  final String title, body;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: const Color(0xFF20261D),
      borderRadius: BorderRadius.circular(18),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: _lime),
        const SizedBox(height: 10),
        Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(body, style: const TextStyle(color: _muted)),
      ],
    ),
  );
}

typedef _ContentAction = void Function(SpotifyContent);

class _ContentList extends StatefulWidget {
  const _ContentList({
    super.key,
    required this.controller,
    required this.load,
    required this.empty,
    required this.onTap,
    required this.onMenu,
  });
  final SpotifyCompanionController controller;
  final Future<SpotifyPage> Function(int) load;
  final String empty;
  final _ContentAction onTap, onMenu;
  @override
  State<_ContentList> createState() => _ContentListState();
}

class _ContentListState extends State<_ContentList> {
  List<SpotifyContent> items = [];
  int? next;
  bool busy = false;
  String? error;
  @override
  void initState() {
    super.initState();
    unawaited(_load(reset: true));
  }

  Future<void> _load({bool reset = false}) async {
    if (busy) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final page = await widget.load(reset ? 0 : next ?? 0);
      if (mounted)
        setState(() {
          if (reset) items = [];
          final known = items.map((i) => i.uri).toSet();
          items.addAll(page.items.where((i) => known.add(i.uri)));
          next = page.nextOffset;
        });
    } catch (e) {
      if (mounted) setState(() => error = widget.controller.message(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => RefreshIndicator(
    onRefresh: () => _load(reset: true),
    child: ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        if (busy) const LinearProgressIndicator(),
        if (error != null)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text(error!),
                TextButton(
                  onPressed: busy ? null : () => _load(reset: items.isEmpty),
                  child: const Text('Retry'),
                ),
              ],
            ),
          ),
        if (!busy && error == null && items.isEmpty)
          Padding(padding: const EdgeInsets.all(24), child: Text(widget.empty)),
        ...items.map(
          (item) => ListTile(
            contentPadding: const EdgeInsets.symmetric(
              vertical: 4,
              horizontal: 4,
            ),
            leading: _Art(item.imageUrl),
            title: Text(
              item.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: Text(
              '${item.subtitle}${!item.playable ? ' · Unavailable' : ''}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            onTap: widget.controller.connected
                ? () => widget.onTap(item)
                : null,
            trailing: IconButton(
              tooltip: 'Track options',
              onPressed: widget.controller.connected
                  ? () => widget.onMenu(item)
                  : null,
              icon: const Icon(Icons.more_vert),
            ),
          ),
        ),
        if (next != null)
          TextButton(
            onPressed: busy ? null : () => _load(),
            child: const Text('Load more'),
          ),
        if (items.isNotEmpty)
          const Padding(
            padding: EdgeInsets.only(top: 16),
            child: Text(
              'Content provided by Spotify',
              textAlign: TextAlign.center,
              style: TextStyle(color: _muted, fontSize: 12),
            ),
          ),
      ],
    ),
  );
}

class _TopTracks extends StatefulWidget {
  const _TopTracks({
    super.key,
    required this.controller,
    required this.onTap,
    required this.onMenu,
  });
  final SpotifyCompanionController controller;
  final _ContentAction onTap, onMenu;
  @override
  State<_TopTracks> createState() => _TopTracksState();
}

class _TopTracksState extends State<_TopTracks> {
  String range = 'long_term';
  @override
  Widget build(BuildContext context) => Column(
    children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Wrap(
          spacing: 8,
          children: [
            for (final e in const {
              'short_term': '4 weeks',
              'medium_term': '6 months',
              'long_term': '1 year',
            }.entries)
              ChoiceChip(
                label: Text(e.value),
                selected: range == e.key,
                onSelected: (_) => setState(() => range = e.key),
              ),
          ],
        ),
      ),
      Expanded(
        child: _ContentList(
          key: ValueKey(range),
          controller: widget.controller,
          load: (offset) =>
              widget.controller.api.top(range: range, offset: offset),
          empty: 'No top tracks for this period yet. Try another range.',
          onTap: widget.onTap,
          onMenu: widget.onMenu,
        ),
      ),
    ],
  );
}

class _SearchTab extends StatefulWidget {
  const _SearchTab({
    super.key,
    required this.controller,
    required this.onTap,
    required this.onMenu,
  });
  final SpotifyCompanionController controller;
  final _ContentAction onTap, onMenu;
  @override
  State<_SearchTab> createState() => _SearchTabState();
}

class _SearchTabState extends State<_SearchTab> {
  final text = TextEditingController();
  String term = '', type = 'track';
  int revision = 0;
  @override
  void dispose() {
    text.dispose();
    super.dispose();
  }

  void _search() => setState(() {
    term = text.text.trim();
    revision++;
  });
  @override
  Widget build(BuildContext context) => Column(
    children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 8),
        child: TextField(
          controller: text,
          onSubmitted: (_) => _search(),
          textInputAction: TextInputAction.search,
          decoration: InputDecoration(
            hintText: 'Songs, artists, podcasts…',
            prefixIcon: const Icon(Icons.search),
            suffixIcon: IconButton(
              onPressed: _search,
              icon: const Icon(Icons.arrow_forward),
            ),
          ),
        ),
      ),
      SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Row(
          children: [
            for (final e in const {
              'track': 'Songs',
              'album': 'Albums',
              'playlist': 'Playlists',
              'show': 'Podcasts',
              'episode': 'Episodes',
            }.entries)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(e.value),
                  selected: type == e.key,
                  onSelected: (_) => setState(() => type = e.key),
                ),
              ),
          ],
        ),
      ),
      Expanded(
        child: term.isEmpty
            ? const Center(child: Text('Find your next favourite on Spotify.'))
            : _ContentList(
                key: ValueKey('$term-$type-$revision'),
                controller: widget.controller,
                load: (offset) =>
                    widget.controller.api.search(term, type, offset: offset),
                empty: 'No results. Try another search.',
                onTap: widget.onTap,
                onMenu: widget.onMenu,
              ),
      ),
    ],
  );
}

class _LibraryTab extends StatefulWidget {
  const _LibraryTab({
    super.key,
    required this.controller,
    required this.onTap,
    required this.onMenu,
  });
  final SpotifyCompanionController controller;
  final _ContentAction onTap, onMenu;
  @override
  State<_LibraryTab> createState() => _LibraryTabState();
}

class _LibraryTabState extends State<_LibraryTab> {
  String kind = 'playlists';
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(24, 16, 24, 12),
        child: Text(
          'Your Spotify library',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Wrap(
          spacing: 8,
          children: [
            for (final e in const {
              'playlists': 'Playlists',
              'tracks': 'Liked songs',
              'shows': 'Podcasts',
            }.entries)
              ChoiceChip(
                label: Text(e.value),
                selected: kind == e.key,
                onSelected: (_) => setState(() => kind = e.key),
              ),
          ],
        ),
      ),
      Expanded(
        child: _ContentList(
          key: ValueKey(kind),
          controller: widget.controller,
          load: (offset) => widget.controller.api.library(kind, offset: offset),
          empty:
              'Nothing saved here yet. Save content in Spotify or use Search.',
          onTap: widget.onTap,
          onMenu: widget.onMenu,
        ),
      ),
    ],
  );
}

class _CollectionScreen extends StatelessWidget {
  const _CollectionScreen({
    required this.item,
    required this.controller,
    required this.onPlay,
    required this.onMenu,
    required this.onOpen,
  });
  final SpotifyContent item;
  final SpotifyCompanionController controller;
  final _ContentAction onPlay, onMenu;
  final Future<void> Function(Uri) onOpen;
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(item.title)),
    body: SafeArea(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                _Art(item.imageUrl, size: 80),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.title,
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      Text(
                        item.subtitle,
                        style: const TextStyle(color: _muted),
                      ),
                      if (item.type != 'show')
                        FilledButton.icon(
                          onPressed: () => onPlay(item),
                          icon: const Icon(Icons.play_arrow),
                          label: const Text('Play on Spotify'),
                        ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          if (item.type == 'playlist')
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'Spotify may only show tracks in playlists you own or collaborate on. You can still try playing the playlist.',
                style: TextStyle(fontSize: 12, color: _muted),
              ),
            ),
          TextButton.icon(
            onPressed: () => onOpen(item.webUrl),
            icon: const Icon(Icons.open_in_new, size: 16),
            label: const Text('Open in Spotify'),
          ),
          Expanded(
            child: _ContentList(
              controller: controller,
              load: (offset) => controller.api.collection(item, offset: offset),
              empty: 'No available items in this collection.',
              onTap: onPlay,
              onMenu: onMenu,
            ),
          ),
        ],
      ),
    ),
  );
}

class _DevicePicker extends StatefulWidget {
  const _DevicePicker({required this.controller, required this.openSpotify});
  final SpotifyCompanionController controller;
  final Future<void> Function() openSpotify;
  @override
  State<_DevicePicker> createState() => _DevicePickerState();
}

class _DevicePickerState extends State<_DevicePicker> {
  List<SpotifyDevice> devices = [];
  bool busy = false;
  String? error;
  @override
  void initState() {
    super.initState();
    unawaited(_refresh());
  }

  Future<void> _refresh() async {
    if (busy) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final result = await widget.controller.api.devices();
      if (mounted) setState(() => devices = result);
    } catch (e) {
      if (mounted) setState(() => error = widget.controller.message(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _select(SpotifyDevice device) async {
    if (busy) return;
    setState(() {
      busy = true;
      error = null;
    });
    final ok = await widget.controller.selectDevice(device);
    if (!mounted) return;
    if (ok) {
      Navigator.pop(context);
      return;
    }
    setState(() {
      busy = false;
      error = widget.controller.error ?? 'Could not select this device.';
    });
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: SizedBox(
      height: MediaQuery.sizeOf(context).height * .65,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
        children: [
          const Text(
            'Listen on your phone',
            style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          const Text(
            'Open Spotify, play a song, then return and refresh. Use the same Spotify account in both apps. Choosing a device moves the Spotify session there without starting playback.',
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            children: [
              OutlinedButton(
                onPressed: widget.openSpotify,
                child: const Text('Open Spotify'),
              ),
              TextButton.icon(
                onPressed: busy ? null : _refresh,
                icon: const Icon(Icons.refresh),
                label: const Text('Refresh devices'),
              ),
            ],
          ),
          if (busy) const LinearProgressIndicator(),
          if (error != null)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Text(
                error!,
                style: const TextStyle(color: Colors.orangeAccent),
              ),
            ),
          if (!busy && error == null && devices.isEmpty)
            const Padding(
              padding: EdgeInsets.all(20),
              child: Text('No Spotify devices found yet.'),
            ),
          ...devices.map(
            (d) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(
                d.type.toLowerCase() == 'smartphone'
                    ? Icons.phone_android
                    : Icons.speaker,
              ),
              title: Text(d.name),
              subtitle: Text(
                d.restricted
                    ? 'Spotify does not allow remote control'
                    : d.active
                    ? 'Currently active'
                    : d.type,
              ),
              trailing: d.id == widget.controller.target
                  ? const Icon(Icons.check_circle, color: _lime)
                  : null,
              enabled: !busy && !d.restricted,
              onTap: () => _select(d),
            ),
          ),
        ],
      ),
    ),
  );
}

class _FullPlayer extends StatefulWidget {
  const _FullPlayer({
    required this.controller,
    required this.devices,
    required this.openSpotify,
    required this.onMenu,
    required this.onQueue,
  });
  final SpotifyCompanionController controller;
  final Future<void> Function() devices, openSpotify;
  final _ContentAction onMenu;
  final VoidCallback onQueue;
  @override
  State<_FullPlayer> createState() => _FullPlayerState();
}

class _FullPlayerState extends State<_FullPlayer> {
  Timer? _ticker;
  double? _drag;
  String? _dragItem;
  @override
  void initState() {
    super.initState();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  String _time(int ms) =>
      '${ms ~/ 60000}:${((ms ~/ 1000) % 60).toString().padLeft(2, '0')}';
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: widget.controller,
    builder: (context, _) {
      final c = widget.controller;
      final item = c.playback.item;
      final duration = item?.durationMs ?? 0;
      final position = _dragItem == item?.uri && _drag != null
          ? _drag!
          : c.positionMs.toDouble();
      return SafeArea(
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height * .88,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(28, 4, 28, 24),
            children: [
              const Text(
                'PLAYING THROUGH SPOTIFY',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11, letterSpacing: 2, color: _muted),
              ),
              const SizedBox(height: 20),
              Center(
                child: _Art(
                  item?.imageUrl,
                  size: MediaQuery.sizeOf(context).width.clamp(180, 330) - 48,
                ),
              ),
              const SizedBox(height: 20),
              Text(
                item?.title ?? 'Start something in Spotify',
                style: const TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                item?.subtitle ?? 'Then control playback from Sona.',
                style: const TextStyle(color: _muted),
              ),
              if (c.error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(
                    c.error!,
                    style: const TextStyle(color: Colors.orangeAccent),
                  ),
                ),
              Slider(
                value: position.clamp(
                  0,
                  duration > 0 ? duration.toDouble() : 1.0,
                ),
                max: duration > 0 ? duration.toDouble() : 1,
                onChanged: duration > 0 && c.allows('seeking')
                    ? (value) => setState(() {
                        _drag = value;
                        _dragItem = item?.uri;
                      })
                    : null,
                onChangeEnd: (value) async {
                  final id = _dragItem;
                  setState(() {
                    _drag = null;
                    _dragItem = null;
                  });
                  if (id == c.playback.item?.uri)
                    await c.action('seek', position: value.round());
                },
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _time(position.toInt()),
                    style: const TextStyle(color: _muted, fontSize: 12),
                  ),
                  Text(
                    _time(duration),
                    style: const TextStyle(color: _muted, fontSize: 12),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  IconButton(
                    tooltip: 'Shuffle',
                    onPressed: c.allows('toggling_shuffle')
                        ? () =>
                              c.action('shuffle', shuffle: !c.playback.shuffle)
                        : null,
                    icon: Icon(
                      Icons.shuffle,
                      color: c.playback.shuffle ? _lime : null,
                    ),
                  ),
                  IconButton(
                    tooltip: 'Previous',
                    onPressed: c.allows('skipping_prev')
                        ? () => c.action('previous')
                        : null,
                    icon: const Icon(Icons.skip_previous, size: 32),
                  ),
                  IconButton(
                    tooltip: c.playback.playing ? 'Pause' : 'Resume',
                    onPressed:
                        c.allows(c.playback.playing ? 'pausing' : 'resuming')
                        ? () =>
                              c.playback.playing ? c.action('pause') : c.play()
                        : null,
                    icon: Icon(
                      c.playback.playing
                          ? Icons.pause_circle_filled
                          : Icons.play_circle_fill,
                      color: c.canControl ? _lime : _muted,
                      size: 68,
                    ),
                  ),
                  IconButton(
                    tooltip: 'Next',
                    onPressed: c.allows('skipping_next')
                        ? () => c.action('next')
                        : null,
                    icon: const Icon(Icons.skip_next, size: 32),
                  ),
                  IconButton(
                    tooltip: 'Repeat: ${c.playback.repeat}',
                    onPressed:
                        c.allows('toggling_repeat_context') &&
                            c.allows('toggling_repeat_track')
                        ? () => c.action(
                            'repeat',
                            repeat: switch (c.playback.repeat) {
                              'off' => 'context',
                              'context' => 'track',
                              _ => 'off',
                            },
                          )
                        : null,
                    icon: Icon(
                      c.playback.repeat == 'track'
                          ? Icons.repeat_one
                          : Icons.repeat,
                      color: c.playback.repeat == 'off' ? null : _lime,
                    ),
                  ),
                ],
              ),
              if (c.commanding) const LinearProgressIndicator(),
              TextButton.icon(
                onPressed: widget.devices,
                icon: const Icon(Icons.devices, size: 18),
                label: Text(c.deviceName),
              ),
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 12,
                children: [
                  TextButton.icon(
                    onPressed: widget.onQueue,
                    icon: const Icon(Icons.queue_music),
                    label: const Text('Queue'),
                  ),
                  if (item != null)
                    TextButton.icon(
                      onPressed: () => widget.onMenu(item),
                      icon: const Icon(Icons.more_horiz),
                      label: const Text('Options'),
                    ),
                  TextButton.icon(
                    onPressed: widget.openSpotify,
                    icon: const Icon(Icons.open_in_new),
                    label: const Text('Open Spotify'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                'Spotify handles sound, downloads, background playback, and lock-screen controls. Keep Spotify installed and signed in.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: _muted),
              ),
            ],
          ),
        ),
      );
    },
  );
}
