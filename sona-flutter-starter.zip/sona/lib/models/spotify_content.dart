class SpotifyContent {
  const SpotifyContent({
    required this.id,
    required this.type,
    required this.title,
    required this.subtitle,
    required this.uri,
    this.imageUrl,
    this.durationMs = 0,
    this.playable = true,
  });
  final String id, type, title, subtitle, uri;
  final String? imageUrl;
  final int durationMs;
  final bool playable;
  bool get isCollection =>
      type == 'album' || type == 'playlist' || type == 'show';
  bool get isAudio => type == 'track' || type == 'episode';
  Uri get webUrl => Uri.https('open.spotify.com', '/$type/$id');
  static Map<String, dynamic> map(Object? value) =>
      value is Map ? Map<String, dynamic>.from(value) : <String, dynamic>{};
  factory SpotifyContent.fromJson(
    Map<String, dynamic> data, {
    String? type,
    String? subtitle,
  }) {
    final kind = type ?? data['type'] as String? ?? 'track';
    final id = data['id'] as String? ?? '';
    if (!RegExp(r'^[a-zA-Z0-9]+$').hasMatch(id) ||
        !['track', 'episode', 'album', 'playlist', 'show'].contains(kind)) {
      throw const FormatException('Unsupported or unavailable Spotify item');
    }
    final album = map(data['album']);
    final show = map(data['show']);
    final images = data['images'] ?? album['images'] ?? show['images'];
    String? image;
    if (images is List) {
      for (final entry in images) {
        final value = map(entry)['url'];
        final parsed = value is String ? Uri.tryParse(value) : null;
        if (parsed?.scheme == 'https' && parsed!.host.isNotEmpty) {
          image = value as String;
          break;
        }
      }
    }
    final artists = (data['artists'] as List? ?? [])
        .map((a) => map(a)['name'])
        .whereType<String>()
        .join(', ');
    final by = artists.isNotEmpty
        ? artists
        : subtitle ??
              show['name'] as String? ??
              map(data['owner'])['display_name'] as String? ??
              data['publisher'] as String? ??
              (kind == 'show' ? 'Podcast on Spotify' : 'Spotify');
    return SpotifyContent(
      id: id,
      type: kind,
      title: data['name'] as String? ?? 'Untitled',
      subtitle: by,
      uri: 'spotify:$kind:$id',
      imageUrl: image,
      durationMs: (data['duration_ms'] as num?)?.toInt() ?? 0,
      playable: data['is_playable'] != false && data['is_local'] != true,
    );
  }
}

class SpotifyPage {
  const SpotifyPage(this.items, this.nextOffset);
  final List<SpotifyContent> items;
  final int? nextOffset;
  factory SpotifyPage.fromJson(
    Map<String, dynamic> json, {
    String? type,
    String? subtitle,
    String? wrapper,
  }) {
    final items = <SpotifyContent>[];
    for (final raw in json['items'] as List? ?? []) {
      var data = SpotifyContent.map(raw);
      if (wrapper != null)
        data = SpotifyContent.map(data[wrapper] ?? data['track']);
      if (data.isEmpty) continue;
      try {
        items.add(
          SpotifyContent.fromJson(data, type: type, subtitle: subtitle),
        );
      } on FormatException {
        /* Removed/local items cannot be controlled by URI. */
      }
    }
    final next = json['next'];
    // Never fetch an arbitrary URL returned by the API with an access token.
    final nextUri = next is String ? Uri.tryParse(next) : null;
    return SpotifyPage(
      items,
      nextUri == null
          ? null
          : int.tryParse(nextUri.queryParameters['offset'] ?? ''),
    );
  }
}

class SpotifyDevice {
  const SpotifyDevice({
    required this.id,
    required this.name,
    required this.type,
    required this.active,
    required this.restricted,
  });
  final String id, name, type;
  final bool active, restricted;
  factory SpotifyDevice.fromJson(Map<String, dynamic> json) => SpotifyDevice(
    id: json['id'] as String? ?? '',
    name: json['name'] as String? ?? 'Spotify device',
    type: json['type'] as String? ?? 'Unknown',
    active: json['is_active'] == true,
    restricted: json['is_restricted'] == true,
  );
}

class SpotifyPlayback {
  const SpotifyPlayback({
    this.item,
    this.device,
    this.playing = false,
    this.positionMs = 0,
    this.shuffle = false,
    this.repeat = 'off',
    this.disallowed = const {},
  });
  final SpotifyContent? item;
  final SpotifyDevice? device;
  final bool playing, shuffle;
  final int positionMs;
  final String repeat;
  final Set<String> disallowed;
  bool allows(String action) =>
      !disallowed.contains(action) && device?.restricted != true;
  factory SpotifyPlayback.fromJson(Map<String, dynamic> data) {
    SpotifyContent? item;
    try {
      final raw = SpotifyContent.map(data['item']);
      if (raw.isNotEmpty) item = SpotifyContent.fromJson(raw);
    } on FormatException {
      /* Ads and unsupported items have no playable URI. */
    }
    final blocked = SpotifyContent.map(
      SpotifyContent.map(data['actions'])['disallows'],
    );
    return SpotifyPlayback(
      item: item,
      device: data['device'] == null
          ? null
          : SpotifyDevice.fromJson(SpotifyContent.map(data['device'])),
      playing: data['is_playing'] == true,
      positionMs: (data['progress_ms'] as num?)?.toInt() ?? 0,
      shuffle: data['shuffle_state'] == true,
      repeat: data['repeat_state'] as String? ?? 'off',
      disallowed: blocked.entries
          .where((e) => e.value == true)
          .map((e) => e.key)
          .toSet(),
    );
  }
}
