class SpotifyTrack {
  const SpotifyTrack({required this.id, required this.title,
    required this.artists, required this.url, this.imageUrl});

  final String id;
  final String title;
  final String artists;
  final Uri url;
  final Uri? imageUrl;

  factory SpotifyTrack.fromJson(Map<String, dynamic> json) {
    final external = json['external_urls'];
    final link = external is Map ? external['spotify'] : null;
    final url = Uri.tryParse(link is String ? link : '');
    if (url == null || url.scheme != 'https' || url.host != 'open.spotify.com') {
      throw const FormatException('Missing Spotify track link');
    }
    final artistData = json['artists'];
    final artists = artistData is List ? artistData.whereType<Map>()
        .map((artist) => artist['name']).whereType<String>().join(', ') : '';
    final album = json['album'];
    final images = album is Map ? album['images'] : null;
    Uri? image;
    if (images is List) {
      for (final entry in images.whereType<Map>()) {
        final value = entry['url'];
        final candidate = value is String ? Uri.tryParse(value) : null;
        if (candidate?.scheme == 'https') { image = candidate; break; }
      }
    }
    return SpotifyTrack(id: json['id'] as String, title: json['name'] as String,
      artists: artists.isEmpty ? 'Unknown artist' : artists, url: url, imageUrl: image);
  }
}
