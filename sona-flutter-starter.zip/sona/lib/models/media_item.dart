enum MediaKind { music, podcast }

class MediaItem {
  const MediaItem({required this.id, required this.title, required this.creator,
    required this.category, required this.kind, required this.source,
    required this.color, required this.art, required this.description});

  final String id;
  final String title;
  final String creator;
  final String category;
  final MediaKind kind;
  final String source;
  final int color;
  final int art;
  final String description;
  bool get isPodcast => kind == MediaKind.podcast;
}

class UserPlaylist {
  UserPlaylist({required this.id, required this.name, List<String>? itemIds})
      : itemIds = itemIds ?? [];
  final String id;
  final String name;
  final List<String> itemIds;

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'itemIds': itemIds};
  factory UserPlaylist.fromJson(Map<String, dynamic> json) => UserPlaylist(
    id: json['id'] as String,
    name: json['name'] as String,
    itemIds: List<String>.from(json['itemIds'] as List),
  );
}
