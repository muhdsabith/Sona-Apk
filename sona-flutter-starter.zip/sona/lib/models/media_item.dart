enum MediaKind { music, podcast }

class MediaItem {
  const MediaItem({
    required this.id,
    required this.title,
    required this.creator,
    required this.category,
    required this.kind,
    required this.source,
    required this.color,
    required this.art,
    required this.description,
    this.artworkUrl,
    this.feedUrl,
    this.durationMs,
  });
  final String id, title, creator, category, source, description;
  final MediaKind kind;
  final int color, art;
  final String? artworkUrl, feedUrl;
  final int? durationMs;
  bool get isPodcast => kind == MediaKind.podcast;
  bool get isLocal => source.startsWith('local:');
  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'creator': creator,
    'category': category,
    'kind': kind.name,
    'source': source,
    'color': color,
    'art': art,
    'description': description,
    'artworkUrl': artworkUrl,
    'feedUrl': feedUrl,
    'durationMs': durationMs,
  };
  factory MediaItem.fromJson(Map<String, dynamic> j) => MediaItem(
    id: j['id'] as String,
    title: j['title'] as String,
    creator: j['creator'] as String,
    category: j['category'] as String? ?? 'Your music',
    kind: j['kind'] == 'podcast' ? MediaKind.podcast : MediaKind.music,
    source: j['source'] as String,
    color: j['color'] as int? ?? 0xFFC9F27A,
    art: j['art'] as int? ?? 0,
    description: j['description'] as String? ?? '',
    artworkUrl: j['artworkUrl'] as String?,
    feedUrl: j['feedUrl'] as String?,
    durationMs: j['durationMs'] as int?,
  );
}

class PodcastFeed {
  const PodcastFeed({
    required this.url,
    required this.title,
    required this.creator,
    this.artworkUrl,
  });
  final String url, title, creator;
  final String? artworkUrl;
  Map<String, dynamic> toJson() => {
    'url': url,
    'title': title,
    'creator': creator,
    'artworkUrl': artworkUrl,
  };
  factory PodcastFeed.fromJson(Map<String, dynamic> j) => PodcastFeed(
    url: j['url'] as String,
    title: j['title'] as String,
    creator: j['creator'] as String? ?? '',
    artworkUrl: j['artworkUrl'] as String?,
  );
}

class UserPlaylist {
  UserPlaylist({required this.id, required this.name, List<String>? itemIds})
    : itemIds = itemIds ?? [];
  final String id;
  String name;
  final List<String> itemIds;
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'itemIds': itemIds};
  factory UserPlaylist.fromJson(Map<String, dynamic> j) => UserPlaylist(
    id: j['id'] as String,
    name: j['name'] as String,
    itemIds: List<String>.from(j['itemIds'] as List),
  );
}
