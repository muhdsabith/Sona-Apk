class Track {
  const Track({
    required this.name,
    required this.artistName,
    required this.imageUrl,
    required this.url,
  });
  final String name, artistName, imageUrl, url;

  static String _text(Object? value) => value is String ? value.trim() : '';
  static String _https(Object? value) {
    final uri = Uri.tryParse(_text(value));
    if (uri == null ||
        !uri.hasAuthority ||
        uri.host.isEmpty ||
        uri.userInfo.isNotEmpty ||
        !['http', 'https'].contains(uri.scheme))
      return '';
    return uri.replace(scheme: 'https').toString();
  }

  factory Track.fromJson(Map<String, dynamic> json) {
    final rawArtist = json['artist'];
    final artist = rawArtist is Map
        ? _text(rawArtist['name']).isNotEmpty
              ? _text(rawArtist['name'])
              : _text(rawArtist['#text'])
        : _text(rawArtist);
    final images = json['image'];
    String image = '';
    int best = -1;
    if (images is List) {
      for (final entry in images) {
        if (entry is! Map) continue;
        final candidate = _https(entry['#text']);
        final rank = [
          'small',
          'medium',
          'large',
          'extralarge',
          'mega',
        ].indexOf(_text(entry['size']));
        if (candidate.isNotEmpty && rank >= best) {
          image = candidate;
          best = rank;
        }
      }
    }
    final name = _text(json['name']);
    final link = _https(json['url']);
    final host = Uri.tryParse(link)?.host ?? '';
    return Track(
      name: name.isEmpty ? 'Unknown Track' : name,
      artistName: artist.isEmpty ? 'Unknown Artist' : artist,
      imageUrl: image,
      url: host == 'last.fm' || host.endsWith('.last.fm') ? link : '',
    );
  }
}
