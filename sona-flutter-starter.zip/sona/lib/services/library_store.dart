import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/media_item.dart';

class LibrarySnapshot {
  LibrarySnapshot({Set<String>? likes, List<UserPlaylist>? playlists,
    Map<String, int>? progress})
      : likes = likes ?? {}, playlists = playlists ?? [], progress = progress ?? {};
  final Set<String> likes;
  final List<UserPlaylist> playlists;
  final Map<String, int> progress;
}

class LibraryStore {
  final SharedPreferencesAsync _prefs = SharedPreferencesAsync();
  Future<void> _writes = Future<void>.value();
  static const _key = 'sona.library.v1';

  Future<LibrarySnapshot> read() async {
    final raw = await _prefs.getString(_key);
    if (raw == null) return LibrarySnapshot();
    final data = jsonDecode(raw) as Map<String, dynamic>;
    return LibrarySnapshot(
      likes: Set<String>.from(data['likes'] as List),
      playlists: (data['playlists'] as List).map((p) =>
        UserPlaylist.fromJson(Map<String, dynamic>.from(p as Map))).toList(),
      progress: Map<String, int>.from(data['progress'] as Map),
    );
  }

  Future<void> save(LibrarySnapshot snapshot) {
    final encoded = jsonEncode({
      'likes': snapshot.likes.toList(),
      'playlists': snapshot.playlists.map((p) => p.toJson()).toList(),
      'progress': snapshot.progress,
    });
    final write = _writes.then((_) => _prefs.setString(_key, encoded));
    _writes = write.catchError((Object _) {});
    return write;
  }
}
