import 'dart:async';
import 'package:youtube_explode_dart/youtube_explode_dart.dart' as yt;
import '../models/media_item.dart';

class OnlineMusicException implements Exception {
  const OnlineMusicException(this.message);
  final String message;
  @override
  String toString() => message;
}

class OnlinePage {
  const OnlinePage(this.items, {this.next});
  final List<MediaItem> items;
  final Future<OnlinePage?> Function()? next;
}

class ResolvedAudio {
  const ResolvedAudio(this.url, this.headers);
  final Uri url;
  final Map<String, String> headers;
}

class OnlineMusicApi {
  OnlineMusicApi({
    yt.YoutubeExplode Function()? clientFactory,
    DateTime Function()? now,
  }) : _factory = clientFactory ?? (() => yt.YoutubeExplode()),
       _now = now ?? DateTime.now {
    _client = _factory();
  }
  final yt.YoutubeExplode Function() _factory;
  final DateTime Function() _now;
  late final yt.YoutubeExplode _client;
  DateTime? _retryAt;

  void _checkConnection() {
    if (_disposed)
      throw const OnlineMusicException(
        'The music connection is closed. Reopen Raaga.',
      );
    final remaining =
        ((_retryAt?.difference(_now()).inMilliseconds ?? 0) / 1000).ceil();
    if (remaining >= 0 && _retryAt != null && _now().isBefore(_retryAt!)) {
      throw OnlineMusicException(
        'YouTube is limiting requests. Try again in ${remaining} seconds, or open the song in YouTube.',
      );
    }
  }

  OnlineMusicException _rateLimited() {
    _retryAt = _now().add(const Duration(seconds: 60));
    return const OnlineMusicException(
      'YouTube is limiting requests. Raaga has paused new requests for one minute. You can open the song in YouTube.',
    );
  }

  static final _headers = yt.clientRequestHeaders(yt.YoutubeApiClient.visionOs);
  static const _timeout = Duration(seconds: 30);
  static const playbackTimeout = Duration(seconds: 75);
  final Set<yt.YoutubeExplode> _resolving = {};
  bool _disposed = false;

  static String videoId(String source) {
    final id = source.startsWith('youtube:') ? source.substring(8) : '';
    if (!RegExp(r'^[a-zA-Z0-9_-]{11}$').hasMatch(id)) {
      throw const OnlineMusicException('This song has an invalid video ID.');
    }
    return id;
  }

  Future<OnlinePage> search(String query) async {
    if (query.trim().isEmpty) return const OnlinePage([]);
    _checkConnection();
    try {
      final page = await _client.search.search(query.trim()).timeout(_timeout);
      return _page(page);
    } on yt.RequestLimitExceededException {
      throw _rateLimited();
    } catch (_) {
      throw const OnlineMusicException(
        'Online search is unavailable. Check your connection and try again.',
      );
    }
  }

  OnlinePage _page(yt.VideoSearchList page) => OnlinePage(
    page
        .where((v) => !v.isLive)
        .map(
          (v) => MediaItem(
            id: 'youtube-${v.id.value}',
            title: v.title,
            creator: v.author,
            category: 'YouTube',
            kind: MediaKind.music,
            source: 'youtube:${v.id.value}',
            color: 0xFFD4BFA5,
            art: 0,
            description: 'From YouTube · ${v.author}',
            artworkUrl: v.thumbnails.highResUrl,
            durationMs: v.duration?.inMilliseconds,
          ),
        )
        .toList(),
    next: () async {
      _checkConnection();
      try {
        final next = await page.nextPage().timeout(_timeout);
        return next == null ? null : _page(next);
      } on yt.RequestLimitExceededException {
        throw _rateLimited();
      } catch (_) {
        throw const OnlineMusicException(
          'Could not load more songs. Try again.',
        );
      }
    },
  );

  Future<ResolvedAudio> resolve(MediaItem item) async {
    final id = videoId(item.source);
    _checkConnection();
    final resolver = _factory();
    _resolving.add(resolver);
    try {
      final manifest = await resolver.videos.streams
          .getManifest(
            id,
            ytClients: [yt.YoutubeApiClient.visionOs],
            requireWatchPage: true,
          )
          .timeout(playbackTimeout);
      final streams = manifest.audioOnly.toList();
      final selected = chooseStream(streams);
      final url = selected.url;
      if (url.scheme != 'https')
        throw const OnlineMusicException(
          'This song returned an unsupported stream.',
        );
      return ResolvedAudio(url, Map<String, String>.from(_headers));
    } on OnlineMusicException {
      rethrow;
    } on TimeoutException {
      throw const OnlineMusicException(
        'Loading this song took too long. Check your connection and tap play to retry.',
      );
    } on yt.RequestLimitExceededException {
      throw _rateLimited();
    } on yt.VideoRequiresPurchaseException {
      throw const OnlineMusicException(
        'This song requires access through YouTube and cannot play here.',
      );
    } on yt.VideoUnplayableException {
      throw const OnlineMusicException(
        'YouTube does not allow this song to play here. Try another song.',
      );
    } catch (_) {
      throw const OnlineMusicException(
        'Could not load this song from YouTube. Tap play to retry or try another song.',
      );
    } finally {
      _resolving.remove(resolver);
      resolver.close();
    }
  }

  static yt.AudioOnlyStreamInfo chooseStream(
    Iterable<yt.AudioOnlyStreamInfo> available,
  ) {
    final streams = available.toList();
    if (streams.isEmpty) {
      throw const OnlineMusicException(
        'This song has no available audio stream. Try another song.',
      );
    }
    streams.sort((a, b) {
      final aDefault = a.audioTrack == null || a.audioTrack!.audioIsDefault;
      final bDefault = b.audioTrack == null || b.audioTrack!.audioIsDefault;
      if (aDefault != bDefault) return aDefault ? -1 : 1;
      final aMp4 = a.container.name == 'mp4' ? 1 : 0;
      final bMp4 = b.container.name == 'mp4' ? 1 : 0;
      final codec = bMp4.compareTo(aMp4);
      return codec != 0
          ? codec
          : b.bitrate.bitsPerSecond.compareTo(a.bitrate.bitsPerSecond);
    });
    return streams.first;
  }

  void dispose() {
    _disposed = true;
    _client.close();
    for (final resolver in _resolving) {
      resolver.close();
    }
    _resolving.clear();
  }
}
