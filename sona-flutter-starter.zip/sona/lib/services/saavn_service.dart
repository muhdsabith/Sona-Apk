import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/media_item.dart';

class SaavnException implements Exception {
  const SaavnException(this.message);
  final String message;
  @override
  String toString() => message;
}

class SaavnPage {
  const SaavnPage(this.items, this.nextPage);
  final List<MediaItem> items;
  final int? nextPage;
}

class SaavnService {
  SaavnService({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;
  String baseUrl = '';
  bool get configured => baseUrl.isNotEmpty;
  static String validateBase(String value) {
    value = value.trim();
    if (value.isEmpty) return '';
    final u = Uri.tryParse(value);
    if (u == null ||
        u.scheme != 'https' ||
        u.host.isEmpty ||
        u.userInfo.isNotEmpty ||
        u.hasQuery ||
        u.hasFragment) {
      throw const SaavnException(
        'Enter your server HTTPS address without a query or password.',
      );
    }
    return value.replaceFirst(RegExp(r'/+$'), '');
  }

  Future<Map<String, dynamic>> _get(
    String route,
    Map<String, String> params,
  ) async {
    if (!configured)
      throw const SaavnException('Add your Saavn server in Settings first.');
    try {
      final response = await _client
          .get(Uri.parse('$baseUrl/$route').replace(queryParameters: params))
          .timeout(const Duration(seconds: 22));
      if (response.statusCode == 429)
        throw const SaavnException('Server busy. Please try again later.');
      if (response.statusCode != 200)
        throw const SaavnException(
          'The music server could not complete this request. Try later.',
        );
      final data = jsonDecode(response.body);
      if (data is! Map<String, dynamic>) throw const FormatException();
      return data;
    } on SaavnException {
      rethrow;
    } catch (_) {
      throw const SaavnException(
        'Cannot reach a compatible music server. Check the address and connection.',
      );
    }
  }

  Future<void> check() async {
    final data = await _get('health', {});
    if (data['service'] != 'raaga-saavn' || data['version'] != 1) {
      throw const SaavnException(
        'This address is not a compatible Raaga server.',
      );
    }
  }

  Future<SaavnPage> search(String query, {int page = 1}) async {
    final data = await _get('search', {'q': query.trim(), 'page': '$page'});
    if (data['items'] is! List)
      throw const SaavnException(
        'The music server returned an invalid song list.',
      );
    final items = <MediaItem>[];
    final seen = <String>{};
    for (final raw in data['items'] as List) {
      if (raw is! Map) continue;
      final id = raw['id'];
      final title = raw['title'];
      if (id is! String ||
          !RegExp(r'^[\w-]{1,80}$').hasMatch(id) ||
          title is! String ||
          title.isEmpty ||
          !seen.add(id))
        continue;
      final image = raw['image'] is String
          ? Uri.tryParse(raw['image'] as String)
          : null;
      items.add(
        MediaItem(
          id: 'saavn:$id',
          title: title,
          creator: raw['artist'] is String
              ? raw['artist'] as String
              : 'Unknown artist',
          category: 'JioSaavn',
          kind: MediaKind.music,
          source: 'saavn:$id',
          color: 0xFFCF9DEB,
          art: 0,
          description: 'Music via your Saavn server',
          artworkUrl: image?.scheme == 'https' && image!.host.isNotEmpty
              ? image.toString()
              : null,
          durationMs: raw['durationMs'] is int && (raw['durationMs'] as int) > 0
              ? raw['durationMs'] as int
              : null,
        ),
      );
    }
    final next = data['nextPage'];
    return SaavnPage(
      items,
      next is int && next == page + 1 && next <= 50 ? next : null,
    );
  }

  Future<String> resolve(MediaItem item) async {
    if (!item.isSaavn) throw const SaavnException('Invalid Saavn song.');
    final data = await _get('stream', {'id': item.source.substring(6)});
    final value = data['url'];
    final u = value is String ? Uri.tryParse(value) : null;
    if (u == null ||
        u.scheme != 'https' ||
        u.host.isEmpty ||
        u.userInfo.isNotEmpty) {
      throw const SaavnException('No supported audio stream is available.');
    }
    return u.toString();
  }

  void dispose() => _client.close();
}
