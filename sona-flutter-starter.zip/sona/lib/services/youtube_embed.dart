import 'dart:convert';

class YoutubeEmbed {
  static const appId = String.fromEnvironment(
    'OLAM_APP_ID',
    defaultValue: 'com.example.sona',
  );
  static String get origin {
    if (!RegExp(r'^[a-zA-Z0-9]+(?:[._-][a-zA-Z0-9]+)+$').hasMatch(appId)) {
      throw StateError('Invalid installed application ID');
    }
    return 'https://${appId.toLowerCase()}';
  }

  static String idFromSource(String source) {
    final id = source.startsWith('youtube:') ? source.substring(8) : '';
    if (!RegExp(r'^[a-zA-Z0-9_-]{11}$').hasMatch(id)) {
      throw const FormatException('Invalid YouTube video ID');
    }
    return id;
  }

  static String errorMessage(int code) => switch (code) {
    2 => 'This video link is invalid.',
    5 => 'YouTube could not play this video in the player.',
    100 => 'This video is unavailable or private.',
    101 || 150 =>
      'The owner does not allow this video to play inside other apps. Open it in YouTube.',
    153 =>
      'YouTube could not verify this app’s player identity. Report code YT153 with your app version.',
    _ =>
      'YouTube could not play this video (YT$code). Try another song or open it in YouTube.',
  };

  static String html(String source) {
    final id = idFromSource(source);
    return '''<!doctype html>
<html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="referrer" content="strict-origin-when-cross-origin">
<style>html,body{margin:0;width:100%;height:100%;background:#000;overflow:hidden}#player{width:100%;height:100%}</style>
</head><body><div id="player"></div>
<script>
let player;
const videoId=${jsonEncode(id)};
let visible=true;
function emit(type,value){if(window.RaagaPlayer){RaagaPlayer.postMessage(JSON.stringify({videoId:videoId,type:type,value:value}));}}
function pauseRaaga(){visible=false;if(player&&player.pauseVideo){player.pauseVideo();}}
function onYouTubeIframeAPIReady(){
 player=new YT.Player('player',{
  width:'100%',height:'100%',videoId:videoId,
  playerVars:{autoplay:0,controls:1,playsinline:1,fs:0,origin:${jsonEncode(origin)}},
  events:{onReady:function(){emit('ready',0);},
   onStateChange:function(e){if(e.data===1&&!visible){player.pauseVideo();return;}emit('state',e.data);},
   onError:function(e){emit('error',e.data);}}
 });
}
document.addEventListener('visibilitychange',function(){visible=!document.hidden;if(!visible){pauseRaaga();}});
window.addEventListener('pagehide',pauseRaaga);
</script><script src="https://www.youtube.com/iframe_api" onerror="emit('loadError',0)"></script>
</body></html>''';
  }
}
