import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:xml/xml.dart';
import 'package:http/http.dart' as http;
import '../models/media_item.dart';
import '../models/spotify_track.dart';
import 'spotify_auth.dart';

abstract class CatalogApi {
  Future<List<MediaItem>> fetchCatalog();
}

class DemoCatalogApi implements CatalogApi {
  @override
  Future<List<MediaItem>> fetchCatalog() async => const [
    MediaItem(
      id: 'm1',
      title: 'Afterglow',
      creator: 'Sona Originals',
      category: 'Chill',
      kind: MediaKind.music,
      source: 'assets/audio/afterglow.mp3',
      color: 0xFFC9F27A,
      art: 0,
      description:
          'A warm, original ambient demo. Find a little space in your day.',
    ),
    MediaItem(
      id: 'm2',
      title: 'Blue Hour',
      creator: 'Sona Originals',
      category: 'Focus',
      kind: MediaKind.music,
      source: 'assets/audio/blue_hour.mp3',
      color: 0xFF8AB4FF,
      art: 1,
      description:
          'Soft electronic notes for a slower state of mind. Original demo audio.',
    ),
    MediaItem(
      id: 'm3',
      title: 'Night Drive',
      creator: 'Sona Originals',
      category: 'Electronic',
      kind: MediaKind.music,
      source: 'assets/audio/night_drive.mp3',
      color: 0xFFEBA2D2,
      art: 2,
      description:
          'A short synth pulse for the road ahead. Original demo audio.',
    ),
    MediaItem(
      id: 'p1',
      title: 'Make room for a good idea',
      creator: 'Small Conversations · EP 01',
      category: 'Creativity',
      kind: MediaKind.podcast,
      source: 'assets/audio/ideas.mp3',
      color: 0xFFFFB77B,
      art: 3,
      description:
          'A short introduction to building a creative habit. Original script with a synthetic demo voice.',
    ),
    MediaItem(
      id: 'p2',
      title: 'A quieter morning',
      creator: 'The Daily Pause · EP 02',
      category: 'Lifestyle',
      kind: MediaKind.podcast,
      source: 'assets/audio/morning.mp3',
      color: 0xFFB8ABF5,
      art: 4,
      description:
          'A small invitation to begin your day with intention. Original script with a synthetic demo voice.',
    ),
  ];
}

class SpotifyApi {
  SpotifyApi({required this.auth, http.Client? client})
    : _client = client ?? http.Client();
  final SpotifyAuth auth;
  final http.Client _client;
  DateTime? _retryAt;

  Future<List<SpotifyTrack>> getTopTracks({
    String timeRange = 'long_term',
  }) async {
    if (!['long_term', 'medium_term', 'short_term'].contains(timeRange)) {
      throw ArgumentError.value(timeRange, 'timeRange');
    }
    if (_retryAt != null && DateTime.now().isBefore(_retryAt!)) {
      throw const SpotifyException(
        'Spotify is limiting requests. Please wait before refreshing.',
      );
    }
    final uri = Uri.https('api.spotify.com', '/v1/me/top/tracks', {
      'time_range': timeRange,
      'limit': '5',
    });
    Future<http.Response> request(String token) => _client
        .get(
          uri,
          headers: {
            'Authorization': 'Bearer $token',
            'Accept': 'application/json',
          },
        )
        .timeout(const Duration(seconds: 25));
    var response = await request(await auth.accessToken());
    if (response.statusCode == 401) {
      response = await request(await auth.accessToken(forceRefresh: true));
    }
    if (response.statusCode == 401) {
      auth.signOut();
      throw const SpotifyException(
        'Your Spotify session expired. Please connect again.',
      );
    }
    if (response.statusCode == 403) {
      throw const SpotifyException(
        'Spotify denied access. Check the app owner’s Premium subscription, allowed users, and user-top-read permission in your Spotify developer settings.',
      );
    }
    if (response.statusCode == 429) {
      final seconds = int.tryParse(response.headers['retry-after'] ?? '') ?? 60;
      _retryAt = DateTime.now().add(
        Duration(seconds: seconds.clamp(1, 86400).toInt()),
      );
      throw const SpotifyException(
        'Spotify’s request limit was reached. Try again later.',
      );
    }
    if (response.statusCode != 200) {
      throw const SpotifyException(
        'Spotify could not load your tracks. Please try again later.',
      );
    }
    final data = jsonDecode(response.body);
    if (data is! Map<String, dynamic> || data['items'] is! List) {
      throw const SpotifyException(
        'Spotify returned an unexpected track list.',
      );
    }
    return (data['items'] as List)
        .map(
          (item) =>
              SpotifyTrack.fromJson(Map<String, dynamic>.from(item as Map)),
        )
        .toList();
  }

  void dispose() => _client.close();
}

class CatalogException implements Exception {
  const CatalogException(this.message);
  final String message;
  @override
  String toString() => message;
}

Uri httpsAddress(String value) {
  final uri = Uri.tryParse(value.trim());
  if (uri == null ||
      uri.scheme != 'https' ||
      uri.host.isEmpty ||
      uri.userInfo.isNotEmpty) {
    throw const CatalogException('Enter a complete HTTPS address.');
  }
  return uri;
}

Future<http.StreamedResponse> openAudioRequest(
  http.Client client,
  Uri uri,
) async {
  for (var hop = 0; hop < 6; hop++) {
    httpsAddress(uri.toString());
    final request = http.Request('GET', uri)..followRedirects = false;
    request.headers['User-Agent'] = 'Sona/2.0';
    final response = await client
        .send(request)
        .timeout(const Duration(seconds: 25));
    if ([301, 302, 303, 307, 308].contains(response.statusCode)) {
      final location = response.headers['location'];
      await response.stream.listen((_) {}).cancel();
      if (location == null)
        throw const CatalogException(
          'The server returned an invalid redirect.',
        );
      uri = uri.resolve(location);
      continue;
    }
    if (response.statusCode != 200) {
      await response.stream.listen((_) {}).cancel();
      throw CatalogException(
        'The server could not load this content (${response.statusCode}).',
      );
    }
    return response;
  }
  throw const CatalogException('The server redirected too many times.');
}

class FeedResult {
  const FeedResult(this.feed, this.episodes);
  final PodcastFeed feed;
  final List<MediaItem> episodes;
}

class PodcastApi {
  PodcastApi({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;
  Future<String> _text(Uri uri) async {
    final response = await openAudioRequest(_client, uri);
    final bytes = <int>[];
    await for (final chunk in response.stream.timeout(
      const Duration(seconds: 25),
    )) {
      bytes.addAll(chunk);
      if (bytes.length > 5 * 1024 * 1024)
        throw const CatalogException('This feed is too large to load.');
    }
    return utf8.decode(bytes, allowMalformed: true);
  }

  Future<List<PodcastFeed>> search(String term) async {
    if (term.trim().isEmpty) return [];
    final uri = Uri.https('itunes.apple.com', '/search', {
      'term': term.trim(),
      'media': 'podcast',
      'entity': 'podcast',
      'limit': '25',
      'country': 'IN',
    });
    final data = jsonDecode(await _text(uri)) as Map<String, dynamic>;
    return (data['results'] as List? ?? [])
        .whereType<Map>()
        .where((r) => (r['feedUrl'] as String? ?? '').startsWith('https://'))
        .map(
          (r) => PodcastFeed(
            url: r['feedUrl'] as String,
            title: r['collectionName'] as String? ?? 'Podcast',
            creator: r['artistName'] as String? ?? 'Podcast',
            artworkUrl: r['artworkUrl600'] as String?,
          ),
        )
        .toList();
  }

  Future<FeedResult> fetchFeed(String address) async {
    final uri = httpsAddress(address);
    return parseFeed(await _text(uri), uri.toString());
  }

  static FeedResult parseFeed(String xml, String address) {
    final document = XmlDocument.parse(xml);
    final channel = document.findAllElements('channel').firstOrNull;
    if (channel == null)
      throw const CatalogException('This address is not a podcast RSS feed.');
    String text(XmlElement e, String name) =>
        e.childElements
            .where((n) => n.name.local == name)
            .firstOrNull
            ?.innerText
            .trim() ??
        '';
    String clean(String s) => s
        .replaceAll(RegExp(r'<[^>]*>'), ' ')
        .replaceAll('&nbsp;', ' ')
        .replaceAll('&amp;', '&')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    String? image(XmlElement e) {
      for (final node in e.childElements.where(
        (n) => n.name.local == 'image',
      )) {
        final url = node.getAttribute('href') ?? text(node, 'url');
        if (url.startsWith('https://')) return url;
      }
      return null;
    }

    int? duration(String value) {
      if (value.isEmpty) return null;
      var seconds = 0;
      for (final part in value.split(':')) {
        final n = int.tryParse(part);
        if (n == null || n < 0) return null;
        seconds = seconds * 60 + n;
      }
      return seconds * 1000;
    }

    final feed = PodcastFeed(
      url: address,
      title: clean(text(channel, 'title')),
      creator: clean(text(channel, 'author')),
      artworkUrl: image(channel),
    );
    final episodes = <MediaItem>[];
    final seen = <String>{};
    for (final node in channel.findElements('item').take(150)) {
      final enclosures = node.childElements.where(
        (n) => n.name.local == 'enclosure',
      );
      final enclosure = enclosures
          .where(
            (e) =>
                (e.getAttribute('url') ?? '').startsWith('https://') &&
                ((e.getAttribute('type') ?? '').startsWith('audio/') ||
                    (e.getAttribute('type') ?? '').isEmpty),
          )
          .firstOrNull;
      final url = enclosure?.getAttribute('url');
      if (url == null) continue;
      final guid = text(node, 'guid');
      final id =
          'rss-${sha256.convert(utf8.encode('$address|${guid.isEmpty ? url : guid}'))}';
      if (!seen.add(id)) continue;
      episodes.add(
        MediaItem(
          id: id,
          title: clean(text(node, 'title')),
          creator: feed.title,
          category: 'Podcasts',
          kind: MediaKind.podcast,
          source: url,
          color: 0xFFB8ABF5,
          art: episodes.length % 5,
          description: clean(text(node, 'description')),
          feedUrl: address,
          artworkUrl: image(node) ?? feed.artworkUrl,
          durationMs: duration(text(node, 'duration')),
        ),
      );
    }
    if (episodes.isEmpty)
      throw const CatalogException(
        'No playable HTTPS audio episodes were found in this feed.',
      );
    return FeedResult(feed, episodes);
  }

  void dispose() => _client.close();
}
