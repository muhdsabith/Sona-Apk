import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/media_item.dart';
import '../models/spotify_track.dart';
import 'spotify_auth.dart';

abstract class CatalogApi {
  Future<List<MediaItem>> fetchCatalog();
}

class DemoCatalogApi implements CatalogApi {
  @override
  Future<List<MediaItem>> fetchCatalog() async => const [
    MediaItem(id: 'm1', title: 'Afterglow', creator: 'Sona Originals',
      category: 'Chill', kind: MediaKind.music, source: 'assets/audio/afterglow.mp3',
      color: 0xFFC9F27A, art: 0, description: 'A warm, original ambient demo. Find a little space in your day.'),
    MediaItem(id: 'm2', title: 'Blue Hour', creator: 'Sona Originals',
      category: 'Focus', kind: MediaKind.music, source: 'assets/audio/blue_hour.mp3',
      color: 0xFF8AB4FF, art: 1, description: 'Soft electronic notes for a slower state of mind. Original demo audio.'),
    MediaItem(id: 'm3', title: 'Night Drive', creator: 'Sona Originals',
      category: 'Electronic', kind: MediaKind.music, source: 'assets/audio/night_drive.mp3',
      color: 0xFFEBA2D2, art: 2, description: 'A short synth pulse for the road ahead. Original demo audio.'),
    MediaItem(id: 'p1', title: 'Make room for a good idea', creator: 'Small Conversations · EP 01',
      category: 'Creativity', kind: MediaKind.podcast, source: 'assets/audio/ideas.mp3',
      color: 0xFFFFB77B, art: 3, description: 'A short introduction to building a creative habit. Original script with a synthetic demo voice.'),
    MediaItem(id: 'p2', title: 'A quieter morning', creator: 'The Daily Pause · EP 02',
      category: 'Lifestyle', kind: MediaKind.podcast, source: 'assets/audio/morning.mp3',
      color: 0xFFB8ABF5, art: 4, description: 'A small invitation to begin your day with intention. Original script with a synthetic demo voice.'),
  ];
}

class SpotifyApi {
  SpotifyApi({required this.auth, http.Client? client}) : _client = client ?? http.Client();
  final SpotifyAuth auth;
  final http.Client _client;
  DateTime? _retryAt;

  Future<List<SpotifyTrack>> getTopTracks({String timeRange = 'long_term'}) async {
    if (!['long_term', 'medium_term', 'short_term'].contains(timeRange)) {
      throw ArgumentError.value(timeRange, 'timeRange');
    }
    if (_retryAt != null && DateTime.now().isBefore(_retryAt!)) {
      throw const SpotifyException('Spotify is limiting requests. Please wait before refreshing.');
    }
    final uri = Uri.https('api.spotify.com', '/v1/me/top/tracks', {
      'time_range': timeRange, 'limit': '5',
    });
    Future<http.Response> request(String token) => _client.get(uri,
      headers: {'Authorization': 'Bearer $token', 'Accept': 'application/json'})
      .timeout(const Duration(seconds: 25));
    var response = await request(await auth.accessToken());
    if (response.statusCode == 401) {
      response = await request(await auth.accessToken(forceRefresh: true));
    }
    if (response.statusCode == 401) {
      auth.signOut();
      throw const SpotifyException('Your Spotify session expired. Please connect again.');
    }
    if (response.statusCode == 403) {
      throw const SpotifyException('Spotify denied access. Check the app owner’s Premium subscription, allowed users, and user-top-read permission in your Spotify developer settings.');
    }
    if (response.statusCode == 429) {
      final seconds = int.tryParse(response.headers['retry-after'] ?? '') ?? 60;
      _retryAt = DateTime.now().add(Duration(seconds: seconds.clamp(1, 86400).toInt()));
      throw const SpotifyException('Spotify’s request limit was reached. Try again later.');
    }
    if (response.statusCode != 200) {
      throw const SpotifyException('Spotify could not load your tracks. Please try again later.');
    }
    final data = jsonDecode(response.body);
    if (data is! Map<String, dynamic> || data['items'] is! List) {
      throw const SpotifyException('Spotify returned an unexpected track list.');
    }
    return (data['items'] as List).map((item) =>
      SpotifyTrack.fromJson(Map<String, dynamic>.from(item as Map))).toList();
  }

  void dispose() => _client.close();
}
