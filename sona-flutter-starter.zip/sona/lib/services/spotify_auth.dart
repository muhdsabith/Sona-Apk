import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:flutter_web_auth_2/flutter_web_auth_2.dart';
import 'package:http/http.dart' as http;

class SpotifyException implements Exception {
  const SpotifyException(this.message);
  final String message;
  @override
  String toString() => message;
}

class SpotifyAuth {
  SpotifyAuth({http.Client? client}) : _client = client ?? http.Client();
  static const callbackScheme = 'com.example.sona.spotify';
  static const redirectUri = '$callbackScheme://callback';
  static const scope = 'user-top-read';
  final http.Client _client;
  String? _clientId;
  String? _accessToken;
  String? _refreshToken;
  DateTime _expiresAt = DateTime.fromMillisecondsSinceEpoch(0);
  Future<String>? _refreshing;
  bool _disposed = false;
  int _generation = 0;

  bool get connected => _accessToken != null;

  static String challengeFor(String verifier) =>
      base64UrlEncode(sha256.convert(ascii.encode(verifier)).bytes).replaceAll('=', '');

  static String _randomString() {
    final random = Random.secure();
    return base64UrlEncode(List<int>.generate(64, (_) => random.nextInt(256))).replaceAll('=', '');
  }

  static String validateCallback(String callback, String expectedState) {
    final uri = Uri.tryParse(callback);
    final expected = Uri.parse(redirectUri);
    if (uri == null) {
      throw const SpotifyException('SP01-PARSE: The browser returned an invalid address. Please report this code.');
    }
    if (uri.scheme != expected.scheme || uri.host != expected.host ||
        uri.path != expected.path || uri.userInfo.isNotEmpty || uri.hasPort) {
      final differences = <String>[
        if (uri.scheme != expected.scheme)
          uri.scheme == 'https' ? 'HTTPS' : uri.scheme == 'http' ? 'HTTP' : 'SCHEME',
        if (uri.host != expected.host) 'HOST',
        if (uri.path != expected.path) uri.path == '/' ? 'ROOT-SLASH' : 'PATH',
        if (uri.userInfo.isNotEmpty) 'USERINFO',
        if (uri.hasPort) 'PORT',
      ];
      throw SpotifyException('SP01-${differences.join('+')}: The browser returned an address that Sona cannot accept. Try Chrome login and report this code if it repeats.');
    }
    if (uri.hasFragment) {
      throw const SpotifyException('SP02: The login returned an unsupported response format. Please report this code.');
    }
    final states = uri.queryParametersAll['state'];
    if (states == null || states.isEmpty || (states.length == 1 && states.single.isEmpty)) {
      throw const SpotifyException('SP03: The login response is missing its verification value. Check Spotify Web API access, then try a fresh browser session.');
    }
    if (states.length != 1) {
      throw const SpotifyException('SP04: The login returned duplicate verification values. Please report this code.');
    }
    if (states.single != expectedState) {
      throw const SpotifyException('SP05: The login response does not match this sign-in attempt. Close old login tabs and try a fresh browser session.');
    }
    if (uri.queryParameters.containsKey('error')) {
      final message = switch (uri.queryParameters['error']) {
        'access_denied' => 'SP06: Spotify denied access. Check your developer app access and allow the requested permission when connecting.',
        'invalid_scope' => 'SP07: Spotify rejected the top-tracks permission. Check Web API access in your developer dashboard.',
        'invalid_client' || 'unauthorized_client' => 'SP08: Spotify rejected this developer app. Check its Client ID and Web API access.',
        'server_error' || 'temporarily_unavailable' => 'SP09: Spotify login is temporarily unavailable. Try again later.',
        _ => 'SP10: Spotify returned a login error. Check your developer app settings and try again.',
      };
      throw SpotifyException(message);
    }
    final code = uri.queryParameters['code'];
    if (code == null || code.isEmpty || uri.queryParametersAll['code']?.length != 1) {
      throw const SpotifyException('SP11: Spotify did not return a single login code. Please try again.');
    }
    return code;
  }

  Future<void> signIn(String clientId, {bool freshBrowserSession = false}) async {
    if (!RegExp(r'^[a-fA-F0-9]{32}$').hasMatch(clientId.trim())) {
      throw const SpotifyException('Enter the 32-character Client ID from your Spotify app settings.');
    }
    signOut();
    final generation = _generation;
    final id = clientId.trim();
    final verifier = _randomString();
    final state = _randomString();
    final authorize = Uri.https('accounts.spotify.com', '/authorize', {
      'client_id': id, 'response_type': 'code', 'redirect_uri': redirectUri,
      'scope': scope, 'state': state, 'code_challenge_method': 'S256',
      'code_challenge': challengeFor(verifier), 'show_dialog': 'true',
    });
    String callback;
    try {
      callback = await FlutterWebAuth2.authenticate(
        url: authorize.toString(), callbackUrlScheme: callbackScheme,
        options: FlutterWebAuth2Options(
          preferEphemeral: freshBrowserSession,
          customTabsPackageOrder: freshBrowserSession ? const ['com.android.chrome'] : null));
    } on PlatformException catch (error) {
      if (error.code == 'CANCELED') {
        throw const SpotifyException('SP12: The login browser closed before finishing. Please connect again.');
      }
      throw const SpotifyException('SP13: The login browser could not start or finish. Check that a browser such as Chrome is enabled, then try again.');
    }
    _ensureActive(generation);
    final code = validateCallback(callback, state);
    final data = await _tokenRequest({
      'grant_type': 'authorization_code', 'client_id': id, 'code': code,
      'redirect_uri': redirectUri, 'code_verifier': verifier,
    });
    _ensureActive(generation);
    _acceptTokens(data);
    _clientId = id;
  }

  void _ensureActive(int generation) {
    if (_disposed || generation != _generation) {
      throw const SpotifyException('The Spotify session has ended. Please connect again.');
    }
  }

  Future<Map<String, dynamic>> _tokenRequest(Map<String, String> body) async {
    final response = await _client.post(Uri.https('accounts.spotify.com', '/api/token'),
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body: body).timeout(const Duration(seconds: 25));
    if (response.statusCode == 429) {
      throw const SpotifyException('Spotify is limiting requests. Wait a little and try again.');
    }
    if (response.statusCode >= 500) {
      throw const SpotifyException('Spotify login is temporarily unavailable. Try again later.');
    }
    if (response.statusCode != 200) {
      throw const SpotifyException('Spotify login expired or the app settings do not match. Check the Client ID and redirect URI, then reconnect.');
    }
    final parsed = jsonDecode(response.body);
    if (parsed is! Map<String, dynamic>) {
      throw const SpotifyException('Spotify returned an unexpected login response.');
    }
    return parsed;
  }

  void _acceptTokens(Map<String, dynamic> data) {
    final access = data['access_token'];
    final expiry = data['expires_in'];
    final tokenType = data['token_type'];
    final granted = data['scope'];
    if (access is! String || access.isEmpty || expiry is! num || expiry <= 0 ||
        tokenType is! String || tokenType.toLowerCase() != 'bearer') {
      throw const SpotifyException('Spotify returned an incomplete login response.');
    }
    if (granted is String && !granted.split(' ').contains(scope)) {
      throw const SpotifyException('Top-tracks permission is missing. Connect again and allow access.');
    }
    _accessToken = access;
    final refresh = data['refresh_token'];
    if (refresh is String && refresh.isNotEmpty) _refreshToken = refresh;
    _expiresAt = DateTime.now().add(Duration(seconds: expiry.toInt()));
  }

  Future<String> accessToken({bool forceRefresh = false}) async {
    if (_disposed || !connected) {
      throw const SpotifyException('Connect your Spotify account first.');
    }
    if (!forceRefresh && DateTime.now().isBefore(_expiresAt.subtract(const Duration(seconds: 30)))) {
      return _accessToken!;
    }
    if (_refreshing != null) return _refreshing!;
    final future = _refresh();
    _refreshing = future;
    try { return await future; }
    finally { if (identical(_refreshing, future)) _refreshing = null; }
  }

  Future<String> _refresh() async {
    final generation = _generation;
    if (_refreshToken == null || _clientId == null) {
      signOut();
      throw const SpotifyException('Your Spotify session expired. Connect again.');
    }
    try {
      final data = await _tokenRequest({'grant_type': 'refresh_token',
        'refresh_token': _refreshToken!, 'client_id': _clientId!});
      _ensureActive(generation);
      _acceptTokens(data);
      return _accessToken!;
    } catch (_) {
      if (generation == _generation) signOut();
      rethrow;
    }
  }

  void signOut() {
    _generation++;
    _clientId = null; _accessToken = null; _refreshToken = null;
    _refreshing = null;
    _expiresAt = DateTime.fromMillisecondsSinceEpoch(0);
  }

  void dispose() { _disposed = true; signOut(); _client.close(); }
}
