import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/track_model.dart';

class LastFmException implements Exception {
  const LastFmException(this.message);
  final String message;
  @override
  String toString() => message;
}

class LastFmService {
  LastFmService({
    required this.apiKey,
    http.Client? client,
    this.timeout = const Duration(seconds: 20),
  }) : _client = client ?? http.Client(),
       _ownsClient = client == null;
  final String apiKey;
  final http.Client _client;
  final bool _ownsClient;
  final Duration timeout;

  Future<List<Track>> getTopTracks({int limit = 30}) async {
    if (apiKey.trim().isEmpty || apiKey.trim() == 'YOUR_LASTFM_API_KEY') {
      throw const LastFmException(
        'Add your Last.fm API key in Settings to load charts.',
      );
    }
    final uri = Uri.https('ws.audioscrobbler.com', '/2.0/', {
      'method': 'chart.gettoptracks',
      'api_key': apiKey.trim(),
      'format': 'json',
      'limit': limit.clamp(1, 100).toString(),
    });
    try {
      final response = await _client.get(uri).timeout(timeout);
      if (response.statusCode == 429)
        throw const LastFmException(
          'Last.fm is limiting requests. Please try later.',
        );
      if (response.statusCode != 200)
        throw LastFmException(
          'Last.fm could not load charts (HTTP ${response.statusCode}).',
        );
      final data = jsonDecode(response.body);
      if (data is! Map) throw const FormatException();
      if (data['error'] != null) {
        final code = int.tryParse('${data['error']}');
        throw LastFmException(switch (code) {
          10 => 'Last.fm rejected this API key. Check it in Settings.',
          26 => 'This Last.fm API key is suspended.',
          29 => 'Last.fm is limiting requests. Please try later.',
          _ => 'Last.fm is temporarily unavailable. Please try later.',
        });
      }
      final container = data['tracks'];
      if (container is! Map || container['track'] is! List)
        throw const FormatException();
      final result = <Track>[];
      final seen = <String>{};
      for (final entry in container['track'] as List) {
        if (entry is! Map<String, dynamic>) continue;
        final item = Track.fromJson(entry);
        if (item.name == 'Unknown Track') continue;
        if (seen.add('${item.artistName}\u0000${item.name}')) result.add(item);
      }
      return result;
    } on LastFmException {
      rethrow;
    } on TimeoutException {
      throw const LastFmException(
        'Last.fm took too long to respond. Try again.',
      );
    } on FormatException {
      throw const LastFmException(
        'Last.fm returned an unexpected response. Try again later.',
      );
    } catch (_) {
      throw const LastFmException(
        'Could not reach Last.fm. Check your connection.',
      );
    }
  }

  void close() {
    if (_ownsClient) _client.close();
  }
}
