import 'package:http/http.dart' as http;
import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import '../models/media_item.dart';

class YoutubeException implements Exception {
  const YoutubeException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Searches YouTube and resolves a temporary audio stream for a video.
/// Only the video id is stored; the stream address is fetched when you press
/// play because YouTube stream links expire.
class YoutubeApi {
  YoutubeApi() : _yt = YoutubeExplode();
  final YoutubeExplode _yt;

  Future<List<MediaItem>> search(String query) async {
    final text = query.trim();
    if (text.isEmpty) return const [];
    try {
      final results = await _yt.search
          .search(text)
          .timeout(const Duration(seconds: 25));
      final items = <MediaItem>[];
      for (final video in results.take(25)) {
        final id = video.id.value;
        items.add(
          MediaItem(
            id: 'youtube-$id',
            title: video.title,
            creator: video.author,
            category: 'YouTube',
            kind: MediaKind.music,
            source: 'youtube:$id',
            color: 0xFFB4A7F5,
            art: id.length % 5,
            description: 'Streamed from YouTube.',
            artworkUrl: 'https://i.ytimg.com/vi/$id/hqdefault.jpg',
            durationMs: video.duration?.inMilliseconds,
          ),
        );
      }
      return items;
    } catch (_) {
      throw const YoutubeException(
        'Could not search YouTube right now. Check your connection and try again.',
      );
    }
  }

  Future<bool> _reachable(String url) async {
    final client = http.Client();
    try {
      final response = await client
          .get(Uri.parse(url), headers: {'Range': 'bytes=0-1'})
          .timeout(const Duration(seconds: 12));
      return response.statusCode == 200 || response.statusCode == 206;
    } catch (_) {
      return false;
    } finally {
      client.close();
    }
  }

  Future<String> resolve(MediaItem item) async {
    final id = item.youtubeId;
    if (id == null) throw const YoutubeException('Not a YouTube song.');
    Object? lastError;
    // Try the Android VR client first (gives direct links that need no
    // JavaScript solving), then Safari, then the library default.
    final attempts = <List<YoutubeApiClient>?>[
      [YoutubeApiClient.androidVr],
      [YoutubeApiClient.safari, YoutubeApiClient.androidVr],
      null,
    ];
    for (final clients in attempts) {
      try {
        final manifest = clients == null
            ? await _yt.videos.streamsClient
                  .getManifest(id)
                  .timeout(const Duration(seconds: 30))
            : await _yt.videos.streamsClient
                  .getManifest(id, ytClients: clients)
                  .timeout(const Duration(seconds: 30));
        final all = manifest.audioOnly.toList();
        if (all.isEmpty) continue;
        all.sort(
          (a, b) => b.bitrate.bitsPerSecond.compareTo(a.bitrate.bitsPerSecond),
        );
        final mp4 = all.where((s) => s.container.name == 'mp4').toList();
        final candidates = [...mp4, ...all.where((s) => s.container.name != 'mp4')];
        for (final stream in candidates.take(3)) {
          final url = stream.url.toString();
          if (await _reachable(url)) return url;
        }
        lastError = 'stream links were rejected';
      } catch (e) {
        lastError = e;
      }
    }
    final detail = '$lastError'.replaceAll('\n', ' ');
    throw YoutubeException(
      'Could not play this song from YouTube (${detail.length > 120 ? detail.substring(0, 120) : detail}). Try another song.',
    );
  }

  void dispose() => _yt.close();
}
