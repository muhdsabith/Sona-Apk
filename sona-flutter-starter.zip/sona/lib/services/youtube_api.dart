import 'package:youtube_explode_dart/youtube_explode_dart.dart';
import '../models/media_item.dart';

class YoutubeException implements Exception {
  const YoutubeException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Searches YouTube and resolves a temporary audio stream for a video.
/// Only the video id is stored; the stream address is fetched when you press
/// play because YouTube stream links expire.
class YoutubeApi {
  YoutubeApi() : _yt = YoutubeExplode();
  final YoutubeExplode _yt;

  Future<List<MediaItem>> search(String query) async {
    final text = query.trim();
    if (text.isEmpty) return const [];
    try {
      final results = await _yt.search
          .search(text)
          .timeout(const Duration(seconds: 25));
      final items = <MediaItem>[];
      for (final video in results.take(25)) {
        final id = video.id.value;
        items.add(
          MediaItem(
            id: 'youtube-$id',
            title: video.title,
            creator: video.author,
            category: 'YouTube',
            kind: MediaKind.music,
            source: 'youtube:$id',
            color: 0xFFB4A7F5,
            art: id.length % 5,
            description: 'Streamed from YouTube.',
            artworkUrl: 'https://i.ytimg.com/vi/$id/hqdefault.jpg',
            durationMs: video.duration?.inMilliseconds,
          ),
        );
      }
      return items;
    } catch (_) {
      throw const YoutubeException(
        'Could not search YouTube right now. Check your connection and try again.',
      );
    }
  }

  Future<String> resolve(MediaItem item) async {
    final id = item.youtubeId;
    if (id == null) throw const YoutubeException('Not a YouTube song.');
    try {
      final manifest = await _yt.videos.streamsClient
          .getManifest(id)
          .timeout(const Duration(seconds: 30));
      final all = manifest.audioOnly.toList();
      if (all.isEmpty) {
        throw const YoutubeException('No audio stream found for this song.');
      }
      final mp4 = all.where((s) => s.container.name == 'mp4').toList();
      final pool = mp4.isNotEmpty ? mp4 : all;
      pool.sort(
        (a, b) => b.bitrate.bitsPerSecond.compareTo(a.bitrate.bitsPerSecond),
      );
      return pool.first.url.toString();
    } on YoutubeException {
      rethrow;
    } catch (_) {
      throw const YoutubeException(
        'Could not load this song from YouTube. It may be blocked or unavailable. Try another one.',
      );
    }
  }

  void dispose() => _yt.close();
}
