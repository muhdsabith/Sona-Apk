import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/spotify_content.dart';

class SpotifyRemoteException implements Exception {
  const SpotifyRemoteException(this.message, {this.status, this.retryAt});
  final String message;
  final int? status;
  final DateTime? retryAt;
  @override
  String toString() => message;
}

class SpotifyCompanionApi {
  SpotifyCompanionApi({
    required this.token,
    required this.onUnauthorized,
    http.Client? client,
  }) : _client = client ?? http.Client();
  final Future<String> Function({bool forceRefresh}) token;
  final void Function() onUnauthorized;
  final http.Client _client;
  int _session = 0;
  DateTime? retryAt;
  static const scopes = [
    'user-top-read',
    'playlist-read-private',
    'playlist-read-collaborative',
    'user-library-read',
    'user-library-modify',
    'user-read-playback-state',
    'user-modify-playback-state',
  ];
  void invalidateSession() => _session++;

  Future<Object?> _request(
    String method,
    String path, {
    Map<String, String>? query,
    Object? body,
  }) async {
    final session = _session;
    void ensureSession() {
      if (session != _session) {
        throw const SpotifyRemoteException('This Spotify session has ended.');
      }
    }

    if (retryAt != null && DateTime.now().isBefore(retryAt!)) {
      throw SpotifyRemoteException(
        'Spotify is limiting requests. Please wait before trying again.',
        status: 429,
        retryAt: retryAt,
      );
    }
    final uri = Uri.https('api.spotify.com', '/v1/$path', query);
    Future<http.Response> send(String access) async {
      ensureSession();
      final request = http.Request(method, uri)..followRedirects = false;
      request.headers.addAll({
        'Authorization': 'Bearer $access',
        'Accept': 'application/json',
      });
      if (body != null) {
        request.headers['Content-Type'] = 'application/json';
        request.body = jsonEncode(body);
      }
      return await http.Response.fromStream(
        await _client.send(request).timeout(const Duration(seconds: 25)),
      ).timeout(const Duration(seconds: 25));
    }

    var response = await send(await token(forceRefresh: false));
    ensureSession();
    if (response.statusCode == 401)
      response = await send(await token(forceRefresh: true));
    ensureSession();
    if (response.statusCode == 401) {
      onUnauthorized();
      throw const SpotifyRemoteException(
        'Your Spotify session expired. Connect again.',
        status: 401,
      );
    }
    if (response.statusCode == 429) {
      final seconds = int.tryParse(response.headers['retry-after'] ?? '') ?? 60;
      retryAt = DateTime.now().add(Duration(seconds: seconds.clamp(1, 86400)));
      throw SpotifyRemoteException(
        'Spotify has reached its request or account quota. Try later.',
        status: 429,
        retryAt: retryAt,
      );
    }
    if (response.statusCode == 403) {
      throw const SpotifyRemoteException(
        'Spotify denied this action. Check Premium, developer-app access, and reconnect to allow the requested permissions. Some playlists or playback actions are restricted by Spotify.',
        status: 403,
      );
    }
    if (response.statusCode == 404 && path.startsWith('me/player')) {
      throw const SpotifyRemoteException(
        'No active Spotify player. Open Spotify, play something, return here and choose your phone under Devices.',
        status: 404,
      );
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw SpotifyRemoteException(
        response.statusCode >= 500
            ? 'Spotify is temporarily unavailable. Try again later.'
            : 'Spotify could not complete this request (${response.statusCode}). The content or device may be unavailable.',
        status: response.statusCode,
      );
    }
    if (response.statusCode == 204 || response.body.trim().isEmpty) return null;
    return jsonDecode(response.body);
  }

  Future<SpotifyPage> top({String range = 'long_term', int offset = 0}) async {
    if (!['long_term', 'medium_term', 'short_term'].contains(range))
      throw ArgumentError('Invalid time range');
    return SpotifyPage.fromJson(
      SpotifyContent.map(
        await _request(
          'GET',
          'me/top/tracks',
          query: {'time_range': range, 'limit': '20', 'offset': '$offset'},
        ),
      ),
      type: 'track',
    );
  }

  Future<SpotifyPage> search(String text, String type, {int offset = 0}) async {
    if (!['track', 'album', 'playlist', 'show', 'episode'].contains(type))
      throw ArgumentError('Invalid search type');
    if (text.trim().isEmpty) return const SpotifyPage([], null);
    final data = SpotifyContent.map(
      await _request(
        'GET',
        'search',
        query: {
          'q': text.trim(),
          'type': type,
          'limit': '10',
          'offset': '$offset',
        },
      ),
    );
    return SpotifyPage.fromJson(
      SpotifyContent.map(data['${type}s']),
      type: type,
    );
  }

  Future<SpotifyPage> library(String kind, {int offset = 0}) async {
    final (path, type, wrapper) = switch (kind) {
      'playlists' => ('me/playlists', 'playlist', null),
      'tracks' => ('me/tracks', 'track', 'track'),
      'shows' => ('me/shows', 'show', 'show'),
      _ => throw ArgumentError('Invalid library type'),
    };
    return SpotifyPage.fromJson(
      SpotifyContent.map(
        await _request(
          'GET',
          path,
          query: {'limit': '20', 'offset': '$offset'},
        ),
      ),
      type: type,
      wrapper: wrapper,
    );
  }

  Future<SpotifyPage> collection(
    SpotifyContent parent, {
    int offset = 0,
  }) async {
    final (path, type, wrapper) = switch (parent.type) {
      'album' => ('albums/${parent.id}/tracks', 'track', null),
      'show' => ('shows/${parent.id}/episodes', 'episode', null),
      'playlist' => ('playlists/${parent.id}/items', null, 'item'),
      _ => throw ArgumentError('Not a collection'),
    };
    return SpotifyPage.fromJson(
      SpotifyContent.map(
        await _request(
          'GET',
          path,
          query: {'limit': '20', 'offset': '$offset'},
        ),
      ),
      type: type,
      subtitle: parent.title,
      wrapper: wrapper,
    );
  }

  Future<void> save(SpotifyContent item) async {
    await _request('PUT', 'me/library', query: {'uris': item.uri});
  }

  Future<List<SpotifyDevice>> devices() async {
    final data = SpotifyContent.map(await _request('GET', 'me/player/devices'));
    return (data['devices'] as List? ?? [])
        .map((d) => SpotifyDevice.fromJson(SpotifyContent.map(d)))
        .where((d) => d.id.isNotEmpty)
        .toList();
  }

  Future<SpotifyPlayback> playback() async => SpotifyPlayback.fromJson(
    SpotifyContent.map(
      await _request(
        'GET',
        'me/player',
        query: {'additional_types': 'track,episode'},
      ),
    ),
  );
  Future<List<SpotifyContent>> queue() async {
    final data = SpotifyContent.map(await _request('GET', 'me/player/queue'));
    return SpotifyPage.fromJson({'items': data['queue'] ?? []}).items;
  }

  Future<void> transfer(String deviceId) async {
    await _request(
      'PUT',
      'me/player',
      body: {
        'device_ids': [deviceId],
        'play': false,
      },
    );
  }

  Future<void> play({SpotifyContent? item, required String deviceId}) async {
    if (item != null && (!item.playable || item.type == 'show')) {
      throw const SpotifyRemoteException(
        'Choose a playable episode or track first.',
      );
    }
    await _request(
      'PUT',
      'me/player/play',
      query: {'device_id': deviceId},
      body: item == null
          ? null
          : item.isAudio
          ? {
              'uris': [item.uri],
            }
          : {'context_uri': item.uri},
    );
  }

  Future<void> command(
    String action,
    String deviceId, {
    int? position,
    bool? shuffle,
    String? repeat,
    String? uri,
  }) async {
    final query = {'device_id': deviceId};
    final (method, path) = switch (action) {
      'pause' => ('PUT', 'pause'),
      'next' => ('POST', 'next'),
      'previous' => ('POST', 'previous'),
      'seek' => ('PUT', 'seek'),
      'shuffle' => ('PUT', 'shuffle'),
      'repeat' => ('PUT', 'repeat'),
      'queue' => ('POST', 'queue'),
      _ => throw ArgumentError('Unsupported player action'),
    };
    if (action == 'seek')
      query['position_ms'] = '${(position ?? 0).clamp(0, 2147483647)}';
    if (action == 'shuffle') query['state'] = '${shuffle ?? false}';
    if (action == 'repeat') {
      if (!['off', 'context', 'track'].contains(repeat))
        throw ArgumentError('Invalid repeat');
      query['state'] = repeat!;
    }
    if (action == 'queue') {
      if (uri == null ||
          !RegExp(r'^spotify:(track|episode):[a-zA-Z0-9]+$').hasMatch(uri))
        throw ArgumentError('Invalid queue item');
      query['uri'] = uri;
    }
    await _request(method, 'me/player/$path', query: query);
  }

  void dispose() => _client.close();
}
