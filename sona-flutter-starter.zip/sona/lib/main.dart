import 'package:flutter/material.dart';
import 'package:audio_service/audio_service.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'controllers/app_controller.dart';
import 'services/library_store.dart';
import 'services/audio_handler.dart';
import 'ui/app_shell.dart';

const accent = Color(0xFFC9F27A);
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SonaApp());
}

class SonaApp extends StatelessWidget {
  const SonaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Sona',
    theme: ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF101214),
      colorScheme: ColorScheme.fromSeed(
        seedColor: accent,
        brightness: Brightness.dark,
        primary: accent,
        onSurface: const Color(0xFFF1F0E9),
        surface: const Color(0xFF1A1D20),
      ),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF101214)),
      dividerTheme: const DividerThemeData(
        color: Color(0xFF292D30),
        thickness: .6,
      ),
      sliderTheme: const SliderThemeData(
        trackHeight: 3,
        thumbShape: RoundSliderThumbShape(enabledThumbRadius: 5),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: const Color(0xFF1C2022),
        side: const BorderSide(color: Color(0xFF333A37)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
          foregroundColor: const Color(0xFF16200F),
        ),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: Color(0xFF191D20),
        surfaceTintColor: Colors.transparent,
      ),
      snackBarTheme: const SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
      ),
      navigationBarTheme: const NavigationBarThemeData(
        backgroundColor: Color(0xFF101214),
        indicatorColor: Color(0xFF2C352D),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF1D2124),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
      ),
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          fontSize: 32,
          fontWeight: FontWeight.w700,
          letterSpacing: -1.4,
        ),
        headlineMedium: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.8,
        ),
        titleLarge: TextStyle(fontSize: 21, fontWeight: FontWeight.w700),
        titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        bodyMedium: TextStyle(fontSize: 14, height: 1.5),
      ),
    ),
    home: const SonaStartup(),
  );
}

class SonaStartup extends StatefulWidget {
  const SonaStartup({super.key});
  @override
  State<SonaStartup> createState() => _SonaStartupState();
}

class _SonaStartupState extends State<SonaStartup> {
  late final Future<AppController> _startup = _initialize();
  Future<AppController> _initialize() async {
    LicenseRegistry.addLicense(() async* {
      yield LicenseEntryWithLineBreaks([
        'youtube_explode_dart',
      ], await rootBundle.loadString('assets/YOUTUBE_EXPLODE_LICENSE.txt'));
      yield LicenseEntryWithLineBreaks([
        'Sona / Musify-derived integration',
      ], await rootBundle.loadString('LICENSE'));
    });
    final handler = await AudioService.init<SonaAudioHandler>(
      builder: SonaAudioHandler.new,
      config: const AudioServiceConfig(
        androidNotificationChannelId: 'com.example.sona.audio',
        androidNotificationChannelName: 'Sona playback',
        androidNotificationIcon: 'drawable/ic_stat_music',
        androidStopForegroundOnPause: true,
      ),
    );
    final controller = AppController(store: LibraryStore(), handler: handler);
    await controller.initialize();
    return controller;
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<AppController>(
    future: _startup,
    builder: (context, snapshot) {
      if (snapshot.hasError)
        return const Scaffold(
          body: SafeArea(
            child: Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Sona could not start its audio service. Close and reopen the app. If this repeats, report the APK version (4.1.0).',
                ),
              ),
            ),
          ),
        );
      final controller = snapshot.data;
      if (controller == null)
        return const Scaffold(body: Center(child: CircularProgressIndicator()));
      return AppShell(controller: controller);
    },
  );
}
