import 'dart:async';
import 'package:flutter/material.dart';
import 'package:audio_service/audio_service.dart';
import 'services/audio_handler.dart';
import 'controllers/app_controller.dart';
import 'services/apis.dart';
import 'services/library_store.dart';
import 'ui/app_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final handler = await AudioService.init<SonaAudioHandler>(
    builder: SonaAudioHandler.new,
    config: const AudioServiceConfig(
      androidNotificationChannelId: 'com.example.sona.playback',
      androidNotificationChannelName: 'Sona playback',
      androidStopForegroundOnPause: false,
      androidNotificationIcon: 'drawable/ic_stat_music',
    ),
  );
  runApp(SonaApp(handler: handler));
}

class SonaApp extends StatefulWidget {
  const SonaApp({super.key, required this.handler});
  final SonaAudioHandler handler;
  @override
  State<SonaApp> createState() => _SonaAppState();
}

class _SonaAppState extends State<SonaApp> with WidgetsBindingObserver {
  late final AppController controller;

  @override
  void initState() {
    super.initState();
    controller = AppController(
      api: DemoCatalogApi(),
      store: LibraryStore(),
      handler: widget.handler,
    );
    WidgetsBinding.instance.addObserver(this);
    unawaited(controller.initialize());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused)
      unawaited(controller.setForeground(false));
    if (state == AppLifecycleState.resumed)
      unawaited(controller.setForeground(true));
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Sona',
    theme: ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF101210),
      colorScheme: ColorScheme.fromSeed(
        seedColor: accent,
        brightness: Brightness.dark,
        primary: accent,
        surface: const Color(0xFF191C19),
      ),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFF101210)),
      snackBarTheme: const SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
      ),
      navigationBarTheme: const NavigationBarThemeData(
        backgroundColor: Color(0xFF101210),
        indicatorColor: Color(0xFF303A26),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF222622),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
      ),
      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          fontSize: 36,
          fontWeight: FontWeight.w800,
          letterSpacing: -1.4,
        ),
        headlineMedium: TextStyle(
          fontSize: 28,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.8,
        ),
        titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
        titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        bodyMedium: TextStyle(fontSize: 14, height: 1.5),
      ),
    ),
    home: AppShell(controller: controller),
  );
}
