import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/spotify_content.dart';
import '../services/spotify_auth.dart';
import '../services/spotify_companion_api.dart';

class SpotifyCompanionController extends ChangeNotifier {
  SpotifyCompanionController() {
    api = SpotifyCompanionApi(
      token: auth.accessToken,
      onUnauthorized: _expired,
    );
  }
  final auth = SpotifyAuth(scopes: SpotifyCompanionApi.scopes);
  late final SpotifyCompanionApi api;
  final _prefs = SharedPreferencesAsync();
  String clientId = '';
  bool ready = false, connecting = false, commanding = false;
  bool _disposed = false, _foreground = true, _polling = false;
  int _generation = 0;
  int _playerRevision = 0;
  Timer? _timer;
  SpotifyPlayback playback = const SpotifyPlayback();
  DateTime? updatedAt;
  String? selectedDeviceId, selectedDeviceName, error;
  bool get connected => auth.connected;
  String? get target => selectedDeviceId ?? playback.device?.id;
  String get deviceName =>
      selectedDeviceName ?? playback.device?.name ?? 'Choose your phone';
  bool get canControl => connected && !commanding && target != null;
  bool allows(String action) => canControl && playback.allows(action);
  int get positionMs {
    final elapsed = playback.playing && updatedAt != null
        ? DateTime.now().difference(updatedAt!).inMilliseconds
        : 0;
    return (playback.positionMs + elapsed).clamp(
      0,
      playback.item?.durationMs ?? 0,
    );
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  String message(Object e) => e is SpotifyRemoteException
      ? e.message
      : e is SpotifyException
      ? e.message
      : 'Could not reach Spotify. Check your connection and try again.';
  void report(Object e) {
    error = message(e);
    _notify();
  }

  void clearError() {
    error = null;
    _notify();
  }

  Future<void> initialize() async {
    try {
      clientId = await _prefs.getString('sona.spotify.client_id') ?? '';
    } catch (_) {
      /* Client ID can be entered again; tokens are never persisted. */
    }
    ready = true;
    _notify();
  }

  Future<void> connect(String id, {bool fresh = false}) async {
    if (connecting) return;
    final generation = ++_generation;
    api.invalidateSession();
    _timer?.cancel();
    connecting = true;
    error = null;
    _notify();
    try {
      await auth.signIn(id, freshBrowserSession: fresh);
      if (_disposed || generation != _generation) return;
      clientId = id.trim();
      try {
        await _prefs.setString('sona.spotify.client_id', clientId);
      } catch (_) {}
      await refreshPlayer();
      _startPolling();
    } catch (e) {
      if (!_disposed && generation == _generation) error = message(e);
    } finally {
      if (generation == _generation) {
        connecting = false;
        _notify();
      }
    }
  }

  void _startPolling() {
    _timer?.cancel();
    if (_foreground && connected && !_disposed) {
      _timer = Timer.periodic(
        const Duration(seconds: 10),
        (_) => unawaited(refreshPlayer()),
      );
    }
  }

  void setForeground(bool value) {
    _foreground = value;
    _timer?.cancel();
    if (value && connected) {
      unawaited(refreshPlayer());
      _startPolling();
    }
  }

  Future<void> refreshPlayer({bool afterCommand = false}) async {
    if (!connected || _polling || _disposed) return;
    if (commanding && !afterCommand) return;
    if (api.retryAt != null && DateTime.now().isBefore(api.retryAt!)) return;
    _polling = true;
    final generation = _generation;
    final revision = _playerRevision;
    try {
      final value = await api.playback();
      if (_disposed || generation != _generation || revision != _playerRevision)
        return;
      if (selectedDeviceId != null && value.device?.id != selectedDeviceId) {
        playback = const SpotifyPlayback();
        updatedAt = null;
        _notify();
        return;
      }
      playback = value;
      updatedAt = DateTime.now();
      // Keep an explicitly selected target instead of moving to another device.
      if (value.device?.active == true) {
        selectedDeviceId = value.device!.id.isEmpty ? null : value.device!.id;
        selectedDeviceName = value.device!.name;
      }
      _notify();
    } catch (e) {
      if (!_disposed && generation == _generation) {
        error = message(e);
        _notify();
      }
    } finally {
      _polling = false;
    }
  }

  Future<bool> _command(Future<void> Function() action) async {
    if (commanding || !connected) return false;
    commanding = true;
    _playerRevision++;
    error = null;
    final generation = _generation;
    _notify();
    try {
      await action();
      if (_disposed || generation != _generation) return false;
      await refreshPlayer(afterCommand: true);
      return true;
    } catch (e) {
      if (!_disposed && generation == _generation) error = message(e);
      return false;
    } finally {
      if (generation == _generation) {
        commanding = false;
        _notify();
      }
    }
  }

  String _requireDevice() {
    final id = target;
    if (id == null || id.isEmpty)
      throw const SpotifyRemoteException(
        'Open Spotify and play something first. Then return here and choose your phone under Devices.',
      );
    return id;
  }

  Future<bool> play([SpotifyContent? item]) =>
      _command(() => api.play(item: item, deviceId: _requireDevice()));
  Future<bool> action(
    String action, {
    int? position,
    bool? shuffle,
    String? repeat,
    String? uri,
  }) => _command(
    () => api.command(
      action,
      _requireDevice(),
      position: position,
      shuffle: shuffle,
      repeat: repeat,
      uri: uri,
    ),
  );
  Future<bool> selectDevice(SpotifyDevice device) => _command(() async {
    if (device.restricted)
      throw const SpotifyRemoteException(
        'Spotify does not allow control of this device. Choose another.',
      );
    await api.transfer(device.id);
    selectedDeviceId = device.id;
    selectedDeviceName = device.name;
    playback = SpotifyPlayback(device: device);
    updatedAt = DateTime.now();
  });
  Future<bool> save(SpotifyContent item) => _command(() => api.save(item));
  void _expired() {
    api.invalidateSession();
    auth.signOut();
    _timer?.cancel();
    playback = const SpotifyPlayback();
    selectedDeviceId = selectedDeviceName = null;
    _notify();
  }

  void disconnect() {
    ++_generation;
    api.invalidateSession();
    auth.signOut();
    _timer?.cancel();
    playback = const SpotifyPlayback();
    updatedAt = null;
    selectedDeviceId = selectedDeviceName = null;
    connecting = commanding = false;
    error = null;
    _notify();
  }

  @override
  void dispose() {
    _disposed = true;
    ++_generation;
    _timer?.cancel();
    api.dispose();
    auth.dispose();
    super.dispose();
  }
}
