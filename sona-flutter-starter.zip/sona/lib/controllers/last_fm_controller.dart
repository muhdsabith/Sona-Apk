import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/track_model.dart';
import '../services/last_fm_service.dart';

class LastFmController extends ChangeNotifier {
  final _prefs = SharedPreferencesAsync();
  String _key = '';
  bool ready = false, loading = false, _disposed = false;
  int _revision = 0;
  bool saving = false;
  List<Track> tracks = [];
  String? error;
  DateTime? updatedAt;
  bool get configured => _key.isNotEmpty;
  void _notify() {
    if (!_disposed) notifyListeners();
  }

  Future<void> initialize() async {
    final revision = _revision;
    try {
      final saved = await _prefs.getString('olam.lastfm.api_key');
      if (_disposed || revision != _revision) return;
      _key = saved ?? const String.fromEnvironment('LASTFM_API_KEY');
    } catch (_) {
      error = 'Could not restore Last.fm settings.';
    }
    if (_disposed || revision != _revision) return;
    ready = true;
    _notify();
    if (configured) await load();
  }

  Future<bool> saveKey(String key) async {
    if (saving || _disposed) return false;
    saving = true;
    ++_revision;
    loading = false;
    _notify();
    try {
      // An empty saved value intentionally overrides a build-time key.
      await _prefs.setString('olam.lastfm.api_key', key.trim());
      if (_disposed) return false;
      _key = key.trim();
      ready = true;
      tracks = [];
      updatedAt = null;
      error = null;
      _notify();
    } catch (_) {
      error = 'Could not save the API key on this device.';
      _notify();
      return false;
    } finally {
      saving = false;
      _notify();
    }
    if (configured) await load();
    return true;
  }

  Future<void> load({bool force = false}) async {
    if (_disposed || !configured || loading || saving) return;
    if (!force &&
        updatedAt != null &&
        DateTime.now().difference(updatedAt!) < const Duration(minutes: 30))
      return;
    final revision = ++_revision;
    loading = true;
    error = null;
    _notify();
    final service = LastFmService(apiKey: _key);
    try {
      final result = await service.getTopTracks();
      if (_disposed || revision != _revision) return;
      tracks = result;
      updatedAt = DateTime.now();
    } catch (e) {
      if (!_disposed && revision == _revision)
        error = e is LastFmException ? e.message : 'Charts could not load.';
    } finally {
      service.close();
      if (!_disposed && revision == _revision) {
        loading = false;
        _notify();
      }
    }
  }

  @override
  void dispose() {
    _disposed = true;
    ++_revision;
    super.dispose();
  }
}
