import 'dart:async';
import 'dart:math';
import 'package:audio_session/audio_session.dart';
import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import '../models/media_item.dart';
import '../services/apis.dart';
import '../services/library_store.dart';

class AppController extends ChangeNotifier {
  AppController({required this.api, required this.store});
  final CatalogApi api;
  final LibraryStore store;
  final AudioPlayer player = AudioPlayer();
  final List<StreamSubscription<dynamic>> _subscriptions = [];
  LibrarySnapshot library = LibrarySnapshot();
  List<MediaItem> catalog = [];
  List<MediaItem> queue = [];
  MediaItem? current;
  bool initialized = false;
  bool loading = false;
  bool shuffle = false;
  bool repeat = false;
  bool _disposed = false;
  bool _foreground = true;
  bool _completionHandled = false;
  String? error;
  double speed = 1;
  int _lastSavedSecond = -1;

  void _refresh() { if (!_disposed) notifyListeners(); }

  Future<void> initialize() async {
    try {
      catalog = await api.fetchCatalog();
    } catch (_) { error = 'The catalogue could not be loaded. Restart to try again.'; }
    try {
      library = await store.read();
    } catch (_) { error = 'Saved library could not be read. Changes will be saved from this session.'; }
    try {
      final session = await AudioSession.instance;
      await session.configure(const AudioSessionConfiguration.music());
    } catch (_) { error = 'Audio setup failed. Try playing a track again.'; }
    _subscriptions.add(player.playerStateStream.listen((state) {
      _refresh();
      if (state.playing && state.processingState == ProcessingState.completed &&
          !loading && !_completionHandled) {
        _completionHandled = true;
        unawaited(_complete());
      }
    }));
    _subscriptions.add(player.positionStream.listen((position) {
      if (loading || current?.isPodcast != true ||
          player.processingState == ProcessingState.completed) return;
      final seconds = position.inSeconds;
      if (seconds % 5 == 0 && seconds != _lastSavedSecond) {
        _lastSavedSecond = seconds;
        library.progress[current!.id] = position.inMilliseconds;
        unawaited(persist());
      }
    }));
    _subscriptions.add(player.errorStream.listen((_) {
      error = 'Unable to play this audio. Tap play to try again.';
      loading = false;
      _refresh();
    }));
    initialized = true;
    _refresh();
  }

  List<MediaItem> get music => catalog.where((m) => !m.isPodcast).toList();
  List<MediaItem> get podcasts => catalog.where((m) => m.isPodcast).toList();
  List<MediaItem> get likedItems => catalog.where((m) => library.likes.contains(m.id)).toList();
  bool liked(MediaItem item) => library.likes.contains(item.id);
  List<MediaItem> playlistItems(UserPlaylist p) => p.itemIds
      .expand((id) => catalog.where((m) => m.id == id)).toList();

  Future<void> persist() async {
    try { await store.save(library); }
    catch (_) { error = 'Your changes could not be saved on this device.'; _refresh(); }
  }

  void _remember() {
    if (current?.isPodcast == true && !loading) {
      library.progress[current!.id] = player.processingState == ProcessingState.completed
          ? 0 : player.position.inMilliseconds;
    }
  }

  Future<void> playItem(MediaItem item, {List<MediaItem>? from}) async {
    if (loading || _disposed) return;
    _remember();
    loading = true;
    error = null;
    _refresh();
    try {
      await player.pause();
      queue = List.of(from == null || from.isEmpty ? [item] : from);
      if (!queue.any((m) => m.id == item.id)) queue.insert(0, item);
      current = item;
      _completionHandled = false;
      _lastSavedSecond = -1;
      final duration = item.source.startsWith('assets/')
          ? await player.setAsset(item.source)
          : await player.setUrl(item.source);
      final saved = item.isPodcast ? library.progress[item.id] ?? 0 : 0;
      if (saved > 0 && duration != null && saved < duration.inMilliseconds - 1000) {
        await player.seek(Duration(milliseconds: saved));
      }
      await player.setSpeed(item.isPodcast ? speed : 1);
      loading = false;
      _refresh();
      unawaited(_start());
      unawaited(persist());
    } catch (_) {
      error = 'Unable to load this audio. Tap play to try again.';
      loading = false;
      _refresh();
    }
  }

  Future<void> _start() async {
    if (_disposed || !_foreground) return;
    try { await player.play(); }
    catch (_) { error = 'Playback failed. Please try again.'; _refresh(); }
  }

  Future<void> togglePlayback() async {
    if (loading || current == null) return;
    if (error != null || player.processingState == ProcessingState.idle) {
      await playItem(current!, from: queue);
      return;
    }
    if (player.playing && player.processingState != ProcessingState.completed) {
      await player.pause();
      _remember();
      await persist();
    } else {
      if (player.processingState == ProcessingState.completed) {
        await player.seek(Duration.zero);
        _completionHandled = false;
      }
      unawaited(_start());
    }
    _refresh();
  }

  Future<void> _complete() async {
    if (current == null) return;
    final completedId = current!.id;
    if (current!.isPodcast) library.progress[current!.id] = 0;
    await persist();
    if (_disposed || loading || !_foreground || current?.id != completedId ||
        player.processingState != ProcessingState.completed) return;
    if (repeat) {
      await player.seek(Duration.zero);
      _completionHandled = false;
      unawaited(_start());
    } else {
      await next(automatic: true);
    }
  }

  Future<void> next({bool automatic = false}) async {
    if (queue.isEmpty || current == null || loading) return;
    final index = queue.indexWhere((m) => m.id == current!.id);
    if (shuffle && queue.length > 1) {
      final options = queue.where((m) => m.id != current!.id).toList();
      await playItem(options[Random().nextInt(options.length)], from: queue);
    } else if (index + 1 < queue.length) {
      await playItem(queue[index + 1], from: queue);
    } else if (!automatic) {
      await playItem(queue.first, from: queue);
    } else {
      await player.pause();
      _refresh();
    }
  }

  Future<void> previous() async {
    if (current == null || loading) return;
    if (player.position.inSeconds > 3) { await seek(Duration.zero); return; }
    final index = queue.indexWhere((m) => m.id == current!.id);
    if (index > 0) await playItem(queue[index - 1], from: queue);
    else { await seek(Duration.zero); }
  }

  Future<void> seek(Duration position) async {
    if (loading || current == null) return;
    final maxMs = player.duration?.inMilliseconds ?? 0;
    final ms = position.inMilliseconds.clamp(0, maxMs).toInt();
    try {
      await player.seek(Duration(milliseconds: ms));
      if (ms < maxMs) _completionHandled = false;
      _remember(); await persist();
    }
    catch (_) { error = 'Could not seek in this audio.'; _refresh(); }
  }

  Future<void> cycleSpeed() async {
    if (loading) return;
    const speeds = [1.0, 1.25, 1.5, 2.0];
    final nextSpeed = speeds[(speeds.indexOf(speed) + 1) % speeds.length];
    try { await player.setSpeed(nextSpeed); speed = nextSpeed; }
    catch (_) { error = 'Playback speed could not be changed.'; }
    _refresh();
  }

  void toggleShuffle() { shuffle = !shuffle; _refresh(); }
  void toggleRepeat() { repeat = !repeat; _refresh(); }
  void clearError() { error = null; _refresh(); }

  void toggleLike(MediaItem item) {
    if (!library.likes.remove(item.id)) library.likes.add(item.id);
    _refresh(); unawaited(persist());
  }

  UserPlaylist? createPlaylist(String name) {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return null;
    final p = UserPlaylist(id: DateTime.now().microsecondsSinceEpoch.toString(), name: trimmed);
    library.playlists.add(p); _refresh(); unawaited(persist()); return p;
  }

  void addToPlaylist(UserPlaylist p, MediaItem item) {
    if (!p.itemIds.contains(item.id)) p.itemIds.add(item.id);
    _refresh(); unawaited(persist());
  }

  void removeFromPlaylist(UserPlaylist p, MediaItem item) {
    p.itemIds.remove(item.id); _refresh(); unawaited(persist());
  }

  void deletePlaylist(UserPlaylist p) {
    library.playlists.remove(p); _refresh(); unawaited(persist());
  }

  Future<void> setForeground(bool foreground) async {
    _foreground = foreground;
    if (foreground || _disposed) return;
    try { await player.pause(); _remember(); await persist(); }
    catch (_) { error = 'Playback could not be paused.'; _refresh(); }
  }

  @override
  void dispose() {
    _disposed = true;
    for (final subscription in _subscriptions) { unawaited(subscription.cancel()); }
    unawaited(player.dispose());
    super.dispose();
  }
}
