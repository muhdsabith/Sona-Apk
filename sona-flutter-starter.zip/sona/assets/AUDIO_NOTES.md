# Demo audio

`afterglow.mp3`, `blue_hour.mp3`, and `night_drive.mp3` are original, procedurally synthesized instrumental demos created for this project. Each is 36 seconds long.

`ideas.mp3` and `morning.mp3` contain original short scripts spoken by a synthetic demo voice using the local Flite speech synthesizer. They are sample episodes, not recordings of real hosts. The scripts are in `tool/demo_scripts/`.

These demos are provided for use and modification with this starter. No Spotify audio, artist recordings, or third-party cover images are included. The application artwork is drawn by Flutter.
