# Raaga identity
Generated with the built-in image-generation tool. Original is raaga-logo-original.png; raaga-icon.png and native launcher assets are size variants.

Prompt: A square premium music app icon, original flowing ribbon r / sound wave, vivid lime #D6ED69 and lavender #CF9DEB on near-black #09090F, central safe area, no text or mockup.

Existing Android package and preference keys remain unchanged for upgrade compatibility. No trademark availability check has been performed.
