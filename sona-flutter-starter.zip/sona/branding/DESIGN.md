# Olam branding

Olam is the new display name. Cream #F6F1E7, terracotta #A64F39,
charcoal #292823. Original logo generated using the built-in image-generation
skill and integrated into the Flutter, Android adaptive/legacy and iOS icons.
Icon exports are resized versions of the generated mark. Source image is included.

Prompt: One square mobile launcher icon for Olam (Malayalam for wave). A
terracotta O monogram formed by two flowing rounded wave ribbons, on warm cream.
Minimal, flat vector-like styling with generous space for Android icon masks.
No wordmark, no device, no border. Symbol centered within the middle 52 percent.

The app remains internally named sona so the existing repository workflow,
Android application ID, saved-library keys and Spotify callback keep working.
The supplied ZIP filename and top-level sona directory are deliberately retained.

## Interface update 4.4.0

The UI now follows the supplied dark/violet references: background #0C0A10,
surface #211A2F, primary text #F6F2FF, muted text #B7ACC9 and accent #C7A0FF.
Gradient cards and a rounded bottom navigation frame carry the visual style.
Existing generated wave launcher logo is retained. The references' people,
ratings and booking controls are not part of this music app. Real catalogue
artwork and user-imported music populate cards; no invented example songs.

## Interface update 4.5.0

New reference: near-black #09090F, surface #1C1B24, lime #D6ED69, lavender
#CF9DEB, soft ambient pink/purple header lighting. Five working tabs replace
the three-tab layout. Home has a lavender discovery card; Search has four
pastel mood cards; Charts uses ranked Last.fm results, not sample content.
Shared theme covers native players, collection routes, settings, dialogs and
optional Spotify screens. Existing generated launcher mark remains unchanged.
No fake profile photo, invented playlist or downloaded/streaming claim was added.
