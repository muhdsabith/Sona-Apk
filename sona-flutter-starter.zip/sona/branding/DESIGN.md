# Sona icon

Created with the built-in image-generation tool. Mechanical resizing and PNG encoding were used to export native launcher sizes.

Prompt: Create one square mobile launcher icon for Sona, a music and podcast companion. A single bold custom lime-green S monogram whose smooth folded shape suggests a flowing audio waveform, using lime #C9F27A on near-black forest charcoal #101210. Center the symbol within the middle 56% of the square with generous equal margins for circular icon masks. Full-bleed opaque background, no rounded outer tile, border, mockup, words, Spotify mark, extra objects, gradients, shadows or glows. Refined geometric branding with crisp edges.

Generated original: sona-logo-original.png
Launcher source: sona-icon.png (1024 × 1024, opaque RGB)
