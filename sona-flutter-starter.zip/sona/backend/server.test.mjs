import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createServer,track} from './server.mjs';
async function withServer(sdk,run,options) {
  const server=createServer(sdk,options); await new Promise(r=>server.listen(0,'127.0.0.1',r));
  try { await run(`http://127.0.0.1:${server.address().port}`); }
  finally { server.closeAllConnections(); await new Promise(r=>server.close(r)); }
}
const sample={id:'abc_123',title:'A &amp; B',subtitle:'Artist',images:[{url:'https://example.com/art.jpg'}],duration:120};
test('search normalizes metadata and preserves SDK pagination',async()=>withServer({search:async p=>{assert.equal(p.offset,2);return {results:[sample],total:60};}},async base=>{
 const r=await fetch(base+'/search?q=Tamil&page=2');const j=await r.json();assert.equal(j.items[0].title,'A & B');assert.equal(j.nextPage,3);assert.equal(j.items[0].durationMs,120000);
}));
test('invalid query and unsupported methods never call SDK',async()=>withServer({},async base=>{
 assert.equal((await fetch(base+'/search?q=a&page=0')).status,400);
 assert.equal((await fetch(base+'/search?q=a',{method:'POST'})).status,405);
 assert.equal((await fetch(base+'/stream?id=https://x')).status,400);
}));
test('resolves current track and prefers supported 160kbps stream',async()=>withServer({getById:async()=>({songs:[{...sample,media:{encryptedUrl:'opaque'}}]}),experimental:{fetchStreamUrls:async(value,runtime,ack)=>{
 assert.equal(value,'opaque');assert.equal(runtime,'node');assert.equal(ack,true);
 return [{bitrate:'320kbps',url:'https://example.com/a.m4a'},{bitrate:'160kbps',url:'https://example.com/b.m4a'}];
}}},async base=>assert.equal((await (await fetch(base+'/stream?id=abc_123')).json()).url,'https://example.com/b.m4a')));
test('rejects unsafe stream and missing song',async()=>withServer({getById:async({songIds})=>({songs:songIds==='missing'?[]:[sample]}),experimental:{fetchStreamUrls:async()=>[{url:'javascript:alert(1)'}]}},async base=>{
 assert.equal((await fetch(base+'/stream?id=abc_123')).status,422);
 assert.equal((await fetch(base+'/stream?id=missing')).status,404);
}));
test('sanitizes upstream failures and deadlines',async()=>withServer({search:async()=>{throw new Error('private upstream internals');}},async base=>{
 const r=await fetch(base+'/search?q=a');assert.equal(r.status,502);assert.ok(!(await r.text()).includes('private'));
}));
test('deadline returns a useful error instead of hanging',async()=>withServer({search:()=>new Promise(()=>{})},async base=>assert.equal((await fetch(base+'/search?q=a')).status,502),{timeoutMs:10}));
test('malformed songs are excluded',()=>assert.equal(track({id:'https://x',title:'bad'}),null));
test('health identifies protocol version',async()=>withServer({},async base=>assert.deepEqual(await (await fetch(base+'/health')).json(),{service:'raaga-saavn',version:1})));
