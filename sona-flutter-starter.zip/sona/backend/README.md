# Raaga Saavn backend

This small Node server adapts **@saavn-labs/sdk 0.1.5** to the Flutter app.
It is an unofficial third-party integration, not an official JioSaavn developer
service. The SDK stream URL method is experimental. No Spotify app or JioSaavn
app is required by this code; successful access to the upstream service is required.

## Run and host

1. Put this backend folder in a GitHub repository (include package-lock.json).
2. On a Node/Docker hosting service, select that repository and this folder as
   the root directory. Use Node 22 or newer.
3. Build command: `npm ci --omit=dev --ignore-scripts`
4. Start command: `npm start`. The server listens on the hosting service's PORT
   environment variable, or 3000 by default. A Dockerfile is also included.
5. Enable HTTPS through your hosting service. Open `https://YOUR-HOST/health`:
   it should show `{"service":"raaga-saavn","version":1}`.
6. In Raaga, open Settings → Saavn music server. Paste `https://YOUR-HOST`
   (without /health) and choose Check & save.
7. Home and Search now use this server. Select a song to resolve a fresh stream
   and play it using the app's existing background audio service.

To return online discovery to YouTube, clear the server URL in Settings.
Existing saved songs and playlists remain. Saved Saavn songs need a configured
server again to play. The server URL is stored locally, not embedded in the APK.

## Routes

- `GET /health`: protocol check (does NOT certify upstream availability).
- `GET /search?q=Kesariya&page=1`: 20 metadata results, next page when available.
- `GET /stream?id=SONG_ID`: resolves an HTTPS stream URL on demand.

The server does not host or proxy audio. It accepts only fixed routes and song
IDs, has request deadlines and an eight-request concurrency cap. For a public
or large deployment, add host-level quotas/rate limits and monitoring. Do not
put passwords in the app's server URL; this simple server has no login system.
Use your hosting provider's standard security controls before exposing it widely.

## Tests and limitations

`npm test`: eight offline contract tests with a mocked SDK. Flutter adapter has
12 offline checks. Live search in the build environment returned HTML instead
of JSON on 2026-09-27. No playable media or physical-phone background playback
was verified. Do not assume a successful health check means songs will stream.
Upstream availability, region restrictions, SDK changes and hosting-network
restrictions may prevent playback. There are no proxy rotations, bypasses,
credentials or DRM fields in this adapter. SDK dependency licenses are in npm;
its MIT license is included as SAAVN_SDK_LICENSE.txt.
