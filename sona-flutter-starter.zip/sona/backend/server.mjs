import http from 'node:http';
import {pathToFileURL} from 'node:url';
import {Song} from '@saavn-labs/sdk';

export function httpsUrl(value) {
  try { const u = new URL(value); return u.protocol === 'https:' && !u.username && !u.password ? u.href : null; }
  catch { return null; }
}
const clean = value => typeof value === 'string' ? value.replaceAll('&amp;', '&').replaceAll('&quot;', '"').replaceAll('&#039;', "'") : '';
export function track(s) {
  if (!s || typeof s.id !== 'string' || !/^[\w-]{1,80}$/.test(s.id) || !s.title) return null;
  return {id:s.id, title:clean(s.title), artist:clean(s.artists?.primary?.map(a=>a.name).filter(Boolean).join(', ') || s.subtitle || 'Unknown artist'),
    image: [...(s.images || [])].reverse().map(i=>httpsUrl(i.url)).find(Boolean) || '',
    durationMs: Number.isFinite(s.duration) ? Math.round(s.duration * 1000) : null};
}
async function deadline(promise, ms) {
  let timer;
  try { return await Promise.race([promise, new Promise((_, reject) => { timer = setTimeout(()=>reject(new Error('upstream timeout')), ms); })]); }
  finally { clearTimeout(timer); }
}
export function createServer(sdk=Song, {timeoutMs=15000}={}) {
  let active=0;
  return http.createServer(async (req,res)=>{
    const send=(code,body)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(body));};
    if(req.method!=='GET') return send(405,{error:'Only GET is supported.'});
    const u=new URL(req.url,'http://localhost');
    if(u.pathname==='/health') return send(200,{service:'raaga-saavn',version:1});
    if(active>=8) return send(429,{error:'Server busy. Try again shortly.'});
    const query=(u.searchParams.get('q')||'').trim();
    const page=Number(u.searchParams.get('page')||1);
    const id=u.searchParams.get('id')||'';
    if(u.pathname==='/search' && (!query || query.length>120 || !Number.isInteger(page) || page<1 || page>50)) return send(400,{error:'Enter a search of 1–120 characters.'});
    if(u.pathname==='/stream' && !/^[\w-]{1,80}$/.test(id)) return send(400,{error:'Invalid song ID.'});
    if(!['/search','/stream'].includes(u.pathname)) return send(404,{error:'Route not found.'});
    active++;
    try {
      if(u.pathname==='/search') {
        const r=await deadline(sdk.search({query,limit:20,offset:page}),timeoutMs);
        if(!Array.isArray(r.results)) throw new Error('invalid upstream');
        const items=r.results.map(track).filter(Boolean);
        return send(200,{items,nextPage:items.length && page*20<Number(r.total) && page<50 ? page+1:null});
      }
      const r=await deadline(sdk.getById({songIds:id}),timeoutMs);
      const song=r.songs?.find(s=>s.id===id);
      if(!song) return send(404,{error:'This song is no longer available.'});
      // SDK experimental URL resolver only; no DRM fields or request bypasses.
      const urls=await deadline(sdk.experimental.fetchStreamUrls(song.media?.encryptedUrl,'node',true),timeoutMs);
      const chosen=urls.find(x=>x.bitrate==='160kbps' && httpsUrl(x.url)) || urls.find(x=>httpsUrl(x.url));
      if(!chosen) return send(422,{error:'No supported audio stream is available for this song.'});
      return send(200,{url:httpsUrl(chosen.url)});
    } catch { return send(502,{error:'JioSaavn is unavailable from this server. Please try later.'}); }
    finally { active--; }
  });
}
if(process.argv[1] && import.meta.url===pathToFileURL(process.argv[1]).href) {
  // Bound actual upstream fetches as well as each API response.
  const originalFetch=globalThis.fetch;
  globalThis.fetch=(input, options={})=>originalFetch(input, {...options,
    signal: options.signal ? AbortSignal.any([options.signal, AbortSignal.timeout(12000)]) : AbortSignal.timeout(12000)});
  const server=createServer();
  server.requestTimeout=20000;
  server.listen(Number(process.env.PORT||3000),'0.0.0.0',()=>console.log('Raaga API listening'));
}
