import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:youtube_explode_dart/src/extensions/helpers_extension.dart';
import 'package:youtube_explode_dart/src/reverse_engineering/pages/search_page.dart';
import 'package:youtube_explode_dart/src/videos/streams/models/audio_track.dart';
import 'package:http_parser/http_parser.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart' as yt;
import '../lib/models/media_item.dart';
import '../lib/services/online_music_api.dart';

int count = 0;
void check(bool pass, String description) {
  if (!pass) throw StateError(description);
  count++;
  print('PASS $description');
}

yt.AudioOnlyStreamInfo stream(
  String container,
  int bitrate, {
  bool? isDefault,
}) => yt.AudioOnlyStreamInfo(
  yt.VideoId('BaW_jenozKc'),
  140,
  Uri.parse('https://media.example.test/audio'),
  yt.StreamContainer.parse(container),
  yt.FileSize(1000),
  yt.Bitrate(bitrate),
  container == 'mp4' ? 'mp4a.40.2' : 'opus',
  'audio',
  [],
  MediaType('audio', container),
  isDefault == null
      ? null
      : AudioTrack(
          id: isDefault ? 'original' : 'dubbed',
          displayName: 'test',
          audioIsDefault: isDefault,
        ),
);
Future<void> main() async {
  check(
    OnlineMusicApi.videoId('youtube:BaW_jenozKc') == 'BaW_jenozKc',
    'Stable video ID',
  );
  for (final invalid in [
    '',
    'youtube:short',
    'https://youtube.com/watch?v=BaW_jenozKc',
    'youtube:../../secret',
    'youtube:BaW_jenozKc?token=x',
  ]) {
    var rejected = false;
    try {
      OnlineMusicApi.videoId(invalid);
    } on OnlineMusicException {
      rejected = true;
    }
    check(rejected, 'Reject invalid source: $invalid');
  }
  final mp4 = stream('mp4', 128000);
  final opus = stream('webm', 160000);
  check(
    identical(OnlineMusicApi.chooseStream([opus, mp4]), mp4),
    'Prefer mobile AAC/MP4',
  );
  check(
    identical(OnlineMusicApi.chooseStream([opus]), opus),
    'Allow audio format fallback',
  );
  final high = stream('mp4', 192000);
  check(
    identical(OnlineMusicApi.chooseStream([mp4, high]), high),
    'Prefer bitrate within compatible format',
  );
  final original = stream('webm', 96000, isDefault: true);
  final dubbed = stream('mp4', 192000, isDefault: false);
  check(
    identical(OnlineMusicApi.chooseStream([dubbed, original]), original),
    'Prefer original/default audio over dubbed audio',
  );
  var emptyRejected = false;
  try {
    OnlineMusicApi.chooseStream([]);
  } on OnlineMusicException {
    emptyRejected = true;
  }
  check(emptyRejected, 'Report unavailable audio');
  const item = MediaItem(
    id: 'youtube-BaW_jenozKc',
    title: 'Test',
    creator: 'Creator',
    category: 'YouTube',
    kind: MediaKind.music,
    source: 'youtube:BaW_jenozKc',
    color: 0xFFC9F27A,
    art: 0,
    description: 'test',
  );
  final encoded = jsonEncode(item.toJson());
  final restored = MediaItem.fromJson(
    jsonDecode(encoded) as Map<String, dynamic>,
  );
  check(
    restored.isYoutube &&
        restored.source == item.source &&
        restored.id == item.id,
    'Saved favourite survives serialization',
  );
  check(
    !encoded.contains('googlevideo.com') && !encoded.contains('token='),
    'Library contains no expiring audio URL',
  );
  final headers = yt.clientRequestHeaders(yt.YoutubeApiClient.visionOs);
  check(
    headers.keys.any((k) => k.toLowerCase() == 'user-agent'),
    'Preserve extractor client identity for playback',
  );
  for (final live in [false, true]) {
    final data = {
      'contents': {
        'twoColumnSearchResultsRenderer': {
          'primaryContents': {
            'sectionListRenderer': {
              'contents': [
                {
                  'itemSectionRenderer': {
                    'contents': [
                      {
                        'videoRenderer': {
                          'videoId': 'BaW_jenozKc',
                          'title': {
                            'runs': [
                              {'text': 'Regression track'},
                            ],
                          },
                          'ownerText': {
                            'runs': [
                              {
                                'text': 'Creator',
                                'navigationEndpoint': {
                                  'browseEndpoint': {
                                    'browseId': 'UCaaaaaaaaaaaaaaaaaaaaaa',
                                  },
                                },
                              },
                            ],
                          },
                          'viewCountText': {
                            'runs': [
                              {'text': '1,234'},
                              {'text': live ? ' watching' : ' views'},
                            ],
                          },
                          'thumbnail': {'thumbnails': []},
                          'lengthText': {'simpleText': live ? 'LIVE' : '3:12'},
                        },
                      },
                    ],
                  },
                },
              ],
            },
          },
        },
      },
    };
    final page = SearchPage.parse(
      '<script>var ytInitialData = ${jsonEncode(data)};</script>',
      'test',
    );
    final video = page.searchContent.single as yt.SearchVideo;
    check(
      video.viewCount == 1234 && video.isLive == live,
      'Parse dynamic text-run response (live=$live)',
    );
  }
  check(
    'Streamed 2 days'.toDateTime() == null,
    'Ignore unrecognized streamed-date text',
  );
  check('2 unknown ago'.toDateTime() == null, 'Ignore unknown date units');
  check(
    'Streamed 2 days ago'.toDateTime() != null,
    'Keep valid relative dates',
  );
  final api = OnlineMusicApi();
  check(
    (await api.search('   ')).items.isEmpty,
    'Empty search makes no request',
  );
  api.dispose();
  var requests = 0;
  var now = DateTime.utc(2026, 9, 27);
  final limited = OnlineMusicApi(
    now: () => now,
    clientFactory: () => yt.YoutubeExplode(
      httpClient: yt.YoutubeHttpClient(
        MockClient((request) async {
          requests++;
          return http.Response('Too many requests', 429, request: request);
        }),
      ),
    ),
  );
  try {
    await limited.search('test');
  } on OnlineMusicException catch (e) {
    check(
      e.message.contains('one minute'),
      'HTTP 429 is explained as a cooldown',
    );
  }
  check(requests == 1, 'HTTP 429 is not automatically retried');
  try {
    await limited.search('another');
  } on OnlineMusicException catch (e) {
    check(
      e.message.contains('seconds'),
      'Repeated search reports remaining cooldown',
    );
  }
  try {
    await limited.resolve(item);
  } on OnlineMusicException catch (e) {
    check(e.message.contains('seconds'), 'Playback shares the search cooldown');
  }
  check(requests == 1, 'Cooldown blocks search and playback network requests');
  now = now.add(const Duration(seconds: 61));
  try {
    await limited.search('test');
  } on OnlineMusicException catch (_) {}
  check(requests == 2, 'Manual requests resume after cooldown');
  limited.dispose();
  print(
    '$count checks passed. Offline checks only; no phone playback verified.',
  );
}
