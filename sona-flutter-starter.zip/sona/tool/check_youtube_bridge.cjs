const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(process.argv[2], 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const messages = [], events = {};
let config, pauses = 0, count = 0;
function check(ok, label) { assert.ok(ok, label); count++; console.log('PASS ' + label); }
const bridge = { postMessage: s => messages.push(JSON.parse(s)) };
const document = { hidden: false, addEventListener: (n, f) => events[n] = f };
const context = vm.createContext({ document, OlamPlayer: bridge,
  window: { OlamPlayer: bridge, addEventListener: (n, f) => events[n] = f },
  YT: { Player: function(_, options) { config = options; return { pauseVideo() { pauses++; } }; } }
});
vm.runInContext(script, context);
vm.runInContext('onYouTubeIframeAPIReady()', context);
check(config.videoId === '60ItHLz5WEA' && config.playerVars.origin === 'https://com.example.sona', 'Correct video and app identity reach the player');
check(config.playerVars.autoplay === 0 && config.playerVars.controls === 1, 'User-initiated playback with visible controls');
config.events.onReady();
check(messages.at(-1).type === 'ready', 'Readiness reaches the native bridge');
config.events.onStateChange({data:1});
check(messages.at(-1).type === 'state' && messages.at(-1).value === 1, 'Actual playing state reaches native history tracking');
config.events.onError({data:153});
check(messages.at(-1).type === 'error' && messages.at(-1).value === 153, 'Provider error code is preserved');
const before = messages.length;
events.pagehide();
config.events.onStateChange({data:1});
check(pauses === 2 && messages.length === before, 'Hidden player is paused and cannot report playing');
document.hidden = false; events.visibilitychange();
config.events.onStateChange({data:1});
check(messages.at(-1).type === 'state' && messages.length === before + 1, 'Visible player can resume after a user action');
console.log(`${count} JavaScript bridge checks passed. Mock player only.`);
