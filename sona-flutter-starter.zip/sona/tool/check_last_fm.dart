import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import '../lib/models/track_model.dart';
import '../lib/services/last_fm_service.dart';

Future<void> main() async {
  var count = 0;
  void check(bool value, String name) {
    if (!value) throw StateError(name);
    count++;
    print('PASS $name');
  }

  Future<void> fails(LastFmService service, String expected) async {
    try {
      await service.getTopTracks();
      throw StateError('Expected error');
    } on LastFmException catch (e) {
      check(e.message.contains(expected), 'Friendly error: $expected');
    } finally {
      service.close();
    }
  }

  final malformed = Track.fromJson({
    'name': 9,
    'artist': {'name': false},
    'image': [
      false,
      null,
      {'#text': 4},
    ],
    'url': 'javascript:alert(1)',
  });
  check(
    malformed.name == 'Unknown Track' &&
        malformed.artistName == 'Unknown Artist' &&
        malformed.imageUrl.isEmpty &&
        malformed.url.isEmpty,
    'Malformed fields do not crash',
  );
  final map = Track.fromJson({
    'name': 'Song',
    'artist': {'name': 'Artist'},
    'image': [
      {'size': 'extralarge', '#text': 'https://images.example/large'},
      {'size': 'small', '#text': 'https://images.example/small'},
    ],
    'url': 'http://www.last.fm/music/a',
  });
  check(
    map.imageUrl.endsWith('/large') && map.artistName == 'Artist',
    'Select artwork by size, not array position',
  );
  check(
    map.url == 'https://www.last.fm/music/a',
    'Last.fm page upgraded to HTTPS',
  );
  check(
    Track.fromJson({'artist': 'Singer'}).artistName == 'Singer',
    'String artist',
  );
  check(
    Track.fromJson({
          'artist': {'#text': 'Singer'},
        }).artistName ==
        'Singer',
    'Text artist',
  );
  check(
    Track.fromJson({
      'url': 'https://last.fm.attacker.example/test',
    }).url.isEmpty,
    'Reject unrelated page host',
  );
  var calls = 0;
  final client = MockClient((request) async {
    calls++;
    check(
      request.url.host == 'ws.audioscrobbler.com' &&
          request.url.queryParameters['api_key'] == 'test-key' &&
          request.url.queryParameters['limit'] == '100',
      'Encoded request and bounded limit',
    );
    return http.Response(
      '{"tracks":{"track":[{"name":"Song","artist":"Artist"},null,{"name":"Song","artist":"Artist"},{"name":null}]}}',
      200,
    );
  });
  final service = LastFmService(apiKey: 'test-key', client: client);
  check(
    (await service.getTopTracks(limit: 500)).length == 1 && calls == 1,
    'Skip malformed rows and duplicate tracks',
  );
  await fails(
    LastFmService(
      apiKey: 'YOUR_LASTFM_API_KEY',
      client: MockClient((_) => throw StateError('Must not request')),
    ),
    'Add your Last.fm',
  );
  for (final fixture in <(String, int, String)>[
    ('{"error":10,"message":"private detail"}', 200, 'rejected'),
    ('{"error":"29"}', 200, 'limiting'),
    ('unavailable', 503, 'HTTP 503'),
    ('{}', 200, 'unexpected'),
    ('not json', 200, 'unexpected'),
    ('[]', 200, 'unexpected'),
    ('{}', 429, 'limiting'),
  ]) {
    await fails(
      LastFmService(
        apiKey: 'test',
        client: MockClient((_) async => http.Response(fixture.$1, fixture.$2)),
      ),
      fixture.$3,
    );
  }
  final empty = LastFmService(
    apiKey: 'test',
    client: MockClient(
      (_) async => http.Response('{"tracks":{"track":[]}}', 200),
    ),
  );
  check((await empty.getTopTracks()).isEmpty, 'Empty charts are valid');
  await fails(
    LastFmService(
      apiKey: 'test',
      client: MockClient(
        (_) async => throw http.ClientException('private key and URL'),
      ),
    ),
    'Check your connection',
  );
  await fails(
    LastFmService(
      apiKey: 'test',
      timeout: Duration.zero,
      client: MockClient((_) => Completer<http.Response>().future),
    ),
    'too long',
  );
  print('$count Last.fm checks passed.');
}
