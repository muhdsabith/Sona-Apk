import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import '../lib/services/saavn_service.dart';

Future<void> main() async {
  var count = 0;
  void check(bool ok, String label) {
    if (!ok) throw StateError(label);
    count++;
    print('PASS $label');
  }

  check(
    SaavnService.validateBase('https://example.com/api/') ==
        'https://example.com/api',
    'normalizes base path',
  );
  for (final bad in [
    'http://example.com',
    'https://user:pass@example.com',
    'https://example.com?key=secret',
  ]) {
    try {
      SaavnService.validateBase(bad);
      throw StateError('accepted unsafe base');
    } on SaavnException {
      count++;
    }
  }
  var route = 'search';
  final service = SaavnService(
    client: MockClient((req) async {
      if (route == 'search') {
        check(
          req.url.queryParameters['q'] == 'A & B',
          'query is encoded safely',
        );
        return http.Response(
          jsonEncode({
            'items': [
              {
                'id': 'abc',
                'title': 'Song',
                'artist': 'Artist',
                'image': 'javascript:x',
                'durationMs': 120000,
              },
              {'id': 'abc', 'title': 'Duplicate'},
              {'id': {}, 'title': 3},
            ],
            'nextPage': 2,
          }),
          200,
        );
      }
      if (route == 'stream')
        return http.Response('{"url":"https://cdn.example/audio.m4a"}', 200);
      if (route == 'unsafe')
        return http.Response('{"url":"file:///private"}', 200);
      if (route == 'html')
        return http.Response('<html>unavailable</html>', 200);
      if (route == 'limit') return http.Response('{}', 429);
      return http.Response('{"service":"raaga-saavn","version":1}', 200);
    }),
  )..baseUrl = 'https://example.com';
  final result = await service.search('A & B');
  check(
    result.items.length == 1 && result.nextPage == 2,
    'deduplicates malformed songs and accepts pagination',
  );
  final song = result.items.single;
  check(
    song.isSaavn && song.source == 'saavn:abc' && song.artworkUrl == null,
    'stable source ID and safe artwork',
  );
  route = 'stream';
  check(
    (await service.resolve(song)).endsWith('.m4a'),
    'fresh stream resolution',
  );
  for (final mode in ['unsafe', 'html', 'limit']) {
    route = mode;
    try {
      await service.resolve(song);
      throw StateError('accepted $mode');
    } on SaavnException {
      check(true, 'friendly failure for $mode');
    }
  }
  route = 'health';
  await service.check();
  check(true, 'health protocol accepted');
  service.dispose();
  print('$count Saavn checks passed');
}
