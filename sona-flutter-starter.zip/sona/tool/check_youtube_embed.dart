import 'dart:io';
import '../lib/services/youtube_embed.dart';

Future<void> main(List<String> args) async {
  var count = 0;
  void check(bool ok, String message) {
    if (!ok) throw StateError(message);
    count++;
    print('PASS $message');
  }

  check(
    YoutubeEmbed.origin == 'https://com.example.sona',
    'Origin matches installed Android application ID',
  );
  check(
    YoutubeEmbed.idFromSource('youtube:60ItHLz5WEA') == '60ItHLz5WEA',
    'Valid video ID accepted',
  );
  for (final source in [
    'youtube:<script>',
    'youtube:60ItHLz5WEA?x=1',
    'https://example.com',
    'youtube:',
  ]) {
    var rejected = false;
    try {
      YoutubeEmbed.html(source);
    } on FormatException {
      rejected = true;
    }
    check(rejected, 'Reject malformed source before producing HTML');
  }
  check(
    YoutubeEmbed.errorMessage(153).contains('identity'),
    'Identity failure is distinguished from rate limit',
  );
  check(
    YoutubeEmbed.errorMessage(150).contains('owner'),
    'Embedding restrictions are explained',
  );
  check(
    YoutubeEmbed.errorMessage(100).contains('private'),
    'Unavailable video is explained',
  );
  final html = YoutubeEmbed.html('youtube:60ItHLz5WEA');
  if (args.isNotEmpty) File(args.first).writeAsStringSync(html);
  print('$count embed checks passed. Actual phone playback not verified.');
}
