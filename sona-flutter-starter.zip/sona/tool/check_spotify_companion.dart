// Offline checks for the production API/model code. Uses no Flutter engine,
// real account, network connection, or external playback device.
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import '../lib/models/spotify_content.dart';
import '../lib/services/spotify_companion_api.dart';

int passed = 0;
void check(bool condition, String name) {
  if (!condition) throw StateError('FAILED: $name');
  passed++;
  print('PASS: $name');
}

Future<SpotifyRemoteException> fails(
  Future<Object?> operation,
  int? status,
) async {
  try {
    await operation;
  } on SpotifyRemoteException catch (e) {
    if (status != null && e.status != status) rethrow;
    return e;
  }
  throw StateError('Expected SpotifyRemoteException');
}

Map<String, Object?> content(String id, String type) => {
  'id': id,
  'type': type,
  'name': 'Example $type',
  'duration_ms': 60000,
  'artists': [
    {'name': 'Artist'},
  ],
};
SpotifyCompanionApi apiWith(
  Future<http.Response> Function(http.Request) response, {
  Future<String> Function({bool forceRefresh})? token,
  void Function()? unauthorized,
}) => SpotifyCompanionApi(
  token: token ?? ({bool forceRefresh = false}) async => 'test-token',
  onUnauthorized: unauthorized ?? () {},
  client: MockClient(response),
);

Future<void> main() async {
  final track = SpotifyContent.fromJson(content('track1', 'track'));
  final album = SpotifyContent.fromJson(content('album1', 'album'));
  final episode = SpotifyContent.fromJson(content('episode1', 'episode'));
  final playlist = SpotifyContent.fromJson(content('playlist1', 'playlist'));
  check(
    track.uri == 'spotify:track:track1' && track.subtitle == 'Artist',
    'track parsing and canonical URI',
  );
  check(
    episode.isAudio && !episode.isCollection && album.isCollection,
    'content type classification',
  );
  final page = SpotifyPage.fromJson({
    'items': [
      null,
      {'item': content('track1', 'track')},
      {'track': content('episode1', 'episode')},
      {
        'item': {'id': null},
      },
    ],
    'next': 'https://api.spotify.com/v1/playlists/a/items?offset=20',
  }, wrapper: 'item');
  check(
    page.items.length == 2 && page.nextOffset == 20,
    'new and legacy playlist wrappers; unavailable items skipped',
  );
  final state = SpotifyPlayback.fromJson({
    'item': content('episode1', 'episode'),
    'is_playing': true,
    'progress_ms': 1000,
    'device': {'id': 'phone', 'name': 'My phone', 'is_active': true},
    'actions': {
      'disallows': {'seeking': true},
    },
  });
  check(
    state.playing && state.item?.type == 'episode' && !state.allows('seeking'),
    'podcast playback and restricted controls',
  );
  check(
    SpotifyPlayback.fromJson({
          'currently_playing_type': 'ad',
          'item': null,
        }).item ==
        null,
    'advertisement and empty playback handling',
  );

  final requests = <http.Request>[];
  var api = apiWith((r) async {
    requests.add(r);
    return http.Response('', 204);
  });
  await api.play(item: track, deviceId: 'phone');
  check(
    requests.last.method == 'PUT' &&
        requests.last.url.path == '/v1/me/player/play' &&
        requests.last.url.queryParameters['device_id'] == 'phone' &&
        jsonDecode(requests.last.body)['uris'][0] == track.uri,
    'track playback targets selected device',
  );
  await api.play(item: album, deviceId: 'phone');
  check(
    jsonDecode(requests.last.body)['context_uri'] == album.uri,
    'album context playback',
  );
  await api.play(deviceId: 'phone');
  check(requests.last.body.isEmpty, 'resume has no fabricated track body');
  await api.transfer('phone');
  check(
    jsonDecode(requests.last.body)['play'] == false &&
        jsonDecode(requests.last.body)['device_ids'][0] == 'phone',
    'transfer does not start playback',
  );
  await api.command('pause', 'phone');
  check(
    requests.last.method == 'PUT' && requests.last.url.path.endsWith('/pause'),
    'pause method and endpoint',
  );
  await api.command('next', 'phone');
  check(
    requests.last.method == 'POST' && requests.last.body.isEmpty,
    'skip does not send a JSON null body',
  );
  await api.command('seek', 'phone', position: -20);
  check(
    requests.last.url.queryParameters['position_ms'] == '0',
    'seek clamps negative positions',
  );
  await api.command('shuffle', 'phone', shuffle: true);
  check(
    requests.last.url.queryParameters['state'] == 'true',
    'shuffle parameter',
  );
  await api.command('repeat', 'phone', repeat: 'track');
  check(
    requests.last.url.queryParameters['state'] == 'track',
    'repeat parameter',
  );
  await api.command('queue', 'phone', uri: episode.uri);
  check(
    requests.last.url.queryParameters['uri'] == episode.uri &&
        requests.last.method == 'POST',
    'episode queue parameter',
  );
  await api.save(track);
  check(
    requests.last.url.path == '/v1/me/library' &&
        requests.last.url.queryParameters['uris'] == track.uri,
    '2026 library save endpoint',
  );
  check(
    requests.every(
      (r) =>
          r.url.scheme == 'https' &&
          r.url.host == 'api.spotify.com' &&
          r.headers['Authorization'] == 'Bearer test-token' &&
          !r.followRedirects,
    ),
    'tokens confined to Spotify HTTPS origin',
  );
  check((await api.playback()).item == null, '204 playback response accepted');
  api.dispose();

  api = apiWith((r) async {
    check(
      r.url.queryParameters['limit'] == '10' &&
          r.url.queryParameters['offset'] == '10',
      'search respects development pagination limits',
    );
    return http.Response(
      jsonEncode({
        'tracks': {
          'items': [content('track1', 'track')],
          'next': 'https://api.spotify.com/v1/search?offset=20',
        },
      }),
      200,
    );
  });
  final search = await api.search('test', 'track', offset: 10);
  check(
    search.items.single.id == 'track1' && search.nextOffset == 20,
    'search result pagination',
  );
  api.dispose();

  api = apiWith((r) async {
    check(
      r.url.path == '/v1/playlists/playlist1/items',
      '2026 playlist items endpoint',
    );
    return http.Response(
      jsonEncode({
        'items': [
          {'item': content('track1', 'track')},
        ],
      }),
      200,
    );
  });
  check(
    (await api.collection(playlist)).items.single.id == 'track1',
    'playlist contents parsed',
  );
  api.dispose();

  var calls = 0, refreshes = 0;
  api = apiWith(
    (r) async {
      calls++;
      return http.Response(
        calls == 1 ? '' : '{"devices":[]}',
        calls == 1 ? 401 : 200,
      );
    },
    token: ({bool forceRefresh = false}) async {
      if (forceRefresh) refreshes++;
      return 'token';
    },
  );
  await api.devices();
  check(calls == 2 && refreshes == 1, '401 refreshes and retries once');
  api.dispose();

  calls = 0;
  var signedOut = false;
  api = apiWith((r) async {
    calls++;
    return http.Response('', 401);
  }, unauthorized: () => signedOut = true);
  await fails(api.devices(), 401);
  check(calls == 2 && signedOut, 'repeated 401 stops and signs out');
  api.dispose();

  calls = 0;
  api = apiWith((r) async {
    calls++;
    return http.Response('', 429, headers: {'retry-after': '60'});
  });
  await fails(api.devices(), 429);
  await fails(api.playback(), 429);
  check(
    calls == 1 && api.retryAt != null,
    '429 cooldown prevents further API traffic',
  );
  api.dispose();

  api = apiWith((r) async => http.Response('', 404));
  final missing = await fails(api.play(deviceId: 'phone'), 404);
  check(
    missing.message.contains('Open Spotify'),
    'missing player gives recovery instructions',
  );
  api.dispose();

  api = apiWith((r) async => http.Response('', 403));
  check(
    (await fails(api.save(track), 403)).message.contains('Premium'),
    '403 access requirements surfaced',
  );
  api.dispose();

  calls = 0;
  api = apiWith((r) async {
    calls++;
    return http.Response(
      '',
      302,
      headers: {'location': 'https://example.com/steal'},
    );
  });
  await fails(api.devices(), 302);
  check(
    calls == 1,
    'redirect response rejected without following external URL',
  );
  api.dispose();

  final delayed = Completer<http.Response>();
  final requested = Completer<void>();
  signedOut = false;
  api = apiWith((r) {
    requested.complete();
    return delayed.future;
  }, unauthorized: () => signedOut = true);
  final pending = api.devices();
  await requested.future;
  api.invalidateSession();
  final failure = fails(pending, null);
  delayed.complete(http.Response('', 401));
  await failure;
  check(!signedOut, 'old response cannot sign out a replacement session');
  api.dispose();
  print(
    'Completed: $passed offline companion checks passed. No network requests or account actions performed.',
  );
}
