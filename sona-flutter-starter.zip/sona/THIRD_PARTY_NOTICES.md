# Third-party notices

## Spotify

Raaga can read metadata exposed by Spotify's public embed pages for a playlist
link supplied or shared by the user. Spotify is not bundled with Raaga and no
affiliation is claimed. Imported Spotify items remain identified as Spotify
imports. Playback is limited to preview audio URLs that Spotify itself exposes
for a track when available. Raaga does not download or convert Spotify full
tracks.

Spotify's public embed HTML structure is not a stable API contract, so playlist
import may require maintenance if Spotify changes that page.

## Spotube

Spotube (https://github.com/team-spotube/spotube, BSD-4-Clause) is not included
or depended on in this build.

## Internet Archive

Online search uses the public archive.org advancedsearch and metadata endpoints
(no key). Results are filtered to Creative Commons, public-domain and LibriVox
items, but a public URL does not grant reuse rights: check each item's license,
and credit artists where the license requires it.

## Flutter packages

`receive_sharing_intent` is used for Android text/URL sharing into Raaga and
retains its own license. Other Flutter packages retain their own licenses,
available in the app's About > Licenses screen.

This project's LICENSE file (GPL-3.0-or-later) stays in place. The code license
does not grant music rights or ownership of third-party audio. No affiliation
with Spotify, Spotube, YouTube, JioSaavn or Last.fm is claimed.
