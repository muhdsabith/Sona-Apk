# Third-party notices

This build removes the Spotify Web API, Last.fm, Saavn backend and YouTube
integrations, along with the bundled Musify-derived youtube_explode_dart
package. Raaga now plays only imported files and direct audio links.

## Spotube

Raaga declares Spotube as a git dependency in pubspec.yaml:
https://github.com/team-spotube/spotube

Spotube is licensed under BSD-4-Clause. Retain its copyright and license
notice when redistributing. BSD-4-Clause includes an advertising clause that
the FSF considers incompatible with GPL-3.0-or-later, the license of this
project's LICENSE file. Review this before distributing a combined build.

## Other notices

This project's LICENSE file (GPL-3.0-or-later) stays in place. Other Flutter
packages retain their own licenses, available in the app's About > Licenses
screen. The code license does not grant music rights or ownership of
third-party audio. No affiliation with Spotube, Spotify, YouTube, JioSaavn or
Last.fm is claimed.
