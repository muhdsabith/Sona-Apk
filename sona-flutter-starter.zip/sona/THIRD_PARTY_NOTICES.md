# Third-party notices

Olam 4.3.0 (formerly Sona) adds online playback based on the approach in Musify.
Reference: https://github.com/gokadzev/Musify
Reference commit: 5b98d3a3cddd3fdb16ea6cc14d59d667e82cccd2
Copyright (C) 2026 Valeri Gokadze and Musify contributors.

The bundled packages/youtube_explode_dart directory is derived from that
commit, with its own BSD-3-Clause LICENSE retained (Copyright 2021 Mattia).
The dependency, its generated Dart files, and all required source files are
included. Sona fixes two dynamic map extension calls in search_page.dart by
casting viewCountText runs before accessing text; this prevents NoSuchMethodError.
Sona also makes unrecognized relative-date metadata return null instead of
crashing the entire search (helpers_extension.dart).
In retry.dart, request-limit exceptions now stop immediately instead of being
retried; Sona applies a shared 60-second cooldown for subsequent requests.
Sona uses the same manifest client selection and matching playback
headers as that Musify snapshot. UI/controller integration was written for Sona.

This combined source distribution is supplied under GPL-3.0-or-later; see LICENSE.
Retain original notices and provide corresponding source when distributing a
modified APK under those terms. The embedded dependency retains its own license.
The code license does not grant music rights or ownership of third-party audio.
No affiliation with YouTube, Spotify, Musify or their owners is claimed.

Olam's new wave branding replaces the previous Sona mark. Bundled demo audio was removed in 4.1.0. Other Flutter
packages retain their own licenses, available in Library > About Sona > Licenses.

Olam 4.3.0 routes online playback through the official YouTube IFrame player.
The bundled Musify-derived dependency continues to supply search metadata.
