# Sona 4.0.1 — music inside Sona

This source ZIP adds online song search and direct in-app playback using the
YouTube extractor bundled with Musify. It keeps Sona's dark/lime design and logo,
local music, playlists, favourites, podcast discovery/RSS subscriptions and player.
The Spotify companion remains optional under Library. No API key or Spotify login
is needed for the new online music search.

## Build on your Android phone

1. Upload **sona-flutter-starter.zip** to your GitHub repository's top level,
   replacing the old file with exactly the same name.
2. Commit the upload. Start a **new** Actions > Build Sona APK > Run workflow.
3. Download the **Sona-Android-APK** artifact, extract it and install app-debug.apk.
4. Open Sona > Find music. Type a song/artist and press the search arrow or keyboard
   Search. Tap a result. It should play inside Sona.
5. Test pause, seek, next, locking the screen, and reopening a saved favourite.

The existing workflow can continue if it preserves the supplied AndroidManifest.xml
and launcher resources. A complete compatible replacement is included at
**tool/build-android.yml**: copy its contents into your repository's
`.github/workflows/build-android.yml` only if your existing workflow fails.
The workflow installs dependencies, runs analysis and tests, builds and uploads an
APK. It must run on the commit containing this updated source ZIP.

This ZIP is source code, not an APK. No new APK was built or tested on a phone in
this workspace. Live online search and 20 offline checks passed. The updated resolver obtained the Faded stream URL in about 30 seconds.
The media-byte probe returned HTTP 206 with text/html, so actual decoding and
phone playback are not confirmed. Check VALIDATION.json for the checks actually completed. Your
successful Musify phone test does not by itself verify this Sona integration.

## Changes in 4.0.1

- Home now loads Malayalam, Tamil and English song shelves automatically, with
  artwork, titles, artists and tap-to-play queues. Refresh buttons reload them.
- Successful home results are cached locally and shown while new results load.
- Playback resolution gets 75 seconds instead of the previous 30. Investigation
  showed the watch page, player response, HLS manifest and CDN validation could
  together exceed the old limit even when a song was available.
- Each resolution uses its own client, closed after completion or timeout so
  abandoned requests do not keep retrying behind later play attempts.
- Loading, request limits, restricted tracks and timeout errors are distinguished.
- The required watch-page metadata and matching playback headers are retained.

## Features

- Online search with submit, loading/error/empty states and Load more.
- Plays online songs in Sona; resolves a fresh stream URL for each play/retry.
- Saves stable YouTube IDs and metadata rather than expiring playback URLs.
- Favourites, local playlists, queue, shuffle, repeat, seeking and sleep timer.
- Android background playback/notification and lock-screen controls configured.
- Import phone audio and add direct HTTPS audio links.
- Podcast search, RSS subscriptions, episode progress and episode downloads.
- Optional Spotify browsing/playback control from Library; Spotify handles that
  separate mode's audio and account requirements. Existing callback setup remains.
- Existing local library data and Sona logo are retained.

## Limits

Online playback depends on unofficial YouTube extraction and can stop working when
YouTube changes. Private, unavailable, restricted and live videos are not promised.
No automatic proxies, account cookies, login bypass, music download service or
background backend is installed. Online search results may include non-music videos.
Online songs require internet; offline files and downloaded podcast episodes do not.
This is not a hosted catalogue or a guarantee that every song is available.

This iteration targets Android. iOS source/icon assets are retained, and setup.dart
configures background audio, but iOS requires macOS/Xcode/signing and is untested.

## Development

Use Flutter 3.35+/Dart 3.9+ (stable). From sona/:

```
dart tool/setup.dart
flutter analyze --no-fatal-infos
flutter test
flutter build apk --debug
```

The bundled extractor is a local path dependency. Keep packages/youtube_explode_dart
inside sona/ when moving the project. Pub resolves its additional dependencies on
the first build. No secrets are embedded. See THIRD_PARTY_NOTICES.md and LICENSE.

GitHub debug signing keys may differ between runs, causing an update-signature
conflict. Keep a consistent signing key for long-term upgrades. Uninstalling the app
can delete its local data; do not uninstall before keeping any needed originals.
