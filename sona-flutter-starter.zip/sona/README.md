# Raaga 4.7.0

Flutter music player with a dark lime/lavender interface, saved playlists and
native background audio. This version has no online music APIs: the Spotify
Web API, Last.fm charts, Saavn backend server and YouTube search/embed
integrations were removed.

## What it does

- Import audio files from your phone and play them in the background.
- Add direct HTTPS audio links from your own or licensed catalogs.
- Search, favourites, playlists, sleep timer, lock-screen controls.
- Podcast feed import and offline episode downloads (unchanged).

## Spotube

Spotube (https://github.com/team-spotube/spotube) was tried as a git dependency
but removed: it pins `file_picker 10.3.3` while this app pins `10.3.10`, so
`flutter pub get` failed. Spotube is a full app rather than a published Dart
package, so it is not a good fit as a dependency. Nothing in `lib/` used it.

## Android phone build

1. Upload **sona-flutter-starter.zip** unchanged to your GitHub repository root.
2. Run the build workflow (`tool/build-android.yml`).
3. Download **Sona-Android-APK** and open app-debug.apk.

The ZIP keeps top-level `sona/` and Android package `com.example.sona`.

## Verification

Not verified in this environment: no Flutter or Dart SDK was available, so
`flutter pub get`, `flutter analyze`, tests and the APK build were not run.
GitHub Actions runs analysis, tests and the Android build; check its result.
See THIRD_PARTY_NOTICES.md for licensing notes.
