# Olam 4.5.0 — let the music flow

Flutter music app with a near-black, lime and lavender interface inspired by the
supplied reference. Soft pink/purple ambient backgrounds, pastel discovery and
mood cards, rounded track rows, and a floating five-tab navigation bar.

## Install from your Android phone

1. Upload **sona-flutter-starter.zip** to your GitHub repository root, replacing
   the old ZIP. Keep the filename unchanged and commit.
2. Open Actions and start a **new workflow run on that new commit**.
3. Download **Sona-Android-APK** after the run succeeds, extract the artifact ZIP,
   then install **app-debug.apk**.
4. Check **Settings > About > Olam 4.5.0**.

This ZIP is Flutter source, not an APK. The compatible workflow is included at
`tool/build-android.yml`; copy it to `.github/workflows/build-android.yml` in your
repository if your current workflow does not preserve supplied platform files.
Top-level `sona/`, Android application ID, saved library keys and Spotify callback
are retained for compatibility. Existing Olam wave launcher icon is retained.

## Last.fm charts setup

Your supplied example contained `YOUR_LASTFM_API_KEY`, not a working key.

1. Get an API key at https://www.last.fm/api/account/create .
2. Open Olam **Settings > Last.fm API key** and paste the key.
3. Open **Charts**. Home also displays the first three chart tracks.
4. Tap a chart track to search for it on YouTube. Use its menu to visit Last.fm.

No API secret, password or Last.fm account session is required for chart lookup.
The API key is stored in device preferences (not encrypted secret storage).
You can replace or remove it in Settings. An optional build-time
`--dart-define=LASTFM_API_KEY=...` is also supported, but the phone settings take
precedence. No real credentials are included in this ZIP.

`lib/models/track_model.dart` handles string/map artists, missing or malformed
fields, artwork sizes and page URLs. `lib/services/last_fm_service.dart` provides
bounded chart requests, timeouts and friendly HTTP/Last.fm errors. The controller
keeps successful charts in memory for 30 minutes and ignores stale responses
when the key changes. Refresh is manual; there are no automatic retry loops.

Last.fm supplies chart metadata and links to Last.fm song pages. Its `url` field
is **not an audio stream**. Chart items are not passed to the audio player.
Artwork has a rank fallback because images may be missing. No demo songs added.
Reference: https://www.last.fm/api/show/chart.getTopTracks

## Pages

- Home: ambient header, favourites shortcut, language filters, lavender discovery
  card, live Last.fm preview when configured, YouTube discoveries, import panel.
- Search: pastel mood cards, online search, local library results.
- Charts: ranked Last.fm tracks, loading/empty/error/setup states and refresh.
- Library: favourites, offline music, recently played, editable playlists.
- Settings: Last.fm key setup, imports, direct links and Spotify connections.
- Native player: matching dark surfaces, lime transport, waveform seek, favourites,
  queue, repeat/shuffle and sleep timer.
- YouTube and optional Spotify screens, playlist pages, dialogs and sheets use
  the shared updated visual palette. Provider web content retains its own UI.

## Background playback

Imported audio files and permitted direct HTTPS audio streams use the native
AudioService with background and lock-screen controls. On Home choose Import
songs, or use Settings > Add a direct audio link. Start a native song, press Home
or lock the device, and test pause/resume/next controls.

YouTube playback uses a **visible official in-app video player**. Tap Play inside
the video. Leaving the screen or backgrounding Olam stops/pauses it. Last.fm does
not change this limitation or add a background-streaming catalogue. Native queues
accept local/direct audio only. Search may still be rate limited and individual
videos may restrict embedding or region/account access.

The embedded player identifies this Android build as `https://com.example.sona`.
If the application ID changes, update the build using
`--dart-define=OLAM_APP_ID=your.actual.application.id` too.

## Verification

- Static analysis: see VALIDATION.json for this version's result.
- 19 new Last.fm checks passed as a compiled Dart AOT executable with mocked HTTP:
  malformed fields, artwork ordering, URL validation, request encoding, duplicate
  rows, missing key, HTTP errors, API errors, empty charts, network error, timeout.
- Those checks also have a Flutter test wrapper for GitHub Actions.
- No live Last.fm request was made: no working API key was supplied.
- No local APK build, Flutter widget execution, UI render or audible phone playback
  was performed. Source validation is not device validation.
- Existing YouTube bridge tests last ran for 4.3.0; playback logic is unchanged.

Phone checks: navigate all five tabs, configure Last.fm, refresh charts, search a
chart track, create a playlist, test large text, import music and test screen-off
playback. Check YouTube pauses when leaving its player.

## Development

Flutter 3.35+ / Dart 3.9+, from `sona/`:

```
dart tool/setup.dart
flutter analyze --no-fatal-infos
flutter test
flutter build apk --debug
```

Keep `packages/youtube_explode_dart`, the bundled Musify-derived dependency.
GPL-3.0-or-later and upstream notices are retained; see THIRD_PARTY_NOTICES.md.
iOS source requires macOS, Xcode, signing and separate device validation.
GitHub debug builds can have different signing keys between runs. Use consistent
signing if installation reports a signature conflict; uninstalling removes local
data, so keep your original music files.
