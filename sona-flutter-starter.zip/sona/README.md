# Sona 2.0.1 — independent music and podcast player

Sona plays imported music, direct HTTPS audio links, and public podcast episodes inside the app. It does not need Spotify for these features. Three original music samples and two sample spoken episodes remain available to try the player before adding a collection.

## Start on your Android phone

1. Download `sona-flutter-starter.zip` and upload it to the top level of your GitHub repository, replacing the old file. Keep the filename exactly as shown.
2. Start a **new** Actions → Build Sona APK → Run workflow on the updated branch. Your existing workflow still extracts the `sona/` directory and builds it.
3. Download the successful run's **Sona-Android-APK** artifact, extract it, and install `app-debug.apk`.
4. Open **Import music** to choose MP3, M4A, AAC, WAV, OGG or FLAC files on your phone. Playback support depends on your device's codecs. Files are copied into app storage for offline playback; originals are untouched. There is a 500 MB limit per file.
5. Open **Find podcasts**, search by a name, subject or language (for example Malayalam), and tap **+** to subscribe. You can also paste an HTTPS RSS feed address.
6. Tap an episode or song to play inside Sona. The mini player opens the full player. Screen-off playback, media notifications, headset controls and lock-screen controls use Android's audio service.

If Android reports a signature conflict when installing an update from GitHub, the debug signing key changed between builds. Uninstalling the old app removes its app-local library and audio copies. Keep your original audio files. A store release needs a stable private signing key.

## Included features

- Device music import, content-based duplicate detection and offline copies.
- Direct HTTPS audio links for your own or licensed hosted catalog.
- Podcast directory search (Apple's public search API) and direct RSS subscriptions.
- Podcast artwork, descriptions, refreshing, saved episodes and unsubscribe while keeping episodes.
- Native in-app playback, media notification, lock-screen/headset controls, background queue playback.
- Mini/full players, seeking, previous/next, shuffle, repeat-one and play-next queue insertion.
- Episode resume positions, 1×/1.25×/1.5×/2× speed and 10-second skip controls.
- Episode downloads, progress, cancellation, offline playback and removal. Downloads need Sona running; interrupted downloads are not resumed automatically.
- Search across your library, favourites, playlist creation/renaming/deletion and playlist membership.
- Recently played, offline collection, and a 15/30/45/60-minute sleep timer.
- Device-local persistence. Existing v1 favourites, playlists and resume positions migrate automatically.
- The working Spotify connection is preserved under **Library → Optional Spotify connection**. Those items still use Spotify; they are separate from the independent player.

## Content and storage

This is a personal player, not a supplied commercial song catalog or a hosted streaming service. Add your music files or direct audio links. Podcast episodes come from their publishers' RSS enclosures. A Spotify or YouTube webpage URL is not a playable audio file.

Podcast search needs internet and relies on an external directory; direct feed entry is also available. Only HTTPS feeds, images and enclosures are accepted. Each refresh reads up to 150 recent feed entries and retains existing episodes so saved items do not vanish. RSS 2.0 audio enclosures are supported; Atom-only and video-only feeds are not. Publisher availability and regional restrictions still apply.

Library data stays on the device using SharedPreferences. Music copies/downloads use the app's documents folder. No account, server, cloud sync, subscription system, or third-party analytics is included. Clearing app data or uninstalling removes the local library and copies. Imported originals are not deleted.

## Flutter development

Requires Flutter 3.35+/Dart 3.9+. Run from `sona/`:

```sh
dart tool/setup.dart
flutter test
flutter run
```

`tool/setup.dart` generates Android and iOS runners without overwriting the included Android manifest and notification icon, sets minSdk 24, and configures iOS background audio. The optional Spotify auth plugin requires iOS 17.4+. iOS needs a Mac, Xcode and signing; it is not built by the Android workflow.

The Android activity uses `AudioServiceActivity` and declares the media playback service, media button receiver, wake lock and foreground-service permissions. API code remains in `lib/services/apis.dart`; no Provider package is used.

## Release scope

The ZIP is source code. GitHub builds the installable debug APK. Android and iPhone device playback, background operation, Bluetooth/headset interactions and interrupted-download behavior must be checked on real devices before release. Public store publishing, release signing and a music-distribution backend are separate deployment work.

See `VALIDATION.json` for the actual checks completed for this version. Do not interpret source checks as successful device testing.

## 2.0.1 review fixes

Immediate download cancellation now works during storage preparation; cancelled downloads do not show failure messages. Download cleanup always closes the network client. Removing a track updates the media notification queue, and download deletion is blocked while playback is loading. Static analysis passed; see VALIDATION.json for the unexecuted runtime checks.
