# Olam 4.2.0 — let the music flow

A music-only Flutter player with a warm cream interface and a new wave identity.

## Install from your Android phone

1. Upload **sona-flutter-starter.zip** to the top level of your GitHub repository,
   replacing the old ZIP with exactly the same filename. Commit the change.
2. Open Actions > your build workflow > Run workflow. Start a **new run on the new commit**.
3. After success, download the **Sona-Android-APK** artifact, extract it, and open
   **app-debug.apk** to install.
4. Open Library > About Olam and confirm **4.2.0**.

This ZIP contains Flutter source; it is not an APK. The compatible workflow is
included at `tool/build-android.yml`. If your existing workflow already preserves
the supplied Android manifest and icons, continue using it. Otherwise copy the
included workflow to `.github/workflows/build-android.yml` in your repository.

## Changes in Olam 4.2.0

- New app display name **Olam**, with a terracotta wave/O logo. Launcher icons
  supplied for Android (legacy and adaptive) and iOS; Flutter branding updated.
- Warm cream background, charcoal text, terracotta accents, and clean Material
  controls inspired by the supplied music-player reference video.
- Tracks opens to a compact song list. Filter Malayalam, Tamil, English or
  on-device tracks; sort by title or artist. Search and Library remain separate.
- The player centres artwork, song and artist with smaller transport controls,
  favourite / playlist / queue actions and a sleep timer.
- The seek bar uses a decorative wave for the played portion. It is draggable,
  retains Flutter Slider semantics, and is not a measured audio waveform.
- Podcast screens and example audio remain removed. Your music library, favourites
  and playlists continue using the same stored keys.
- The internal project/package name, Android identity, Spotify callback and ZIP
  filename stay unchanged, so the existing GitHub workflow and Spotify dashboard
  setup can continue. Public app labels and notifications use Olam.
- The prior request-limit cooldown and six-hour home cache remain in place.

## Playback status — read before building

The earlier screenshot's request-limit error remains a provider limitation. This design update does **not**
guarantee that YouTube songs will play. In the previous version, stream resolution
succeeded but the media probe returned unexpected HTML rather than verified audio.
Audible YouTube playback is still unverified. No proxy or access bypass is added.

Local imports and direct HTTPS audio links remain available. The optional Spotify
companion is under Library; its audio is handled by Spotify. Existing Spotify
callback configuration is retained; Olam branding is applied throughout.

## Verification

- Dart analyzer: zero errors and zero warnings (style notices remain).
- 26 offline checks passed, including mocked HTTP 429 behavior, no automatic retry,
  shared cooldown across search/playback, cooldown expiry, source validation,
  codec selection, metadata parsing and saved-track serialization.
- Three new wave-slider widget tests are included for the GitHub build.
- No local APK build, Flutter widget test execution, rendered screen validation,
  or Android device playback test was performed. The included GitHub workflow
  runs Flutter analysis/tests and builds the APK. See `VALIDATION.json`.

## Development

Flutter 3.35+ / Dart 3.9+. From `sona/`:

```
dart tool/setup.dart
flutter analyze --no-fatal-infos
flutter test
flutter build apk --debug
```

Keep `packages/youtube_explode_dart` in the source tree. It is the bundled path
dependency derived from Musify. Notices and source modifications are described in
`THIRD_PARTY_NOTICES.md`; license is GPL-3.0-or-later with upstream notices retained.
No API secrets are included. iOS source is retained but requires macOS, Xcode,
signing and device testing.

GitHub debug builds can use different signing keys between runs. An installation
signature conflict needs consistent signing; uninstalling can remove local data.
Keep any original music files before uninstalling.
