# Sona — music & podcasts

A Flutter starter for Android and iPhone with an original dark interface, lime accents, code-drawn cover artwork, three original music demos, and two synthetic-voice podcast demos. No API keys, account, or network connection are required to browse and play the bundled demo catalogue after installation. Version 1.2 adds your Spotify playlist embed, alongside the optional Spotify sign-in and top-tracks screen; see SPOTIFY_SETUP.md for phone-only setup and rebuilding instructions.

## Start the app

Install a current stable Flutter SDK (at least Flutter 3.35 / Dart 3.9), plus Android Studio for Android. iOS builds require macOS and Xcode. Run `flutter doctor` and complete any required platform setup first.

Unzip this project, open a terminal inside `sona`, then run:

```sh
dart tool/setup.dart
flutter run
```

The setup script generates standard Android and iOS runner projects using your installed Flutter version, enables Android network permission for future HTTPS streaming, sets Android's minimum SDK to 24, resolves dependencies, and runs `flutter analyze`. It preserves existing Dart source and pubspec files by not passing `--overwrite`. Review generated platform files if you run setup again after native customization.

The Android callback manifest is included. The remaining native runner files and a dependency lockfile are generated on your computer or by the GitHub workflow. Commit the resulting `pubspec.lock` for reproducible builds. The Spotify authentication plugin requires iOS 17.4 or newer. The setup script updates generated iOS deployment targets; verify them in Xcode. After setup you can open the generated platform project in Android Studio or `ios/Runner.xcworkspace` in Xcode.

To build an Android APK after successful setup:

```sh
flutter build apk --release
```

For an iOS release, configure your Apple development team and a unique bundle identifier in Xcode, then use `flutter build ipa`. Store publication, signing, and app-store assets are not included.

## Included

- Your supplied Spotify playlist in a native WebView, available from Home and Library without an API token.
- Optional Spotify sign-in with PKCE, five top tracks, time ranges, token refresh, and Open in Spotify links.
- Home with music/podcast filters and a featured mix.
- Search across titles, creators, and categories.
- Dedicated podcast browsing and episode descriptions.
- Mini player and full player, scrubbing, queue selection, previous/next, shuffle, and repeat-one.
- Podcast skip controls and 1× / 1.25× / 1.5× / 2× speed.
- Favourites, playlist creation/deletion, and adding/removing playlist items.
- Device-local persistence of favourites, playlists, and podcast progress.
- Loading, playback-error, empty-library, and no-search-results states.
- Scrolling layouts, constrained tablet widths, safe areas, and labelled icon controls.

Podcast progress is checkpointed every five seconds and on pause/seek/track change. Completing an episode resets its progress. This starter pauses when the app moves to the background. Its next button wraps manually; automatic playback stops at the end of the queue unless shuffle or repeat is enabled.

## Project map

```text
lib/main.dart                     Theme, app startup, lifecycle
lib/models/media_item.dart        Catalogue and playlist models
lib/services/apis.dart            Catalogue interface and local demo catalogue
lib/services/library_store.dart   Serialized local preference writes
lib/controllers/app_controller.dart  Playback and library state
lib/ui/app_shell.dart             Browsing, library, and player screens
lib/ui/cover_art.dart             Original procedural artwork
assets/audio/                    Bundled MP3 demos
tool/setup.dart                  Generate native runners and check setup
```

State uses Flutter's `ChangeNotifier` and `AnimatedBuilder`; Provider is not required. API/catalogue code is isolated in `apis.dart`.

## Connect your own catalogue

Implement `CatalogApi.fetchCatalog()` in `lib/services/apis.dart`, mapping your API response to `MediaItem` values. Inject that implementation in `main.dart`. Each item needs a stable unique ID; existing favourites, playlists, and resume positions are tied to those IDs. Set `source` to an audio asset path starting with `assets/` or a direct HTTPS audio URL. A service webpage or a Spotify track URL is not a direct playable audio file.

Suggested server fields: `id`, `title`, `creator`, `category`, `kind`, `source`, `color`, `art`, `description`. The starter has no credentials in client code. For a hosted catalogue, serve audio you have permission to distribute, and issue authenticated URLs from your server where needed. Spotify top-track metadata can be connected through Library → Connect Spotify; full Spotify audio is not provided to this player.

## Scope and next implementation work

This is a local, foreground-playback starter, not a finished streaming service. It includes Spotify authorization for top-track metadata, but does not include Sona user accounts, cloud sync, an upload/admin backend, subscriptions, general external catalogue discovery, music licensing, downloaded-file management, background playback (the playlist embed also reloads after backgrounding), media notifications, lock-screen controls, recommendation algorithms, analytics, or store publishing. “Podcasts” here are two playable demo episodes, not a live RSS directory. The podcast voices are synthetic; the scripts and music are supplied as original demos.

To support background playback, integrate an audio-service handler with platform foreground-service/audio background configuration, then remove the current pause-on-background lifecycle behavior after device testing. Account and catalogue backend choices can be added without moving the UI into the API file.

## Verification status

The supplied Dart files were checked for syntax with a Dart grammar parser. All bundled MP3s were checked for decodability, and catalogue asset references were checked against the package. Flutter/Dart SDKs and mobile emulators were unavailable in the authoring environment, so `flutter analyze`, device playback, APK compilation, and iOS compilation have **not** been verified. The setup script runs the Flutter analyzer on your computer. This package is source code, not an APK or IPA.

Before shipping, verify on a physical Android device and iPhone:

1. Start playback, pause, scrub, skip, switch tracks, and let the queue finish.
2. Use repeat and shuffle, including a one-item playlist.
3. Change podcast speed, seek, restart the app, and confirm resume position.
4. Create a playlist, add/remove tracks, favourite an item, and restart to check persistence.
5. Test empty search results, an unavailable HTTPS source, airplane mode, and interrupted playback.
6. Check small screens, large accessibility text, landscape, headphones, phone interruptions, and background/foreground transitions.

## Dependency references

- [Flutter installation](https://docs.flutter.dev/get-started/install)
- [just_audio](https://pub.dev/packages/just_audio) — audio playback
- [audio_session](https://pub.dev/packages/audio_session) — audio session setup
- [shared_preferences](https://pub.dev/packages/shared_preferences) — local storage
- [flutter_web_auth_2](https://pub.dev/packages/flutter_web_auth_2) — Spotify browser authorization
- [webview_flutter](https://pub.dev/packages/webview_flutter) — native view for the Spotify playlist embed
- [Spotify PKCE](https://developer.spotify.com/documentation/web-api/tutorials/code-pkce-flow) — sign-in without a client secret

These package APIs were consulted while preparing the source. Resolve and validate the dependencies with your local Flutter SDK before release.
