# Raaga 4.7.0

Flutter music player with a dark lime/lavender interface, saved playlists and
native background audio. The Spotify Web API, Last.fm charts, Saavn backend
server and YouTube search/embed integrations were removed. Online search now
uses the Internet Archive only, with no API key.

## What it does

- Search the Internet Archive (Search tab) for audio that is Creative Commons,
  public domain or LibriVox. Each result shows its license. Items whose license
  is not clearly free are hidden. An item plays its first MP3 file.
- Import audio files from your phone and play them in the background.
- Add direct HTTPS audio links from your own or licensed catalogs.
- Search, favourites, playlists, sleep timer, lock-screen controls.
- Podcast feed import and offline episode downloads (unchanged).

## Spotube

Spotube (https://github.com/team-spotube/spotube) was tried as a git dependency
but removed: it pins `file_picker 10.3.3` while this app pins `10.3.10`, so
`flutter pub get` failed. Spotube is a full app rather than a published Dart
package, so it is not a good fit as a dependency. Nothing in `lib/` used it.

## Android phone build

1. Upload **sona-flutter-starter.zip** unchanged to your GitHub repository root.
2. Run the build workflow (`tool/build-android.yml`).
3. Download **Sona-Android-APK** and open app-debug.apk.

The ZIP keeps top-level `sona/` and Android package `com.example.sona`.

## Verification

Not verified in this environment: no Flutter or Dart SDK was available, so
`flutter pub get`, `flutter analyze`, tests and the APK build were not run.
GitHub Actions runs analysis, tests and the Android build; check its result.
See THIRD_PARTY_NOTICES.md for licensing notes.
