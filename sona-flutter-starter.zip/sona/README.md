# Sona 4.1.0 — your music, refined

A music-only update with a charcoal / warm white / lime interface, an editorial
Home page, Malayalam / Tamil / English song shelves, search, favourites,
playlists, imported music and a compact full-screen player.

## Install from your Android phone

1. Upload **sona-flutter-starter.zip** to the top level of your GitHub repository,
   replacing the old ZIP with exactly the same filename. Commit the change.
2. Open Actions > Build Sona APK > Run workflow. Start a **new run on the new commit**.
3. After success, download the **Sona-Android-APK** artifact, extract it, and open
   **app-debug.apk** to install.
4. Open Library > About Sona and confirm **4.1.0**.

This ZIP contains Flutter source; it is not an APK. The compatible workflow is
included at `tool/build-android.yml`. If your existing workflow already preserves
the supplied Android manifest and icons, continue using it. Otherwise copy the
included workflow to `.github/workflows/build-android.yml` in your repository.

## Changes

- Music-only Home, Search and Library. Podcast tabs, discovery, episode actions,
  and podcast filters in the optional Spotify companion are removed.
- Bundled example music and podcast audio files are removed from the source and
  asset manifest. No example songs are inserted at startup.
- Existing user music, favourites, playlists and imports remain. Legacy podcast
  records remain stored for compatibility, but are excluded from the Sona music
  catalogue, favourites, history and playlist views. Upgrading does not delete
  previously imported user files.
- Home has a featured mood card, mood shortcuts, recent listening, and real search
  results for Malayalam, Tamil and English. The featured card opens a search;
  it is not a fabricated playlist. Search results may include non-music videos.
- Artwork cards have bounded titles, artist labels and play affordances. The
  smaller full-player artwork and two-line title leave more room for transport
  controls. Queue is a separate sheet; the player scrolls on small screens.
- The mini player displays loading or playback errors. A failed song offers an
  explicit **Open in YouTube** action, which opens an external app or browser.
- Home results are reused for six hours, and refreshed sequentially. Pull to
  refresh requests a new collection; cached songs remain during failures.
- Request-limit responses are no longer automatically retried. A shared one-minute
  cooldown blocks subsequent search and playback requests. This is Sona's retry
  policy, not a promise that YouTube will allow playback after one minute.

## Playback status — read before building

The screenshot's request-limit error remains a provider limitation. This update
reduces repeated requests and improves the error experience; it does **not**
guarantee that YouTube songs will play. In the previous version, stream resolution
succeeded but the media probe returned unexpected HTML rather than verified audio.
Audible YouTube playback is still unverified. No proxy or access bypass is added.

Local imports and direct HTTPS audio links remain available. The optional Spotify
companion is under Library; its audio is handled by Spotify. Existing Spotify
callback configuration and branding are retained.

## Verification

- Dart analyzer: zero errors and zero warnings (style notices remain).
- 26 offline checks passed, including mocked HTTP 429 behavior, no automatic retry,
  shared cooldown across search/playback, cooldown expiry, source validation,
  codec selection, metadata parsing and saved-track serialization.
- No local APK build, Flutter widget test execution, rendered screen validation,
  or Android device playback test was performed. The included GitHub workflow
  runs Flutter analysis/tests and builds the APK. See `VALIDATION.json`.

## Development

Flutter 3.35+ / Dart 3.9+. From `sona/`:

```
dart tool/setup.dart
flutter analyze --no-fatal-infos
flutter test
flutter build apk --debug
```

Keep `packages/youtube_explode_dart` in the source tree. It is the bundled path
dependency derived from Musify. Notices and source modifications are described in
`THIRD_PARTY_NOTICES.md`; license is GPL-3.0-or-later with upstream notices retained.
No API secrets are included. iOS source is retained but requires macOS, Xcode,
signing and device testing.

GitHub debug builds can use different signing keys between runs. An installation
signature conflict needs consistent signing; uninstalling can remove local data.
Keep any original music files before uninstalling.
