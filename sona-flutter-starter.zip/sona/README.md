# Olam 4.4.0 — let the music flow

A music-only Flutter player with a dark violet interface, rounded artwork cards and floating navigation.

## Install from your Android phone

1. Upload **sona-flutter-starter.zip** to the top level of your GitHub repository,
   replacing the old ZIP with exactly the same filename. Commit the change.
2. Open Actions > your build workflow > Run workflow. Start a **new run on the new commit**.
3. After success, download the **Sona-Android-APK** artifact, extract it, and open
   **app-debug.apk** to install.
4. Open Library > About Olam and confirm **4.4.0**.

This ZIP contains Flutter source; it is not an APK. The compatible workflow is
included at `tool/build-android.yml`. If your existing workflow already preserves
the supplied Android manifest and icons, continue using it. Otherwise copy the
included workflow to `.github/workflows/build-android.yml` in your repository.

## New in 4.4.0

- Dark surfaces, lavender typography, violet gradients and rounded music cards inspired by the supplied references.
- Home search shortcut, language filters, horizontal discovery cards and floating bottom navigation.
- A prominent background-listening card with Import songs, Add audio link and Play my music actions.
- Source labels distinguish YouTube video playback from native background audio.
- Native player, Search, Library and optional Spotify screens use the new palette.
- No example tracks or podcasts added. Existing app icon is retained.

## Background listening on your phone

1. On Home choose **Import songs** and select a music file, or **Add audio link** for a direct HTTPS audio stream you can use.
2. Choose **Play my music** and tap a track. This opens the native audio player.
3. Press Home or lock the phone. The audio service is configured to continue playback and expose media controls.
4. Check pause/resume and next/previous from the notification or lock screen.

YouTube songs use a separate visible video player and stop when you leave it.
The embedded YouTube player is not a source for background audio. Supporting an
online music catalogue with screen-off playback requires a provider that supplies
permitted direct audio streams. This update does not add that catalogue.

Background playback configuration was reviewed, but screen-off playback and the
new layout still need testing on an Android phone. No APK was built here.

## Playback change in 4.3.0

Online songs now open a visible **official YouTube player inside Olam**.
Tap the song, then tap **Play inside the video**. The old native audio extraction
path is no longer called for YouTube songs, so its media-request rate-limit
countdown no longer blocks opening a saved online song.

- Existing Olam logo, music search, favourites and playlists are retained.
- YouTube playback requires this screen to remain visible. Leaving the screen or
  backgrounding Olam stops/pauses that player. It does not offer YouTube audio-only
  or lock-screen playback. Imported files and direct audio links keep the native
  background player.
- Online collections can be selected manually below the player. Playback controls
  and seeking are supplied by YouTube. Native audio queues accept local/direct
  audio items only, preventing an online item from returning to the old extractor.
- Your history is updated only when the player reports actual playback.
- The embedded player identifies the installed app as `https://com.example.sona`
  using the HTML base URL and IFrame origin. This matches the supplied Android
  build. If you change the application ID, build with
  `--dart-define=OLAM_APP_ID=your.actual.application.id` too.
- Player errors distinguish unavailable/private content, embedding restrictions,
  and identification failures (YT153). The external YouTube option remains.
- Search still uses the existing metadata provider; search rate limits can still
  affect discovery. They no longer prevent the embedded player opening a song
  already present in your library or cached results.

## What has and has not been verified

The earlier 4.3.0 extraction trace reached the watch page and player API but returned
`text/html` from the media host. Stream URL resolution therefore did not verify
audio playback. The change uses the supported embedded player instead.

- Static Dart analysis passed with no errors or warnings; style notices remain.
- In 4.3.0, nine offline embed checks passed: app identity, video-ID validation and error mapping.
- In 4.3.0, seven JavaScript checks passed against a mock player: initialization, visible
  controls, readiness/playing/error events, and pausing when hidden.
- No Android APK build, Android WebView playback, or audible playback was tested
  here. Build the APK in GitHub and test a song on your phone. Content owners may
  prohibit embedding, and YouTube can still impose account or regional restrictions.
- The existing Flutter tests plus the new embed checks run in the included workflow.

This is a source ZIP, not an APK. See `VALIDATION.json` for exact verification.
Official references:
https://developers.google.com/youtube/iframe_api_reference
https://developers.google.com/youtube/terms/required-minimum-functionality

## Development

Flutter 3.35+ / Dart 3.9+. From `sona/`:

```
dart tool/setup.dart
flutter analyze --no-fatal-infos
flutter test
flutter build apk --debug
```

Keep `packages/youtube_explode_dart` in the source tree. It is the bundled path
dependency derived from Musify. Notices and source modifications are described in
`THIRD_PARTY_NOTICES.md`; license is GPL-3.0-or-later with upstream notices retained.
No API secrets are included. iOS source is retained but requires macOS, Xcode,
signing and device testing.

GitHub debug builds can use different signing keys between runs. An installation
signature conflict needs consistent signing; uninstalling can remove local data.
Keep any original music files before uninstalling.
