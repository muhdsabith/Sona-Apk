# Raaga 4.6.0

Flutter music app with a dark lime/lavender interface, a new Raaga ribbon icon,
Saavn server integration, Last.fm charts, saved playlists and native background
audio. No podcasts or bundled example songs are added.

## Android phone build

1. Upload **sona-flutter-starter.zip** unchanged to your GitHub repository root.
2. Run your existing build workflow. `tool/build-android.yml` is included if
   you need to replace the workflow at `.github/workflows/build-android.yml`.
3. After success, download **Sona-Android-APK**, fully extract the artifact ZIP,
   then open app-debug.apk. The installed app is named **Raaga**.

This download is source code, not an APK. The ZIP keeps top-level `sona/` and
Android package `com.example.sona` for existing build compatibility. Preferences,
Spotify callback and library records are preserved. Updates require the same
signing key as the installed build. Back up your files before uninstalling.

## Enable Saavn music

The backend code is included under **backend/**. It must be hosted on an HTTPS
Node server before Saavn Home/Search can work. Follow **backend/README.md**.
In Raaga, open Settings → Saavn music server → paste your hosted URL → Check & save.
No API key or separate JioSaavn app is used by this integration.

Raaga resolves fresh song URLs before sending them to its native audio service.
Available streams can use background play, queue, seek and notification controls.
This is an unofficial SDK with experimental stream resolution. Live search from
our build environment returned HTML, so **live Saavn playback is not verified**.
No server is deployed or preconfigured in this ZIP. A health check verifies the
backend protocol only. Clearing the server setting returns discovery to YouTube.

## Other sources

- Imported audio and direct audio links use the native background player.
- Last.fm charts require your own API key in Settings; they provide metadata,
  not playable audio. Chart taps search the selected provider.
- YouTube uses the visible official embedded video player and pauses when its
  screen is closed. Its videos do not play as hidden background audio.
- Optional Spotify controls still rely on playback through Spotify.

Only configure music sources you trust and have permission to use. The app is
independent and is not affiliated with Spotify, JioSaavn or Last.fm.

## Verification

- Dart static analysis: no errors or warnings; existing style notices remain.
- New Saavn adapter: 12 offline checks; backend: 8 mocked contract tests.
- Live SDK search: failed with HTML instead of JSON; no stream verified.
- APK build, physical phone playback and iOS signing were not performed here.
- GitHub Actions runs Flutter analysis, tests and the Android build.

For iPhone, generate/build with Flutter on macOS and Xcode. Existing background
audio setup and new icons are supplied; device testing and signing are required.

Keep the vendored Musify-derived dependency, its notices, LICENSE, and backend
SDK license when redistributing. Android package ID remains com.example.sona;
if you change it, also set `--dart-define=OLAM_APP_ID=your.actual.application.id`
for the official embedded player. See VALIDATION.json for detailed test limits.
