# Your Spotify playlist embed — version 1.2

Your supplied playlist `0OfjG2a49jVbnXSWMA0suD` is now available from **Home → Your Spotify playlist** and **Library → Your Spotify playlist**. Flutter loads the exact Spotify embed endpoint (dark theme) in a native WebView, because a React/HTML iframe cannot be inserted directly into a Flutter widget tree.

This playlist screen needs internet access but no developer Client ID, API token, or top-tracks authorization. Spotify controls which content is playable and whether previews, login, or full playback are available. Opening the playlist does not bypass Spotify account or playback restrictions. WebView playback has not been verified on a physical device; use **Open in Spotify** if the embedded player is limited or unavailable.

Replace the old ZIP in your GitHub repository with this updated `sona-flutter-starter.zip`, run the same **Build Sona APK** workflow, and install the resulting APK. No workflow edits are needed. Keep the filename unchanged; Android downloads may append `(1)`.

The screen includes loading, retry, and external-open controls. Local demo playback pauses before opening the playlist. The embedded page is unloaded when you leave the screen or background the app and reloads on return, so embedded playback position is not saved by Sona. Your native demo-podcast resume positions still work separately.

Implementation: `lib/ui/spotify_playlist_screen.dart`. Change `SpotifyPlaylistScreen.playlistId` to replace the featured playlist. The WebView navigates to Spotify's provided embed URL directly instead of wrapping it in an extra iframe. Spotify's own player retains its branding and controls. Authentication/browser links are opened externally; a browser/Spotify login is not shared with Sona's separate top-tracks API session.

The supplied playlist's availability could not be independently confirmed in this environment. The code preserves your exact ID. Dart syntax and package checks were performed; APK compilation and WebView playback still need verification in GitHub/on your phone.

Official embed information: https://developer.spotify.com/documentation/embeds

---

# Connect Spotify from your Android phone

The sign-in feature implements the JavaScript example's `GET /v1/me/top/tracks?time_range=long_term&limit=5` as a Flutter service in `lib/services/apis.dart`. The new screen is **Library → Connect Spotify**. It shows five top tracks, lets you change the time range, and opens each track in Spotify. It does not provide full-song audio to Sona's built-in player or import podcasts. The original demos and local library continue to work.

## 1. Configure your Spotify app

Open https://developer.spotify.com/dashboard in your phone browser and create or open your developer app. Enable **Web API**. Spotify currently requires the app owner to have an active Spotify Premium subscription for development-mode API access. Development mode permits up to five authenticated, allowlisted users; add your test account in the developer dashboard's user-access settings if required.

Add this redirect URI exactly, including punctuation, with no trailing slash:

```text
com.example.sona.spotify://callback
```

Save the settings and copy the **Client ID**. It is a public identifier. Sona does not use a Client Secret. Do not paste your Spotify password, client secret, access token, or refresh token into source code, GitHub, or chat.

## 2. Rebuild with the existing GitHub workflow

1. Download the updated `sona-flutter-starter.zip` from this conversation.
2. In your existing GitHub repository, use **Add file → Upload files** to upload it with that exact filename, replacing the previous ZIP. Commit the change to the default branch. If Android renamed the download with `(1)`, rename it back before uploading.
3. Run **Actions → Build Sona APK → Run workflow**. Keep the existing `build-android.yml` unchanged. The archive now includes the Android callback manifest; `flutter create` preserves it.
4. After a successful build, download **Sona-Android-APK**, extract it, and install `app-debug.apk`.
5. If Android reports an update-signature conflict, the GitHub build uses a temporary debug signing key. Uninstalling the previous Sona build allows the new APK to install, but deletes that installation's local favourites, playlists, and podcast progress. Keep the existing app until you are ready to lose that local data. Persistent release signing is not configured in this starter.

## 3. Connect in Sona

Open **Library → Connect Spotify**, paste the Client ID, and tap **Connect Spotify**. Sign in on Spotify's own login page and grant permission to read your top tracks. Spotify should redirect back to Sona. Your tracks will appear after the request succeeds. Listening uses **Open in Spotify**.

The app remembers only the public Client ID. Access and refresh tokens stay in memory, are never logged, and are not written to SharedPreferences. Closing/killing the app requires sign-in again. **Disconnect** clears the local session and displayed tracks; it does not revoke the developer app's consent in your Spotify account. Revoke that permission in Spotify account settings if needed.

## Implementation

- Authorization Code with PKCE (S256), randomly generated verifier/state, and exact callback/state checks.
- Only the `user-top-read` scope is requested.
- The app exchanges and refreshes tokens over HTTPS without a client secret.
- Expiry refresh and one retry for a 401; 403 and 429 show actionable errors. Rate-limit cooldown respects `Retry-After` for this screen session.
- Login/session logic: `lib/services/spotify_auth.dart`.
- Top-tracks network request: `lib/services/apis.dart`.
- Screen: `lib/ui/spotify_screen.dart`.
- Android callback receiver: bundled `android/app/src/main/AndroidManifest.xml`.
- Package version: 1.2.0+3.

The selected authentication plugin requires iOS 17.4 or newer. `dart tool/setup.dart` updates generated iOS deployment targets; use Xcode on macOS to verify iOS builds. The provided GitHub workflow builds Android only. Custom-scheme redirects are supported by Spotify, although verified HTTPS App Links/Universal Links are preferred for a production app.

## Troubleshooting

- **Undefined token:** the supplied JavaScript snippet did not contain a valid credential. Use the new sign-in flow instead of pasting a token.
- **INVALID_CLIENT / redirect error:** compare the app's Client ID and the exact registered redirect URI above.
- **403:** check owner Premium status, allowed users, and permission consent. Do not change auth flows to bypass account access requirements.
- **No tracks:** Spotify may not have enough listening history for that account/time range.
- **429:** wait for Spotify's rate/quota window; repeated refreshes do not increase access.
- **Login returns to browser instead of Sona:** verify that the latest APK is installed and the registered redirect URI matches exactly.

## Validation and limits

The updated Dart source is syntax-checked and the Android XML is parsed locally. Unit tests for PKCE, callback validation, request shape, 401 retry, 403, and 429 behavior are included in `test/spotify_api_test.dart`. Run them with `flutter test` in a Flutter environment. They were not executed here because the Flutter SDK is unavailable. No live Spotify login or API request has been tested without your developer app and user consent. The APK/iOS builds also remain unverified here; GitHub will perform the Android build.

Official references checked for this update:

- https://developer.spotify.com/documentation/web-api/tutorials/code-pkce-flow
- https://developer.spotify.com/documentation/web-api/reference/get-users-top-artists-and-tracks
- https://developer.spotify.com/documentation/web-api/concepts/quota-modes
- https://developer.spotify.com/blog/2025-02-12-increasing-the-security-requirements-for-integrating-with-spotify
- https://pub.dev/packages/flutter_web_auth_2/versions/5.1.0

## Version 1.2.1: login diagnostics

This update diagnoses an immediate return from Spotify without a visible login page. It is not a confirmed fix for that device-specific failure. Client ID and redirect settings shown in the user's dashboard match the app.

- Connect Spotify keeps the existing browser behavior. Try a fresh browser session requests an ephemeral login session where supported; browsers may ignore that request.
- SP01: unexpected callback address; SP02: fragment response; SP03: missing or empty state; SP04: duplicate state; SP05: mismatched state.
- SP06–SP10: provider error received with verified state; SP11: missing or duplicate authorization code; SP12: browser canceled; SP13: other browser platform failure.
- Callback URLs, authorization codes, state values, tokens, and provider error descriptions are never displayed or logged. State and redirect checks still run before accepting any result.
- Upload the updated `sona-flutter-starter.zip` at the repository root, replacing the old ZIP. Start a NEW Build Sona APK workflow on the updated main branch. Install its APK and confirm Sona 1.2.1 appears on the Spotify screen.
- Try the fresh-session button. If unsuccessful, report only the displayed SP code. The ZIP is source code, not an installable APK.
- Regression tests cover callback rejection reasons, unchanged state enforcement, and no disclosure of callback credentials. Run `flutter test` in a Flutter environment before building.

## Version 1.2.2: Chrome retry and exact callback checks

Both login choices in 1.2.1 returned SP01 on the user's phone. The received callback is still unknown; no root cause or successful fix has been confirmed.

The replacement retry button, **Try Chrome login**, prefers the installed Chrome browser (package `com.android.chrome`) and requests an ephemeral session where supported. The plugin falls back to other supported browsers if Chrome is unavailable. Normal Connect Spotify retains default browser selection. Android package visibility now explicitly includes Chrome and the Custom Tabs service.

SP01 now includes every mismatching address component: HTTPS/HTTP/SCHEME, HOST, ROOT-SLASH/PATH, USERINFO, or PORT. PARSE means the address could not be parsed. These are fixed labels, never raw address contents. State verification, exact address checks, and PKCE remain unchanged. Even a trailing slash remains rejected until its cause is understood.

Rebuild the APK from this ZIP, confirm **Sona 1.2.2** on the Spotify screen, and tap **Try Chrome login**. Send only the displayed diagnostic code if it fails. Do not change the registered redirect address based only on SP01.
