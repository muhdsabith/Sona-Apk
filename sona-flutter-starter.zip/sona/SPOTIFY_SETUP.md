# Sona Spotify companion setup

1. Keep your existing Spotify developer app and enable Web API.
2. Register exactly `com.example.sona.spotify://callback` as its redirect URI.
3. Add your Spotify test account in the developer app's user management settings.
4. Use Spotify Premium. Install Spotify on the phone, sign in, and play something.
5. Open Sona, enter the app's Client ID (not its secret), and connect again to approve the expanded permissions.
6. Select the phone under Devices. Search or open Library and choose content.

The old callback fix is preserved. Chrome login is available if the default browser returns too early.

Sona 3 uses Spotify Connect through the Web API. It does not require an Android SDK application fingerprint. Spotify plays and downloads the audio; Sona browses and controls it.

No devices: open Spotify and play once, then refresh Devices in Sona. Both apps must use the same account.

Access denied: verify Premium, Web API access, allowed test users and the permissions granted during connection. Some playlist contents and player actions are restricted by Spotify.

Rate limited: wait before trying again. All companion requests respect the returned cooldown; repeatedly pressing controls will not bypass Spotify's quota.

Disconnected after fully closing Sona: connect again. Tokens intentionally stay in memory; the Client ID is remembered.
