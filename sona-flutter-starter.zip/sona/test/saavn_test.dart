import 'package:flutter_test/flutter_test.dart';
import '../tool/check_saavn.dart' as checks;

void main() {
  test('Saavn adapter contracts and failures', checks.main);
}
