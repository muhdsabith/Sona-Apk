import 'package:flutter_test/flutter_test.dart';
import '../tool/check_last_fm.dart' as checks;

void main() {
  test('Last.fm parsing, request and failure regressions', checks.main);
}
