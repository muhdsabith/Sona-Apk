import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:sona/services/apis.dart';
import 'package:sona/services/spotify_auth.dart';

class FakeAuth extends SpotifyAuth {
  int refreshes = 0;
  bool signedOut = false;
  @override
  Future<String> accessToken({bool forceRefresh = false}) async {
    if (forceRefresh) refreshes++;
    return forceRefresh ? 'fresh-test-token' : 'initial-test-token';
  }
  @override
  void signOut() { signedOut = true; super.signOut(); }
}

void main() {
  test('PKCE uses the RFC 7636 S256 vector without base64 padding', () {
    expect(SpotifyAuth.challengeFor('dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk'),
      'E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM');
  });

  test('Callback requires the expected redirect and a single matching state', () {
    expect(SpotifyAuth.validateCallback('${SpotifyAuth.redirectUri}?code=test&state=abc', 'abc'), 'test');
    for (final callback in [
      '${SpotifyAuth.redirectUri}?code=test&state=wrong',
      '${SpotifyAuth.redirectUri}?code=test&state=abc&state=abc',
      '${SpotifyAuth.redirectUri}?code=one&code=two&state=abc',
      'https://example.com/callback?code=test&state=abc',
      '${SpotifyAuth.redirectUri}/other?code=test&state=abc',
      '${SpotifyAuth.redirectUri}?error=access_denied&state=abc',
      '${SpotifyAuth.redirectUri}?state=abc',
    ]) {
      expect(() => SpotifyAuth.validateCallback(callback, 'abc'), throwsA(isA<SpotifyException>()));
    }
  });

  test('Callback diagnostics distinguish failures without disclosing credentials', () {
    const secret = 'private-callback-value';
    final base = SpotifyAuth.redirectUri;
    final failures = <String, String>{
      'https://example.com/?code=$secret&state=abc': 'SP01',
      '$base#access_token=$secret': 'SP02',
      '$base?code=$secret': 'SP03',
      '$base?code=$secret&state=': 'SP03',
      '$base?code=$secret&state=abc&state=abc': 'SP04',
      '$base?code=$secret&state=$secret': 'SP05',
      '$base?error=access_denied&state=abc': 'SP06',
      '$base?error=invalid_scope&state=abc': 'SP07',
      '$base?error=invalid_client&state=abc': 'SP08',
      '$base?error=unauthorized_client&state=abc': 'SP08',
      '$base?error=temporarily_unavailable&state=abc': 'SP09',
      '$base?error=$secret&error_description=$secret&state=abc': 'SP10',
      '$base?state=abc': 'SP11',
      '$base?code=one&code=two&state=abc': 'SP11',
    };
    for (final failure in failures.entries) {
      expect(() => SpotifyAuth.validateCallback(failure.key, 'abc'),
        throwsA(isA<SpotifyException>()
          .having((e) => e.message, 'diagnostic code', startsWith(failure.value))
          .having((e) => e.message, 'no callback secrets', isNot(contains(secret)))));
    }
    // Provider errors must never bypass state validation.
    expect(() => SpotifyAuth.validateCallback('$base?error=access_denied&state=wrong', 'abc'),
      throwsA(isA<SpotifyException>().having((e) => e.message, 'state first', startsWith('SP05'))));
  });

  test('Top tracks preserves the supplied endpoint, limit and time range with no GET body', () async {
    final auth = FakeAuth();
    final api = SpotifyApi(auth: auth, client: MockClient((request) async {
      expect(request.method, 'GET');
      expect(request.url.host, 'api.spotify.com');
      expect(request.url.path, '/v1/me/top/tracks');
      expect(request.url.queryParameters, {'time_range': 'long_term', 'limit': '5'});
      expect(request.headers['Authorization'], 'Bearer initial-test-token');
      expect(request.body, isEmpty);
      return http.Response(jsonEncode({'items': [{
        'id': 'example', 'name': 'Test Track', 'artists': [{'name': 'First'}, {'name': 'Second'}],
        'external_urls': {'spotify': 'https://open.spotify.com/track/example'},
        'album': {'images': []},
      }]}), 200);
    }));
    addTearDown(() { api.dispose(); auth.dispose(); });
    final tracks = await api.getTopTracks();
    expect(tracks.single.title, 'Test Track');
    expect(tracks.single.artists, 'First, Second');
    expect(tracks.single.imageUrl, isNull);
  });

  test('401 refreshes once and retries with the fresh token', () async {
    final auth = FakeAuth();
    var count = 0;
    final api = SpotifyApi(auth: auth, client: MockClient((request) async {
      count++;
      if (count == 1) return http.Response('{}', 401);
      expect(request.headers['Authorization'], 'Bearer fresh-test-token');
      return http.Response('{"items":[]}', 200);
    }));
    addTearDown(() { api.dispose(); auth.dispose(); });
    expect(await api.getTopTracks(), isEmpty);
    expect(count, 2); expect(auth.refreshes, 1);
  });

  test('Repeated 401 signs out and stops retrying', () async {
    final auth = FakeAuth();
    var count = 0;
    final api = SpotifyApi(auth: auth, client: MockClient((_) async {
      count++; return http.Response('{}', 401);
    }));
    addTearDown(() { api.dispose(); auth.dispose(); });
    await expectLater(api.getTopTracks(), throwsA(isA<SpotifyException>()));
    expect(count, 2); expect(auth.signedOut, isTrue);
  });

  test('Rate limit respects Retry-After without repeatedly calling Spotify', () async {
    final auth = FakeAuth();
    var count = 0;
    final api = SpotifyApi(auth: auth, client: MockClient((_) async {
      count++; return http.Response('{}', 429, headers: {'retry-after': '120'});
    }));
    addTearDown(() { api.dispose(); auth.dispose(); });
    await expectLater(api.getTopTracks(), throwsA(isA<SpotifyException>()));
    await expectLater(api.getTopTracks(), throwsA(isA<SpotifyException>()));
    expect(count, 1);
  });

  test('403 provides a setup error without silently replacing results with demos', () async {
    final auth = FakeAuth();
    final api = SpotifyApi(auth: auth, client: MockClient((_) async => http.Response('{}', 403)));
    addTearDown(() { api.dispose(); auth.dispose(); });
    await expectLater(api.getTopTracks(), throwsA(isA<SpotifyException>()
      .having((e) => e.message, 'message', contains('Premium'))));
  });
}
