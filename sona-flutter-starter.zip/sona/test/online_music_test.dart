import 'package:flutter_test/flutter_test.dart';
import '../tool/check_online_music.dart' as checks;

void main() {
  test(
    'Online playback source, codec selection and persistence checks',
    () async {
      await checks.main();
    },
  );
}
