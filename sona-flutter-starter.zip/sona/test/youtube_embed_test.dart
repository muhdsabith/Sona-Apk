import 'package:flutter_test/flutter_test.dart';
import '../tool/check_youtube_embed.dart' as checks;

void main() {
  test('YouTube embed identity, source validation and error mapping', () async {
    await checks.main([]);
  });
}
